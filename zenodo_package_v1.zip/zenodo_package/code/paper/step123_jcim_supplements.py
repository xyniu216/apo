# -*- coding: utf-8 -*-
"""Step123：JCIM 补充分析（P1-5 取舍曲线 / P1-6 分辨率分层 / B2 跨方法一致性统计）。
全部数字从 results/ 既有 CSV 重算，输出 results/Step123_jcim_supplements/。"""
import json
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "results" / "Step123_jcim_supplements"
OUT.mkdir(parents=True, exist_ok=True)
FIG = ROOT / "docs" / "paper" / "figures"

qc = pd.read_csv(ROOT / "results/Step97_structure_qc/pair_structure_qc.csv")
gaps = pd.read_csv(ROOT / "results/Step122_gaps_on_apo/pair_level_with_gaps.csv")
qc["pair_id"] = qc["record_id"] + "__" + qc["apo_pdb_id"].str.lower()

# ---------- 1) 取舍曲线（前置分诊 enrichment curve） ----------
THRESH = 0.30
df = qc[["pair_id", "global_ca_rmsd", "pesto_apo_pair_auprc", "dataset"]].dropna().sort_values(
    "global_ca_rmsd").reset_index(drop=True)
n = len(df)
hit = (df["pesto_apo_pair_auprc"] >= THRESH).astype(int)
base_rate = hit.mean()
fracs = np.arange(1, n + 1) / n           # 按 RMSD 从低到高保留的比例
cum_hit_rate = np.cumsum(hit) / np.arange(1, n + 1)
enrich = cum_hit_rate / base_rate
# 曲线下面积（相对随机线 enrich=1 的超额面积）
auc_enrich = float(np.trapezoid(enrich, fracs))
tradeoff = {
    "n_pairs": int(n),
    "threshold_auprc": THRESH,
    "base_rate": round(float(base_rate), 4),
    "at_third": {"fraction": 1 / 3, "hit_rate": round(float(cum_hit_rate[int(n / 3) - 1]), 4),
                 "enrichment": round(float(enrich[int(n / 3) - 1]), 3)},
    "at_half": {"fraction": 0.5, "hit_rate": round(float(cum_hit_rate[int(n / 2) - 1]), 4),
                "enrichment": round(float(enrich[int(n / 2) - 1]), 3)},
    "at_two_thirds": {"fraction": 2 / 3, "hit_rate": round(float(cum_hit_rate[int(2 * n / 3) - 1]), 4),
                      "enrichment": round(float(enrich[int(2 * n / 3) - 1]), 3)},
    "full": {"hit_rate": round(float(base_rate), 4), "enrichment": 1.0},
    "enrichment_curve_auc_above_random": round(auc_enrich - 1.0, 3),
    "mean_auprc_by_third": [
        round(float(df["pesto_apo_pair_auprc"].iloc[: int(n / 3)].mean()), 4),
        round(float(df["pesto_apo_pair_auprc"].iloc[int(n / 3): 2 * int(n / 3)].mean()), 4),
        round(float(df["pesto_apo_pair_auprc"].iloc[2 * int(n / 3):].mean()), 4),
    ],
}

# ---------- 2) 分辨率分层（apo 侧） ----------
def res_group(r):
    if pd.isna(r):
        return "NMR（无分辨率）"
    r = float(r)
    if r <= 2.5:
        return "≤2.5 Å"
    if r <= 3.0:
        return "2.5–3.0 Å"
    return ">3.0 Å"

qc["res_group"] = qc["apo_resolution"].apply(res_group)
res_rows = []
for name, sub in qc.groupby("res_group"):
    rho = sub["global_ca_rmsd"].corr(sub["pesto_apo_pair_auprc"], method="spearman")
    res_rows.append({
        "组": name, "配对数": len(sub),
        "AUPRC 中位": round(float(sub["pesto_apo_pair_auprc"].median()), 3),
        "AUPRC 均值": round(float(sub["pesto_apo_pair_auprc"].mean()), 3),
        "组内 ρ（RMSD×AUPRC）": None if pd.isna(rho) else round(float(rho), 3),
        "分辨率中位": None if sub["apo_resolution"].isna().all() else round(float(sub["apo_resolution"].median()), 2),
    })
res_strata = pd.DataFrame(res_rows)

# ---------- 3) 跨方法逐对一致性（PeSTo vs GAPS） ----------
m = qc.merge(gaps[["pair_id", "gaps_auprc"]], on="pair_id", how="inner")
sp = m["pesto_apo_pair_auprc"].corr(m["gaps_auprc"], method="spearman")
kt = m["pesto_apo_pair_auprc"].corr(m["gaps_auprc"], method="kendall")
# 与 RMSD 的相关对比（方法间一致性检验的关键数字）
consistency = {
    "n_pairs": int(len(m)),
    "pesto_vs_gaps_spearman": round(float(sp), 3),
    "pesto_vs_gaps_kendall": round(float(kt), 3),
    "pesto_rmsd_spearman": round(float(m["pesto_apo_pair_auprc"].corr(m["global_ca_rmsd"], method="spearman")), 3),
    "gaps_rmsd_spearman": round(float(m["gaps_auprc"].corr(m["global_ca_rmsd"], method="spearman")), 3),
}

pd.DataFrame([tradeoff]).to_json(OUT / "tradeoff_curve.json", force_ascii=False, indent=1)
res_strata.to_csv(OUT / "resolution_strata.csv", index=False, encoding="utf-8-sig")
json.dump(consistency, open(OUT / "cross_method_consistency.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)

# ---------- 4) 图 S7：取舍/富集曲线 ----------
import sys
sys.path.insert(0, str(Path(sys.executable).parent.parent.parent))
from daimon_runtime import setup_plot
import matplotlib.pyplot as plt

setup_plot()
fig, ax = plt.subplots(figsize=(5.2, 3.6))
ax.plot(fracs, enrich, color="#c0392b", lw=2, label="按叠合 RMSD 排序的前置分诊")
ax.axhline(1.0, color="#7f8c8d", ls="--", lw=1, label="随机保留（基线）")
ax.axvline(1 / 3, color="#2c3e50", ls=":", lw=1)
ax.annotate(f"保留 1/3：富集 {tradeoff['at_third']['enrichment']}×\n命中率 {tradeoff['at_third']['hit_rate']:.3f}",
            xy=(1 / 3, tradeoff["at_third"]["enrichment"]),
            xytext=(0.42, tradeoff["at_third"]["enrichment"] + 0.25),
            fontsize=9, arrowprops=dict(arrowstyle="->", color="#2c3e50"))
ax.set_xlabel("保留的 apo 结构比例（按 apo–holo 叠合 RMSD 从低到高）")
ax.set_ylabel(f"命中率富集倍数（AUPRC ≥ {THRESH} 比例 / 全集基线）")
ax.set_title("前置分诊取舍曲线（83 对主基准）")
ax.legend(loc="upper right", fontsize=9)
ax.set_xlim(0, 1)
fig.tight_layout()
fig.savefig(FIG / "FigS7_triage_tradeoff.png", dpi=300, bbox_inches="tight")
print("tradeoff:", json.dumps(tradeoff, ensure_ascii=False))
print(res_strata.to_string())
print("consistency:", json.dumps(consistency, ensure_ascii=False))
print("fig written:", FIG / "FigS7_triage_tradeoff.png")
