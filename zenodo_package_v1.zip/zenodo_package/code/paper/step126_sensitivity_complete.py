# -*- coding: utf-8 -*-
"""Step126: 补全 P1-6 敏感性矩阵剩余两维。
(A) 侧链/全原子维度：对 83 对用全重原子 Kabsch 重算全局 RMSD（同一残基映射），与 Cα 口径的 ρ 对比。
(B) 备用 holo 选取规则：每个 apo 只保留一个结合态（RMSD 最小 / 最大两种规则，n=28），重算 ρ。
输出：results/Step126_sensitivity_complete/
"""
import json, sys, time
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(r"D:\hnnm\Metabolic_Inflammation_Functional_Interface")
OUT = ROOT / "results/Step126_sensitivity_complete"
OUT.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(ROOT / "code"))

qc = pd.read_csv(ROOT / "results/Step97_structure_qc/pair_structure_qc.csv")
disp = pd.read_csv(ROOT / "results/Step86_displacement/per_residue_displacement_v3.csv")

# record -> (holo pdb, partner chain)
rec_map = {}
for f in (ROOT / "data/processed/holo/interfaces").glob("*_residues.csv"):
    if f.stat().st_size < 10:
        continue
    df = pd.read_csv(f, usecols=["record_id", "pdb_id", "partner_chain"]).drop_duplicates("record_id")
    rec_map.update(dict(zip(df.record_id, zip(df.pdb_id, df.partner_chain))))
print("record map:", len(rec_map))

from Bio.PDB import MMCIFParser
from Bio.PDB.Polypeptide import is_aa

APO_DIR = ROOT / "data/raw/apo/structures"
HOLO_DIR = ROOT / "data/raw/pdb"
parser = MMCIFParser(QUIET=True)
_cache = {}


def load(pdb):
    pdb = pdb.lower()
    if pdb in _cache:
        return _cache[pdb]
    for d in (APO_DIR, HOLO_DIR):
        f = d / f"{pdb}.cif"
        if f.exists():
            s = parser.get_structure(pdb, str(f))[0]
            chains = {}
            for ch in s:
                reslist = [r for r in ch.get_residues() if is_aa(r, standard=True)]
                if reslist:
                    chains[ch.id] = reslist
            _cache[pdb] = chains
            return chains
    _cache[pdb] = None
    return None


def kabsch(a, b):
    ac = a - a.mean(0); bc = b - b.mean(0)
    u, s, vt = np.linalg.svd(ac.T @ bc)
    d = np.sign(np.linalg.det(u @ vt))
    rot = u @ np.diag([1, 1, d]) @ vt
    return float(np.sqrt(((ac @ rot - bc) ** 2).sum(1).mean()))


rows = []
t0 = time.time()
for qrow in qc.itertuples(index=False):
    rec, apo_pdb0, apo_chain = qrow.record_id, qrow.apo_pdb_id, qrow.apo_chain
    sub = disp[(disp.record_id == rec) & (disp.apo_pdb_id == apo_pdb0) & (disp.apo_chain == apo_chain)]
    apo_pdb = apo_pdb0.lower()
    holo_pdb, holo_chain = rec_map[rec]
    ca = load(apo_pdb); ch = load(holo_pdb.lower())
    if ca is None or ch is None or apo_chain not in ca or holo_chain not in ch:
        rows.append({"record_id": rec, "aa_rmsd": np.nan, "ca_rmsd_recomp": np.nan})
        continue
    aobs = ca[apo_chain]; hobs = ch[holo_chain]
    A, H, CA_A, CA_H = [], [], [], []
    for hp, ap in zip(sub.holo_position, sub.apo_position):
        if hp <= len(hobs) and ap <= len(aobs):
            hr, ar = hobs[hp - 1], aobs[ap - 1]
            ca_h = hr["CA"].coord if "CA" in hr else None
            ca_a = ar["CA"].coord if "CA" in ar else None
            if ca_h is not None and ca_a is not None:
                CA_H.append(ca_h); CA_A.append(ca_a)
            hnames = {a.get_name(): a.coord for a in hr if a.element != "H"}
            anames = {a.get_name(): a.coord for a in ar if a.element != "H"}
            common = sorted(set(hnames) & set(anames))
            for nm in common:
                H.append(hnames[nm]); A.append(anames[nm])
    r = {"record_id": rec, "apo_pdb_id": apo_pdb0, "apo_chain": apo_chain,
         "n_residues": len(CA_H), "n_atoms": len(H)}
    r["aa_rmsd"] = kabsch(np.array(H), np.array(A)) if len(H) >= 30 else np.nan
    r["ca_rmsd_recomp"] = kabsch(np.array(CA_H), np.array(CA_A)) if len(CA_H) >= 3 else np.nan
    rows.append(r)
    print(rec, apo_pdb0, apo_chain, "aa_rmsd", round(r["aa_rmsd"], 3), "ca", round(r["ca_rmsd_recomp"], 3),
          "nres", r["n_residues"], f"({time.time()-t0:.0f}s)", flush=True)

aa = pd.DataFrame(rows).merge(
    qc[["record_id", "apo_pdb_id", "apo_chain", "global_ca_rmsd", "pesto_apo_pair_auprc"]],
    on=["record_id", "apo_pdb_id", "apo_chain"])
aa.to_csv(OUT / "sidechain_rmsd_per_pair.csv", index=False)

valid = aa.dropna(subset=["aa_rmsd", "pesto_apo_pair_auprc"])
sidechain = {
    "n_pairs": int(len(valid)),
    "spearman_aa_rmsd_auprc": round(float(valid.aa_rmsd.corr(valid.pesto_apo_pair_auprc, method="spearman")), 3),
    "spearman_ca_rmsd_recomp_auprc": round(float(valid.ca_rmsd_recomp.corr(valid.pesto_apo_pair_auprc, method="spearman")), 3),
    "median_abs_diff_aa_vs_ca": round(float((valid.aa_rmsd - valid.global_ca_rmsd).abs().median()), 3),
}
(OUT / "sidechain_sensitivity.json").write_text(json.dumps(sidechain, ensure_ascii=False, indent=2), encoding="utf-8")
print("SIDECAHIN", sidechain)

# ---- (B) 备用 holo 选取规则：每个 apo 结构只保留一个结合态（28 个 apo） ----
res_b = {}
for rule in ("min_rmsd", "max_rmsd"):
    kept = qc.sort_values("global_ca_rmsd", ascending=(rule == "min_rmsd")).drop_duplicates("apo_pdb_id")
    rho = kept.global_ca_rmsd.corr(kept.pesto_apo_pair_auprc, method="spearman")
    apo_level = kept.groupby("apo_pdb_id").agg(rmsd=("global_ca_rmsd", "mean"), auprc=("pesto_apo_pair_auprc", "median"))
    res_b[rule] = {
        "n_pairs_kept": int(len(kept)),
        "n_apo_with_multi_holo": int((qc.apo_pdb_id.value_counts() > 1).sum()),
        "spearman_kept_rmsd_auprc": round(float(rho), 3),
        "apo_level_spearman": round(float(apo_level.rmsd.corr(apo_level.auprc, method="spearman")), 3),
        "median_auprc_kept": round(float(kept.pesto_apo_pair_auprc.median()), 3),
    }
(OUT / "holo_selection_rule.json").write_text(json.dumps(res_b, ensure_ascii=False, indent=2), encoding="utf-8")
print("HOLO RULE", json.dumps(res_b, ensure_ascii=False))
