# -*- coding: utf-8 -*-
"""Step125: 补充材料 docx 增补——表 S17（分辨率分层+取舍曲线）、表 S18（PeSTo 重叠审计）、图 S7（取舍曲线）。
新增内容全部标红；更新两个节标题的范围编号。"""
import copy, shutil, datetime, hashlib, pathlib
import docx
from docx.shared import RGBColor, Pt
from docx.oxml.ns import qn
from docx.text.paragraph import Paragraph

ROOT = pathlib.Path(r"D:\hnnm\Metabolic_Inflammation_Functional_Interface")
P = ROOT / "docs/paper/补充材料.docx"
FIG = ROOT / "docs/paper/figures/FigS7_triage_tradeoff.png"
BK = P.parent / "_revision_work"
stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
shutil.copy2(P, BK / f"si_backup_{stamp}.docx")
print("backup", stamp, hashlib.sha256(P.read_bytes()).hexdigest()[:12])

d = docx.Document(str(P))
RED = RGBColor(0xC0, 0x00, 0x00)
heading = next(p for p in d.paragraphs
               if p.style.name.startswith("Heading") and p.text.strip().startswith("补充图"))
tblPr_template = copy.deepcopy(d.tables[-1]._tbl.tblPr)


def make_caption(text):
    src = next(p for p in d.paragraphs if p.text.startswith("表 S16"))
    new_p = copy.deepcopy(src._p)
    for child in list(new_p):
        if child.tag == qn("w:r"):
            new_p.remove(child)
    para = Paragraph(new_p, src._parent)
    run = para.add_run(text)
    run.font.name = "宋体"
    run.font.color.rgb = RED
    rpr = run._element.get_or_add_rPr()
    rfonts = rpr.find(qn("w:rFonts"))
    if rfonts is None:
        rfonts = rpr.makeelement(qn("w:rFonts"), {}); rpr.insert(0, rfonts)
    rfonts.set(qn("w:eastAsia"), "宋体")
    return new_p


def make_table(data):
    rows, cols = len(data), max(len(r) for r in data)
    t = d.add_table(rows=rows, cols=cols)
    t.autofit = True
    t._tbl.replace(t._tbl.tblPr, copy.deepcopy(tblPr_template))
    for i, row in enumerate(data):
        for j in range(cols):
            val = row[j] if j < len(row) else ""
            para = t.cell(i, j).paragraphs[0]
            run = para.add_run(str(val))
            run.font.name = "Times New Roman"
            run.font.size = Pt(8)
            run.font.color.rgb = RED
            rpr = run._element.get_or_add_rPr()
            rfonts = rpr.find(qn("w:rFonts"))
            if rfonts is None:
                rfonts = rpr.makeelement(qn("w:rFonts"), {}); rpr.insert(0, rfonts)
            rfonts.set(qn("w:eastAsia"), "宋体")
    return t._tbl


# ---------------- 表 S17 ----------------
S17 = [
    ["（A）按 apo 结构分辨率分层（83 对）"],
    ["分层", "配对数", "AUPRC 中位", "AUPRC 均值", "组内 ρ（RMSD×AUPRC）", "分辨率中位（Å）", ""],
    ["≤2.5 Å", "28", "0.300", "0.289", "−0.056", "1.90", ""],
    ["2.5–3.0 Å", "19", "0.132", "0.144", "−0.130", "2.70", ""],
    [">3.0 Å", "27", "0.115", "0.141", "−0.140", "3.25", ""],
    ["NMR（无分辨率）", "9", "0.145", "0.154", "+0.118", "—", ""],
    ["注：分辨率与 AUPRC 整体相关 ρ = −0.563，与叠合 RMSD 相关 ρ = +0.244；组内相关均减弱，"
     "分辨率梯度部分由构象构成差异解释。", "", "", "", "", "", ""],
    ["（B）按叠合 RMSD 严格升序保留的取舍曲线（基线命中率 20.5%，阈值 AUPRC ≥ 0.30）"],
    ["保留比例", "命中率", "富集（×基线）", "备注", "", "", ""],
    ["1/3（最预成）", "29.6%", "1.45", "固定截断分层口径为 28.6%（1.40×），两口径一致", "", "", ""],
    ["1/2", "22.0%", "1.07", "", "", "", ""],
    ["2/3", "23.6%", "1.15", "", "", "", ""],
    ["全部", "20.5%", "1.00", "", "", "", ""],
    ["富集曲线相对随机保留的超额面积 AUC = 0.168；排序三分段平均 AUPRC = 0.248 / 0.158 / 0.175"
     "（第三段未继续下降）", "", "", "", "", "", ""],
]

# ---------------- 表 S18 ----------------
S18 = [
    ["（A）本文条目与 PeSTo 官方划分的重叠（按 PDB 条目标识）"],
    ["官方划分", "与 28 个 apo 条目重叠", "与 45 个 holo 条目重叠"],
    ["训练集", "7", "8"],
    ["验证集", "7", "5"],
    ["测试集", "1", "3"],
    ["（B）按是否暴露于官方划分分层后的配对级结果"],
    ["口径", "子集", "配对数", "ρ（RMSD×AUPRC）", "AUPRC 中位"],
    ["apo 条目∈训练集", "暴露", "22", "−0.188", "0.138"],
    ["", "未暴露", "61", "−0.395", "0.176"],
    ["apo 条目∈任一划分", "暴露", "43", "−0.283", "0.168"],
    ["", "未暴露", "40", "−0.433", "0.156"],
    ["判读", "两个口径下方向一致且未暴露子集效应量更大，配对级趋势并非由训练记忆化驱动", "", "", ""],
]

items = [
    make_caption("表 S17 敏感性补充。（A）apo 结构分辨率分层：高分层 AUPRC 更高，但组内 RMSD–AUPRC 相关减弱，"
                 "分辨率与可塑性构成混杂；（B）RMSD 严格排序的取舍曲线数字（图 S7 为相应曲线）。"),
    make_table(S17),
    make_caption("表 S18 PeSTo 官方训练划分的重叠审计。（A）本文 apo/holo 条目在 PeSTo 官方训练、验证、测试"
                 "划分中的出现情况；（B）按暴露与否分层后的配对级 Spearman 相关与 AUPRC 中位。原始清单见公开"
                 "数据集的 pesto_overlap_audit.json 与 overlap_stratified.json。"),
    make_table(S18),
]
for el in items:
    heading._p.addprevious(el)
print("tables inserted; total tables:", len(d.tables))

# ---------------- 节标题范围更新 ----------------
for p in d.paragraphs:
    t = p.text.strip()
    if t == "补充表（表 S1–表 S13）":
        for r in list(p.runs):
            r.text = ""
        p.runs[0].text = "补充表（表 S1–表 S18）"
    elif t == "补充图（图 S1–图 S3）":
        for r in list(p.runs):
            r.text = ""
        p.runs[0].text = "补充图（图 S1–图 S7）"
print("headings updated")

# ---------------- 图 S7：追加到文末 ----------------
cap_src = next(p for p in d.paragraphs if p.text.startswith("图 S3"))
new_p = copy.deepcopy(cap_src._p)
for child in list(new_p):
    if child.tag == qn("w:r"):
        new_p.remove(child)
d.paragraphs[-1]._p.addnext(new_p)
img_par = Paragraph(new_p, cap_src._parent)
run = img_par.add_run()
run.font.color.rgb = RED
run.add_picture(str(FIG), width=docx.shared.Cm(14))
d.save(str(P))

# 图注另起一段
d2 = docx.Document(str(P))
last = d2.paragraphs[-1]
cap2 = copy.deepcopy(cap_src._p)
for child in list(cap2):
    if child.tag == qn("w:r"):
        cap2.remove(child)
last._p.addnext(cap2)
cap_par = Paragraph(cap2, cap_src._parent)
r = cap_par.add_run("图 S7 前置分诊的取舍曲线。83 对按 apo–结合态叠合 RMSD 升序保留时，命中率（AUPRC ≥ 0.30 "
                    "的比例）随保留比例的变化（蓝），灰线为随机保留基线（20.5%）；富集曲线相对随机的超额面积 "
                    "AUC = 0.168。原始数据见 tradeoff_curve.json。")
r.font.name = "宋体"
r.font.color.rgb = RED
rpr = r._element.get_or_add_rPr()
rf = rpr.makeelement(qn("w:rFonts"), {}); rpr.insert(0, rf)
rf.set(qn("w:eastAsia"), "宋体")
d2.save(str(P))
print("figure S7 appended; size", P.stat().st_size)
