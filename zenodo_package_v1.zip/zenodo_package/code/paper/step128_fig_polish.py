# -*- coding: utf-8 -*-
"""Step128：图1 按 1–6 六步重绘；图5/S2 数字口径对齐正文；图S1 版式修正。"""
import importlib.util
import json
import textwrap
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.patches import Circle, FancyArrowPatch, Patch

ROOT = Path(r"D:\hnnm\Metabolic_Inflammation_Functional_Interface")
RES = ROOT / "results"

spec = importlib.util.spec_from_file_location("s127", ROOT / "code" / "paper" / "step127_figures_600dpi.py")
s127 = importlib.util.module_from_spec(spec)
spec.loader.exec_module(s127)
s120 = s127.s120
save600 = s127.save600
W = s120.W
FS, TICK = s120.FS, s120.TICK
T = s127.T
OUT = s127.OUT
PREV = s127.PREV


# ---------------- 图1：六步流程图 ----------------
def fig01(lang):
    fig = plt.figure(figsize=(W, 4.35))
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_xlim(0, 100); ax.set_ylim(0, 100); ax.axis("off")

    INK, GREY, HAIR, ACC, OK, NO = "#1b1b1b", "#5f5f5f", "#d7dade", "#2f5871", "#2c6b5a", "#8f4436"

    def card(x, y, w, h):
        ax.add_patch(plt.Rectangle((x, y), w, h, facecolor="white", edgecolor=HAIR, lw=0.5, zorder=1))

    def head(x, y, num, text):
        ax.add_patch(Circle((x + 1.6, y), 1.35, facecolor="white", edgecolor=HAIR, lw=0.6, zorder=3))
        ax.text(x + 1.6, y, str(num), ha="center", va="center", fontsize=TICK - 1, color=GREY, zorder=4)
        ax.text(x + 4.0, y, text, ha="left", va="center", fontsize=FS, color=INK, fontweight="bold", zorder=4)

    def lines(x, y, rows, dy=3.6, size=TICK):
        for k, s in enumerate(rows):
            ax.text(x, y - k * dy, s, ha="left", va="center", fontsize=size, color=INK)

    def arrow(x1, y1, x2, y2):
        ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2), arrowstyle="-|>", mutation_scale=7,
                                     lw=0.55, color="#9aa1a8", shrinkA=1, shrinkB=1, zorder=2))

    BS = TICK if lang == "zh" else TICK - 0.7
    CW, CH = 30.0, 32.0
    XS = [2.0, 35.0, 68.0]
    Y1, Y2 = 64.0, 28.0

    # 1 基准构建
    card(XS[0], Y1, CW, CH)
    head(XS[0] + 1.0, Y1 + CH - 4.5, "1", T("基准构建", "Benchmark construction", lang))
    lines(XS[0] + 2.0, Y1 + CH - 11.0, [
        T("代谢炎症蛋白–肽复合物", "metabolic-inflammation", lang),
        T("（PDB / BioLiP）", "protein–peptide complexes", lang),
        T("21 个家族 · 125 条受体记录", "21 families · 125 receptor records", lang),
        T("122 条可评价 → 30,325 窗口", "122 evaluable → 30,325 windows", lang),
        T("19,861 个逐残基位移标注", "19,861 per-residue displacements", lang),
    ], dy=4.0, size=BS)

    # 2 严格配对与评价设计
    card(XS[1], Y1, CW, CH)
    head(XS[1] + 1.0, Y1 + CH - 4.5, "2", T("严格配对与评价设计", "Strict pairing and design", lang))
    lines(XS[1] + 2.0, Y1 + CH - 11.0, [
        T("83 对 apo–holo（14 家族、", "83 apo–holo pairs (14 families,", lang),
        T("14 簇、28 个 apo、18,965 窗口）", "14 clusters, 28 apo, 18,965 windows)", lang),
        T("簇分组交叉验证 · 时间外测试", "cluster-grouped CV · temporal holdout", lang),
        T("预注册协议 · 多重比较校正", "pre-registration · multiplicity control", lang),
        T("扩样敏感性集 226 对 / 54,021 窗口", "expanded: 226 pairs / 54,021 windows", lang),
    ], dy=4.0, size=BS)

    # 3 界面位置定位
    card(XS[2], Y1, CW, CH)
    head(XS[2] + 1.0, Y1 + CH - 4.5, "3", T("界面位置定位", "Interface localization", lang))
    lines(XS[2] + 2.0, Y1 + CH - 11.0, [
        T("PeSTo 零训练 lift 1.25", "PeSTo zero-shot lift 1.25", lang),
        T("同配置监督基线 lift 1.64", "same-config supervised lift 1.64", lang),
        T("退化随 apo→holo 偏离增大", "degradation grows with deviation", lang),
        T("ρ = −0.336（Holm p = 0.006）", "ρ = −0.336 (Holm p = 0.006)", lang),
    ], dy=4.0, size=BS)
    ax.text(XS[2] + 2.0, Y1 + 3.6, T("结论：条件可计算", "verdict: conditionally computable", lang),
            fontsize=TICK, color=NO)

    # 4 残基可塑性排序
    card(XS[0], Y2, CW, CH)
    head(XS[0] + 1.0, Y2 + CH - 4.5, "4", T("残基可塑性排序", "Residue plasticity ranking", lang))
    lines(XS[0] + 2.0, Y2 + CH - 11.0, [
        T("87 维 apo 内在特征（无配体信息）", "87 apo-intrinsic features (no ligand)", lang),
        T("折外 lift 1.85（CI 1.69–2.04）", "out-of-fold lift 1.85 (CI 1.69–2.04)", lang),
        T("14/14 个家族方向一致", "14/14 families in the same direction", lang),
        T("时间外测试集不降（1.93）", "no drop in temporal holdout (1.93)", lang),
    ], dy=4.0, size=BS)
    ax.text(XS[0] + 2.0, Y2 + 3.6, T("结论：apo 上可计算", "verdict: computable on apo", lang),
            fontsize=TICK, color=OK)

    # 5 跨体系泛化验证
    card(XS[1], Y2, CW, CH)
    head(XS[1] + 1.0, Y2 + CH - 4.5, "5", T("跨体系泛化验证", "Cross-system generalization", lang))
    lines(XS[1] + 2.0, Y2 + CH - 11.0, [
        T("钙调蛋白 3 对 + 核受体 LBD 5 对", "calmodulin 3 + NR LBD 5 pairs", lang),
        T("8 对 · 1,710 残基 · 222 界面残基", "8 pairs · 1,710 residues · 222 interface", lang),
        T("结合态信号 8/8 高于 apo", "bound-state signal higher than apo in 8/8", lang),
        T("连同 BM5.5 九类 = 十二组对照", "with 9 BM5.5 classes = 12 contrasts", lang),
    ], dy=4.0, size=BS)

    # 6 可计算边界
    card(XS[2], Y2, CW, CH)
    head(XS[2] + 1.0, Y2 + CH - 4.5, "6", T("可计算边界", "Computable boundary", lang))
    lines(XS[2] + 2.0, Y2 + CH - 11.0, [
        T("界面位置：由 apo 与结合态的", "interface: set by apo–holo", lang),
        T("叠合 RMSD 决定", "superposition RMSD", lang),
        T("残基可塑性：只看残基所在的", "plasticity: set by the local", lang),
        T("局部几何环境", "geometric environment alone", lang),
    ], dy=4.0, size=BS)

    # 连接箭头
    for y in (Y1 + CH / 2, Y2 + CH / 2):
        arrow(XS[0] + CW + 0.2, y, XS[1] - 0.5, y)
        arrow(XS[1] + CW + 0.2, y, XS[2] - 0.5, y)
    arrow(XS[2] + CW / 2, Y1 - 0.6, XS[2] + CW / 2, Y2 + CH + 0.5)
    arrow(XS[0] + CW / 2, Y1 - 0.6, XS[0] + CW / 2, Y2 + CH + 0.5)

    # 底部结论带
    ax.plot([2, 98], [22.0, 22.0], lw=0.4, color=HAIR)
    ax.text(2.0, 17.5, T("判据", "Criterion", lang), fontsize=FS, fontweight="bold", color=INK)
    body = [
        (T("界面能否在 apo 单结构上判准，取决于该 apo 离结合态有多远；残基是否会重排，只取决于残基所处的局部几何。",
           "Whether an interface can be read from an apo structure depends on how far that apo sits from the bound state; whether a residue rearranges depends only on its local geometry.", lang), INK),
        (T("83 对基准、226 对扩样集、预注册协议与代码随文公开，可作为同类方法的评价集。",
           "The 83-pair benchmark, 226-pair expanded set, pre-registration and code are released as an evaluation resource.", lang), GREY),
    ]
    yy = 12.6
    for s, c in body:
        for seg in textwrap.wrap(s, 62 if lang == "zh" else 96):
            ax.text(2.0, yy, seg, fontsize=TICK, color=c)
            yy -= 4.3

    save600(fig, "Fig1_overview", lang)


# ---------------- 图5：突变数口径 ----------------
def fig06(lang):
    r95 = json.load(open(RES / "Step95_plasticity_ddg/step95_result.json", encoding="utf-8"))
    r07 = json.load(open(RES / "Step07_multitask_skempi/multitask_summary.json", encoding="utf-8"))
    A = r95["dev_complex_isolated"]["A_baseline"]
    B = r95["dev_complex_isolated"]["B_plus_plasticity"]
    tgt = r95["independent_metabolic_target"]

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(W, 2.85), gridspec_kw={"width_ratios": [1, 1.1]})
    x = np.arange(2); w = 0.34
    cA, cB = "#4a6fa5", "#c0504d"
    b1 = ax1.bar(x - w / 2, [A["spearman"], A["hotspot_auc"]], w, color=cA, edgecolor="white")
    b2 = ax1.bar(x + w / 2, [B["spearman"], B["hotspot_auc"]], w, color=cB, edgecolor="white")
    for bars in (b1, b2):
        for b in bars:
            ax1.text(b.get_x() + b.get_width() / 2, b.get_height() + 0.012, f"{b.get_height():.3f}",
                     ha="center", fontsize=TICK)
    ax1.set_xticks(x)
    ax1.set_xticklabels([T("ΔΔG 排序\n（Spearman ρ）", "ΔΔG ranking\n(Spearman ρ)", lang),
                         T("热点判别\n（AUC）", "Hotspot discrimination\n(AUC)", lang)])
    ax1.set_ylabel(T("性能（复合物隔离）", "Performance (complex-isolated)", lang))
    ax1.set_title(T("A  SKEMPI ΔΔG（4,166 条映射，评价 4,129 条）",
                    "A  SKEMPI ΔΔG (4,166 mapped, 4,129 evaluated)", lang), loc="left")
    ax1.legend(handles=[Patch(facecolor=cA, edgecolor="white", label=T("基线（窗口+残基特征）", "Baseline (window + residue features)", lang)),
                        Patch(facecolor=cB, edgecolor="white", label=T("+ apo 可塑性", "+ apo-derived plasticity", lang))],
               frameon=False, loc="upper left", ncol=2, columnspacing=1.0,
               handlelength=1.2, handleheight=0.9, borderaxespad=0.2)
    ax1.set_ylim(0, 1.15)
    ax1.spines[["top", "right"]].set_visible(False)

    names = [T("单任务\n基线", "Single-task\nbaseline", lang), T("单任务\n+ 可塑性", "Single-task\n+ plasticity", lang),
             T("多任务\n（功能头）", "Multitask\n(function head)", lang), T("多任务\n（接触头）", "Multitask\n(contact head)", lang)]
    vals = [tgt["A_baseline"]["hotspot_auc"], tgt["B_plus_plasticity"]["hotspot_auc"],
            r07["independent_metabolic_mutations"]["multitask"]["hotspot_AUC"],
            r07["independent_metabolic_mutations"]["function_only"]["hotspot_AUC"]]
    colors = ["#4a6fa5", "#c0504d", "#7a9a58", "#b08a3e"]
    bars = ax2.bar(range(4), vals, color=colors, edgecolor="white", width=0.62)
    for b, v in zip(bars, vals):
        ax2.text(b.get_x() + b.get_width() / 2, v + 0.015, f"{v:.3f}", ha="center", fontsize=TICK)
    ax2.axhline(0.5, ls="--", lw=0.8, color="grey", label=T("随机（0.5）", "chance (0.5)", lang))
    ax2.legend(frameon=False, loc="upper right")
    ax2.set_xticks(range(4)); ax2.set_xticklabels(names)
    ax2.set_ylim(0, 1.12); ax2.set_ylabel("Hotspot AUC")
    ax2.set_title(T("B  独立代谢靶点（37 个突变）", "B  Independent metabolic targets (37 mutations)", lang), loc="left")
    ax2.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    save600(fig, "Fig7_functional_boundary", lang)


# ---------------- 图S2：覆盖率口径 ----------------
def figS3(lang):
    r91 = json.load(open(RES / "Step91_d_support/d_support_result.json", encoding="utf-8"))
    methods = [T("仅序列\n(52 特征)", "Sequence only\n(52 feat.)", lang),
               T("PeSTo\n(零训练)", "PeSTo\n(zero-shot)", lang),
               T("监督\n(87 特征)", "Supervised\n(87 feat.)", lang)]
    lift = [1.33, 1.25, 1.64]
    cov = [100, 44, 44]

    fig, axes = plt.subplots(1, 2, figsize=(W, 2.6))
    ax = axes[0]
    bars = ax.bar(range(3), lift, color=["#8bc49a", "#8a8ad9", "#4a90d9"], edgecolor="white", width=0.55)
    for b, l, c in zip(bars, lift, cov):
        x = b.get_x() + b.get_width() / 2
        ax.text(x, l + 0.02, f"lift {l:.2f}\n" + T("覆盖 ", "coverage ", lang) + f"{c}%",
                ha="center", va="bottom", fontsize=TICK)
    ax.axhline(1.0, color="gray", ls=":", lw=0.8)
    ax.set_xticks(range(3)); ax.set_xticklabels(methods)
    ax.set_ylabel(T("OOF AUPRC lift（apo 界面任务）", "OOF AUPRC lift (apo interface task)", lang))
    ax.set_title(T("A  方法与覆盖度权衡", "A  Method × coverage tradeoff", lang), loc="left")
    ax.set_ylim(0.8, 2.05)

    ax = axes[1]
    db = r91["D_b_apo_availability_bias"]
    meth = db["experimental_method_pct"]
    cats = ["X-RAY DIFFRACTION", "ELECTRON MICROSCOPY", "SOLUTION NMR"]
    cov_yes = [meth[c]["true"] * 100 for c in cats]
    cov_no = [meth[c]["false"] * 100 for c in cats]
    x = np.arange(3)
    ax.bar(x - 0.19, cov_yes, 0.38, label=T("有同源 apo（54 条）", "with cognate apo (n=54)", lang),
           color="#4a90d9")
    ax.bar(x + 0.19, cov_no, 0.38, label=T("无同源 apo（71 条）", "without cognate apo (n=71)", lang),
           color="#c9c9c9")
    for i in range(3):
        ax.text(i - 0.19, cov_yes[i] + 1.4, f"{cov_yes[i]:.0f}%", ha="center", fontsize=TICK)
        ax.text(i + 0.19, cov_no[i] + 1.4, f"{cov_no[i]:.0f}%", ha="center", fontsize=TICK)
    ax.set_xticks(x); ax.set_xticklabels(["X-ray", "cryo-EM", "NMR"])
    ax.set_ylabel(T("各组内占比（%）", "% within each group", lang))
    ax.set_title(T("B  按实验方法的 apo 可获得性", "B  apo availability by method", lang), loc="left")
    ax.legend(frameon=False, loc="upper left", fontsize=TICK - 1)
    ax.set_ylim(0, 92)
    fig.tight_layout()
    save600(fig, "Fig6_R5_coverage", lang)


# ---------------- 图S1：取舍曲线版式 ----------------
def figS1(lang):
    qc = pd.read_csv(RES / "Step97_structure_qc/pair_structure_qc.csv")
    qc["pair_id"] = qc["record_id"] + "__" + qc["apo_pdb_id"].str.lower()
    TH = 0.30
    df = qc[["pair_id", "global_ca_rmsd", "pesto_apo_pair_auprc", "dataset"]].dropna()
    df = df.sort_values("global_ca_rmsd").reset_index(drop=True)
    n = len(df)
    hit = (df["pesto_apo_pair_auprc"] >= TH).astype(int)
    base = hit.mean()
    fracs = np.arange(1, n + 1) / n
    cum = np.cumsum(hit) / np.arange(1, n + 1)
    enrich = cum / base
    e_third, e_half = enrich[int(n / 3) - 1], enrich[int(n / 2) - 1]

    fig, ax = plt.subplots(figsize=(W, 3.0))
    ax.plot(fracs, enrich, color="#c0392b", lw=1.3,
            label=T("按叠合 RMSD 排序的前置分诊", "triage ranked by superposition RMSD", lang))
    ax.axhline(1.0, color="#7f8c8d", ls="--", lw=0.8,
               label=T("随机保留（基线）", "random retention (baseline)", lang))
    ax.axvline(1 / 3, color="#2c3e50", ls=":", lw=0.8)
    ax.axvline(0.5, color="#2c3e50", ls="-.", lw=0.8)
    ax.text(0.40, 2.62, T(f"保留 1/3：{e_third:.2f}×", f"top 1/3: {e_third:.2f}×", lang),
            fontsize=TICK, color="#2c3e50", ha="left", va="bottom", bbox=dict(facecolor="white", edgecolor="none", pad=1.6))
    ax.text(0.56, 1.52, T(f"保留 1/2：{e_half:.2f}×", f"top 1/2: {e_half:.2f}×", lang),
            fontsize=TICK, color="#2c3e50", ha="left", va="bottom", bbox=dict(facecolor="white", edgecolor="none", pad=1.6))
    ax.set_xlabel(T("保留的 apo 结构比例（按 apo–holo 叠合 RMSD 从低到高）",
                    "fraction of apo structures retained (low to high apo–holo RMSD)", lang))
    ax.set_ylabel(T(f"命中率富集倍数（相对基线 {base:.3f}）",
                    f"hit-rate enrichment (vs baseline {base:.3f})", lang))
    ax.set_title(T("前置分诊的取舍曲线（83 对主基准）", "Triage trade-off curve (83-pair main set)", lang),
                 loc="left", pad=6)
    ax.set_xlim(0, 1)
    ax.set_ylim(0.85, max(5.2, enrich.max() + 0.35))
    ax.legend(frameon=False, loc="upper right")
    fig.tight_layout()
    save600(fig, "FigS7_triage_tradeoff", lang)


# ---------------- 图S4：构象偏离分布（图例避让） ----------------
def figS4(lang):
    ours = pd.read_csv(RES / "Step82_h1_prereg/pair_level_table.csv")
    ours_g = ours["preformation_aligned"].astype(float)
    ours_i = ours["preformation_iface_rmsd"].astype(float)
    bm = pd.read_csv(RES / "Step65_pesto_zero_training_reanalysis/pesto_per_complex_conformation_mechanism.csv")
    bm_i = bm["local_interface_CA_RMSD"].astype(float)

    fig, axes = plt.subplots(1, 2, figsize=(W, 2.95))
    ax = axes[0]
    ax.hist(ours_g, bins=18, density=True, alpha=0.55, color="#c0392b",
            label=T(f"本数据 {len(ours_g)} 对（全局 RMSD）",
                    f"this dataset ({len(ours_g)} pairs, global RMSD)", lang))
    ax.hist(bm_i, bins=30, density=True, alpha=0.45, color="#2980b9",
            label=T(f"BM5.5 {len(bm_i)} 复合物（局域界面 RMSD）",
                    f"BM5.5 ({len(bm_i)} complexes, local interface RMSD)", lang))
    ax.axvline(np.median(ours_g), color="#c0392b", ls="--", lw=0.8)
    ax.axvline(np.median(bm_i), color="#2980b9", ls="--", lw=0.8)
    ax.set_xlabel(T("叠合 RMSD（Å）", "Superposition RMSD (Å)", lang))
    ax.set_ylabel(T("密度", "Density", lang))
    ax.set_title(T("A  构象偏离分布：本数据 vs BM5.5", "A  Deviation distribution: this dataset vs BM5.5", lang), loc="left")
    ax.set_ylim(0, 0.80)
    ax.legend(frameon=False, loc="upper right", fontsize=TICK - 1)

    ax = axes[1]
    ax.hist(ours_i, bins=18, density=True, alpha=0.55, color="#c0392b",
            label=T("本数据（局域界面 RMSD）", "this dataset (local interface RMSD)", lang))
    ax.hist(bm_i, bins=30, density=True, alpha=0.45, color="#2980b9",
            label=T("BM5.5（局域界面 RMSD）", "BM5.5 (local interface RMSD)", lang))
    ax.axvline(np.median(ours_i), color="#c0392b", ls="--", lw=0.8)
    ax.axvline(np.median(bm_i), color="#2980b9", ls="--", lw=0.8)
    ax.set_xlabel(T("局域界面 RMSD（Å）", "Local interface RMSD (Å)", lang))
    ax.set_ylabel(T("密度", "Density", lang))
    ax.set_title(T("B  同口径对比", "B  Like-for-like comparison", lang), loc="left")
    ax.legend(frameon=False, loc="upper right", fontsize=TICK - 1)
    fig.tight_layout()
    save600(fig, "Fig9_BM55_rmsd_distribution", lang)


if __name__ == "__main__":
    for lang in ("zh", "en"):
        s127.setup(lang)
        for f in (fig01, fig06, figS3, figS1, figS4):
            try:
                f(lang)
            except Exception as e:
                print("FAIL", f.__name__, lang, type(e).__name__, e)
    print("done")


