# -*- coding: utf-8 -*-
"""step148: Fig.1 重设计 —— 标题带 + 编号徽章 + 矢量图标 + 关键数字高亮。

覆盖输出 600 dpi TIFF（zh/en）+ 150 dpi 预览 PNG。
所有数字沿用已核对文本，不得新增。
"""
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Circle, Ellipse, Polygon, Rectangle

ROOT = Path(r"D:\hnnm\Metabolic_Inflammation_Functional_Interface")
OUT = ROOT / "docs" / "paper" / "figures_tiff"
PREV = ROOT / "docs" / "paper" / "_revision_work" / "fig_preview"
PREV.mkdir(parents=True, exist_ok=True)

INK = "#1c3550"      # 深海军蓝
GREY = "#4a5a68"
LINE = "#9fb2c2"

FS = 10.5    # 框标题
TICK = 7.8   # 正文行
BIG = 14.0   # 关键数字

def T(zh, en, lang):
    return zh if lang == "zh" else en

def setup(lang):
    if lang == "zh":
        plt.rcParams["font.family"] = ["Microsoft YaHei", "SimHei", "SimSun"]
    else:
        plt.rcParams["font.family"] = ["Times New Roman", "Arial"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["savefig.dpi"] = 600

# ---------------- 图标（纯矢量） ----------------

def icon_db(ax, cx, cy, r, c):
    w, h = 1.5 * r, 0.42 * r
    ax.add_patch(Rectangle((cx - w / 2, cy - h), w, 2 * h, fc="white", ec=c, lw=1.1, zorder=4))
    ax.add_patch(Ellipse((cx, cy + h), w, 2 * h * 0.62, fc="white", ec=c, lw=1.1, zorder=4))
    ax.add_patch(Ellipse((cx, cy), w, 2 * h * 0.62, fc="none", ec=c, lw=0.8))
    ax.add_patch(Ellipse((cx, cy - h), w, 2 * h * 0.62, fc="none", ec=c, lw=0.8))

def icon_layers(ax, cx, cy, r, c):
    for dy in (0.55 * r, 0.0, -0.55 * r):
        yy = cy + dy
        ax.add_patch(Polygon([(cx, yy + 0.42 * r), (cx + 0.95 * r, yy),
                              (cx, yy - 0.42 * r), (cx - 0.95 * r, yy)],
                             closed=True, fc="white", ec=c, lw=1.0, zorder=4))

def icon_shield(ax, cx, cy, r, c):
    pts = [(cx - 0.85 * r, cy + 0.62 * r), (cx + 0.85 * r, cy + 0.62 * r),
           (cx + 0.85 * r, cy - 0.05 * r), (cx, cy - 0.95 * r),
           (cx - 0.85 * r, cy - 0.05 * r)]
    ax.add_patch(Polygon(pts, closed=True, fc="white", ec=c, lw=1.1, zorder=4))
    ax.plot([cx - 0.42 * r, cx - 0.10 * r, cx + 0.48 * r],
            [cy + 0.05 * r, cy - 0.30 * r, cy + 0.38 * r], color=c, lw=1.4, solid_capstyle="round")

def icon_target(ax, cx, cy, r, c):
    ax.add_patch(Circle((cx, cy), 0.9 * r, fc="white", ec=c, lw=1.1, zorder=4))
    ax.add_patch(Circle((cx, cy), 0.52 * r, fc="none", ec=c, lw=1.0))
    ax.add_patch(Circle((cx, cy), 0.16 * r, fc=c, ec=c, zorder=4))

def icon_wave(ax, cx, cy, r, c):
    x = np.linspace(cx - 0.95 * r, cx + 0.95 * r, 80)
    y = cy + 0.45 * r * np.sin((x - cx) / r * 2.4)
    ax.plot(x, y, color=c, lw=1.5, solid_capstyle="round")
    ax.plot([cx - 0.95 * r, cx + 0.95 * r], [cy - 0.75 * r, cy - 0.75 * r],
            color=c, lw=0.8, ls=(0, (2, 2)), zorder=4)

def icon_fence(ax, cx, cy, r, c):
    ax.plot([cx, cx], [cy - 0.85 * r, cy + 0.85 * r], color=c, lw=1.6,
            ls=(0, (3, 2)), solid_capstyle="round")
    for dx in (-0.62, 0.62):
        ax.add_patch(Circle((cx + dx * r, cy), 0.20 * r, fc=c, ec=c, zorder=4))

def icon_net(ax, cx, cy, r, c):
    nodes = [(cx - 0.62 * r, cy + 0.45 * r), (cx + 0.62 * r, cy + 0.45 * r),
             (cx - 0.62 * r, cy - 0.45 * r), (cx + 0.62 * r, cy - 0.45 * r)]
    for i, (x1, y1) in enumerate(nodes):
        for (x2, y2) in nodes[i + 1:]:
            ax.plot([x1, x2], [y1, y2], color=c, lw=0.7, alpha=0.7, zorder=4)
    for (x, y) in nodes:
        ax.add_patch(Circle((x, y), 0.22 * r, fc="white", ec=c, lw=1.1, zorder=4))

def icon_flag(ax, cx, cy, r, c):
    ax.plot([cx - 0.55 * r, cx - 0.55 * r], [cy - 0.85 * r, cy + 0.85 * r], color=c, lw=1.5, zorder=4)
    ax.add_patch(Polygon([(cx - 0.55 * r, cy + 0.85 * r), (cx + 0.70 * r, cy + 0.45 * r),
                          (cx - 0.55 * r, cy + 0.05 * r)], closed=True, fc=c, ec=c, lw=0.8, zorder=4))

ICONS = {"db": icon_db, "layers": icon_layers, "shield": icon_shield,
         "target": icon_target, "wave": icon_wave, "fence": icon_fence,
         "net": icon_net, "flag": icon_flag}

# ---------------- 版式元件 ----------------

def panel(ax, x, y, w, h, accent, fill):
    ax.add_patch(FancyBboxPatch((x + 0.45, y - 0.55), w, h,
                                boxstyle="round,pad=0,rounding_size=1.4",
                                fc="#10273f", ec="none", alpha=0.10, zorder=1))
    ax.add_patch(FancyBboxPatch((x, y), w, h,
                                boxstyle="round,pad=0,rounding_size=1.4",
                                fc=fill, ec=accent, lw=1.2, zorder=2))
    ax.add_patch(FancyBboxPatch((x + 0.7, y + h - 1.15), w - 1.4, 0.55,
                                boxstyle="round,pad=0,rounding_size=0.27",
                                fc=accent, ec="none", alpha=0.85, zorder=3))

def header(ax, x, y, w, num, title, accent, icon, lang, title_fs=FS,
           icon_dx=2.6, icon_r=1.45):
    """编号徽章 + 标题（左对齐），图标放面板右上角。"""
    r = 2.0
    cx = x + 3.3
    ax.add_patch(Circle((cx, y), r, fc=accent, ec="white", lw=1.2, zorder=6))
    ax.text(cx, y, num, ha="center", va="center", fontsize=9,
            fontweight="bold", color="white", zorder=7)
    ax.text(cx + r + 1.6, y, title, fontsize=title_fs, fontweight="bold",
            color=accent, va="center", zorder=7)
    if icon:
        ICONS[icon](ax, x + w - icon_dx, y, icon_r, accent)

def metric(ax, x, y, w, value, label, accent):
    """关键数字带：灰标签在左，大数字右对齐，互不重叠。"""
    ax.text(x + 1.2, y, label, fontsize=7.4, color=GREY, va="center", ha="left")
    ax.text(x + w - 1.4, y, value, fontsize=BIG, fontweight="bold",
            color=accent, va="center", ha="right")

def lines(ax, x, y, items, step=4.3, fs=TICK, bullet=True):
    for i, it in enumerate(items):
        yy = y - i * step
        if bullet:
            ax.plot([x + 0.6, x + 1.9], [yy, yy], color=LINE, lw=1.1,
                    solid_capstyle="round")
            ax.text(x + 2.8, yy, it, fontsize=fs, color=INK, va="center")
        else:
            ax.text(x, yy, it, fontsize=fs, color=INK, va="center")

def takeaway(ax, x, w, y, text, accent):
    """框底部分隔线 + 一句加粗启示。"""
    ax.plot([x + 1.2, x + w - 1.2], [y + 2.2, y + 2.2], color=accent, lw=0.8, alpha=0.45)
    ax.text(x + 1.2, y, text, fontsize=8.0, fontweight="bold", color=accent, va="center")

def arrow(ax, x1, y1, x2, y2, color=LINE, lw=1.4):
    ax.annotate("", xy=(x2, y2), xytext=(x1, y1),
                arrowprops=dict(arrowstyle="-|>", color=color, lw=lw,
                                shrinkA=0, shrinkB=0,
                                mutation_scale=13), zorder=4)

# ---------------- 主图 ----------------

def fig01(lang):
    fig, ax = plt.subplots(figsize=(7.2, 8.55))
    ax.set_xlim(0, 100); ax.set_ylim(0, 119)
    ax.axis("off")

    C1, F1 = "#2f6b9e", "#eef4fb"   # 数据蓝
    C2, F2 = "#a4443a", "#faf0ee"   # 任务一 红
    C3, F3 = "#2e6e5c", "#edf6f1"   # 任务二 绿
    C4, F4 = "#96702a", "#fbf4e4"   # 任务三 琥珀
    C5, F5 = "#6e6a25", "#f7f5e1"   # 泛化 橄榄
    C6, F6 = "#4c3d78", "#f0ecf8"   # 边界 紫

    # ---- 标题带 ----
    ax.add_patch(FancyBboxPatch((0.8, 110.2), 98.4, 8.2,
                                boxstyle="round,pad=0,rounding_size=1.2",
                                fc=INK, ec="none", zorder=2))
    ax.text(50, 116.4, T("诱导契合的可计算边界：apo 结构上界面定位与可塑性预测的系统评价",
                         "The Computable Boundary of Induced Fit: Interface and Plasticity "
                         "Prediction on apo Structures", lang),
            ha="center", va="center", fontsize=T(10.6, 8.8, lang), fontweight="bold", color="white")
    ax.text(50, 112.6, T("83 对 apo–holo · 21 家族 · 同源簇交叉验证 · 时间外测试 · 跨方法复现（ScanNet / GAPS）",
                         "83 apo–holo pairs · 21 families · homology-cluster CV · temporal holdout · "
                         "cross-method replication (ScanNet / GAPS)", lang),
            ha="center", va="center", fontsize=7.6, color="#c8d6e4")

    # ---- 第一排：数据、基准、评价设计 ----
    r1y, r1h = 82.5, 24.5
    for x, w in ((1, 32), (34, 32), (67, 32)):
        panel(ax, x, r1y, w, r1h, C1, F1)

    y = r1y + r1h - 3.4
    header(ax, 1, y, 32, "1", T("配对数据", "Paired data", lang), C1, "db", lang, 10.0)
    lines(ax, 1, y - 4.9, [T("21 家族 · 125 条记录", "21 families · 125 records", lang),
                           T("122 对可评价", "122 evaluable pairs", lang),
                           T("30,325 窗口 · 19,861 位移标注", "30,325 windows · 19,861 labels", lang)],
          step=4.5, fs=7.8)

    header(ax, 34, y, 32, "2", T("扩样与时间外集", "Expanded datasets", lang), C1, "layers", lang, 10.0)
    lines(ax, 34, y - 4.9, [T("83 对 · 28 apo · 18,965 窗口", "83 pairs · 28 apo · 18,965 windows", lang),
                            T("14 家族 = 14 同源簇", "14 families = 14 clusters", lang),
                            T("226 对 · 54,021 窗口（敏感性）", "226 pairs · 54,021 windows", lang),
                            T("时间外：2024 年后发表结构", "Temporal: post-2024 structures", lang)],
          step=4.5, fs=7.8)

    header(ax, 67, y, 32, "3", T("评价设计", "Evaluation design", lang), C1, "shield", lang, 10.0)
    lines(ax, 67, y - 4.9, [T("同源簇 GroupKFold 交叉验证", "Homology-cluster GroupKFold CV", lang),
                            T("预注册确认性协议（Holm）", "Preregistered protocols (Holm)", lang),
                            T("簇块 bootstrap · 混合模型", "Cluster bootstrap · mixed models", lang),
                            T("留一 apo · 块置换（n = 28）", "Leave-one-apo-out (n = 28)", lang)],
          step=4.5, fs=7.8)

    # ---- 第二排：三个任务 ----
    r2y, r2h = 33.5, 43.5
    for x, cc, ff in ((1, C2, F2), (34, C3, F3), (67, C4, F4)):
        panel(ax, x, r2y, 32, r2h, cc, ff)

    y = r2y + r2h - 3.4
    header(ax, 1, y, 32, "4", T("任务一：界面定位", "Task 1: localization", lang), C2, "target", lang, 8.8, icon_dx=2.2, icon_r=1.3)
    metric(ax, 1, y - 6.4, 32, "1.25", T("PeSTo 零训练 lift", "PeSTo zero-shot lift", lang), C2)
    lines(ax, 1, y - 12.0, [T("监督基线 1.64 · BM5.5 3.22", "Supervised 1.64 · BM5.5 3.22", lang),
                            T("退化随 RMSD 增大，ρ = −0.336", "Decays with RMSD, ρ = −0.336", lang),
                            T("分诊命中率富集 ~1.4 倍", "Triage enriches hits ~1.4×", lang),
                            T("ScanNet 复现，ρ = −0.486", "ScanNet replicates, ρ = −0.486", lang),
                            T("GAPS 近随机，AUC 0.509", "GAPS near-random, AUC 0.509", lang)],
          step=4.4, fs=7.8)
    takeaway(ax, 1, 32, r2y + 4.3, T("启示：apo 可用性由叠合质量决定", "Implication: usability set by RMSD", lang), C2)

    header(ax, 34, y, 32, "5", T("任务二：可塑性排序", "Task 2: plasticity", lang), C3, "wave", lang, 8.8, icon_dx=2.2, icon_r=1.3)
    metric(ax, 34, y - 6.4, 32, "1.85", T("折外 lift，CI 1.69–2.04", "Out-of-fold lift, 1.69–2.04", lang), C3)
    lines(ax, 34, y - 12.0, [T("87 维 apo 内在特征", "87 apo intrinsic features", lang),
                             T("14/14 家族方向一致", "14/14 families concordant", lang),
                             T("时间外测试集性能不降", "Stable on temporal holdout", lang),
                             T("ANM 柔性无解释力，ρ = 0.049", "ANM uninformative, ρ = 0.049", lang),
                             T("界面残基非整体更易动", "Interfaces not more mobile", lang)],
          step=4.4, fs=7.8)
    takeaway(ax, 34, 32, r2y + 4.3, T("启示：可塑性不依赖结合态结构", "Implication: no holo needed", lang), C3)

    header(ax, 67, y, 32, "6", T("任务三：功能边界", "Task 3: boundary", lang), C4, "fence", lang, 8.8, icon_dx=2.2, icon_r=1.3)
    metric(ax, 67, y - 6.4, 32, "+0.007", T("SKEMPI ΔΔG 增量", "SKEMPI ΔΔG gain", lang), C4)
    lines(ax, 67, y - 12.0, [T("疾病变异无界面富集", "Variants not enriched", lang),
                             T("OR 1.10 · p = 0.82", "OR 1.10 · p = 0.82", lang),
                             T("界面 6 变异均有机制注释", "6 interface variants annotated", lang),
                             T("信号限于几何层面", "Signal is geometric only", lang)],
          step=4.4, fs=7.8)
    takeaway(ax, 67, 32, r2y + 4.3, T("启示：几何可测 ≠ 功能可解释", "Implication: geometry ≠ function", lang), C4)

    # ---- 第三排：泛化验证 + 可计算边界 ----
    r3y, r3h = 3.0, 24.5
    panel(ax, 1, r3y, 63, r3h, C5, F5)
    panel(ax, 67, r3y, 32, r3h, C6, F6)

    y = r3y + r3h - 3.4
    header(ax, 1, y, 63, "7", T("跨体系检验", "Cross-system test", lang), C5, "net", lang, 10.0)
    lines(ax, 1, y - 4.9, [T("钙调蛋白 3 对 + 核受体 LBD 5 对：结合态信号 8/8 高于 apo",
                            "CaM 3 + NR LBD 5 pairs: holo signal higher 8/8", lang),
                           T("apo 按界面是否成形分层：AUC 0.32–0.78 · lift 0.81–5.63",
                            "apo stratified by pocket: AUC 0.32–0.78 · lift 0.81–5.63", lang),
                           T("连同 BM5.5 九类 → 十二组对照，覆盖预成–重排连续谱",
                            "With BM5.5 (9 classes): 12 groups, preformed → rearranged", lang)],
          step=4.5, fs=7.8)

    header(ax, 67, y, 32, "8", T("可计算边界", "Computable boundary", lang), C6, None, lang, 10.0)
    lines(ax, 67.6, y - 5.6, [T("界面定位：条件可计算", "Interfaces: conditional,", lang),
                              T("由 apo–holo RMSD 决定", "set by apo–holo RMSD", lang),
                              T("可塑性：apo 几何直接可读", "Plasticity: from apo geometry", lang)],
          step=5.6, fs=7.8, bullet=False)

    # ---- 连接线 ----
    for x in (17, 50, 83):
        arrow(ax, x, r1y - 0.4, x, r2y + r2h + 0.4)
    arrow(ax, 17, r2y - 0.4, 24, r3y + r3h + 0.4)
    arrow(ax, 50, r2y - 0.4, 44, r3y + r3h + 0.4)
    arrow(ax, 83, r2y - 0.4, 83, r3y + r3h + 0.4)
    arrow(ax, 64.6, r3y + r3h / 2, 66.4, r3y + r3h / 2, color="#8a86a8")

    d = OUT / lang
    d.mkdir(parents=True, exist_ok=True)
    p = d / f"Fig1_overview_{lang}.tiff"
    fig.savefig(p, pil_kwargs={"compression": "tiff_lzw"})
    fig.savefig(PREV / f"Fig1_overview_{lang}.png", dpi=150)
    plt.close(fig)
    print("saved", p)


for lang in ("zh", "en"):
    setup(lang)
    fig01(lang)
