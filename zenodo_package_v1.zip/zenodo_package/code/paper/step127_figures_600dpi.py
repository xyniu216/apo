# -*- coding: utf-8 -*-
"""Step127：按正文/补充材料最终图序重出 600 dpi TIFF。

图序（正文 5 张 + 补充 4 张）：
  Fig1_overview                 图1 研究流程
  Fig2_failure_mechanism        图2 失败机制（配对级 RMSD–AUPRC + 十分位剂量反应）
  Fig3_overlay_preformed_plastic 图3 预成/可塑界面三维叠加
  Fig4_plasticity_prediction    图4 可塑性预测（特征消融 + 逐家族）
  Fig5_functional_boundary      图5 功能层面边界（SKEMPI + 独立迁移集）
  FigS1_triage_tradeoff         图S1 前置分诊取舍曲线
  FigS2_coverage_complementarity 图S2 覆盖互补性与 apo 可用性
  FigS3_disease_variants        图S3 疾病相关变异界面分布
  FigS4_conformational_deviation 图S4 本数据 vs BM5.5 构象偏离分布
"""
import importlib.util
import json
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

ROOT = Path(r"D:\hnnm\Metabolic_Inflammation_Functional_Interface")
OUT = ROOT / "docs" / "paper" / "figures_tiff"
PREV = ROOT / "docs" / "paper" / "_revision_work" / "fig_preview"
OUT.mkdir(parents=True, exist_ok=True)
PREV.mkdir(parents=True, exist_ok=True)

spec = importlib.util.spec_from_file_location("s120", ROOT / "code" / "Step120_make_figs_bilingual.py")
s120 = importlib.util.module_from_spec(spec)
spec.loader.exec_module(s120)

MAP = {
    "Fig1_overview": "Fig1_overview",
    "Fig3_H1_mechanism": "Fig2_failure_mechanism",
    "Fig11_overlay_preformed_plastic": "Fig3_overlay_preformed_plastic",
    "Fig4_H2_plasticity": "Fig4_plasticity_prediction",
    "Fig7_functional_boundary": "Fig5_functional_boundary",
    "Fig6_R5_coverage": "FigS2_coverage_complementarity",
    "Fig8_disease_variants": "FigS3_disease_variants",
    "Fig9_BM55_rmsd_distribution": "FigS4_conformational_deviation",
    "FigS7_triage_tradeoff": "FigS1_triage_tradeoff",
}


def save600(fig, name, lang):
    stem = MAP.get(name, name)
    p = OUT / f"{stem}_{lang}.tiff"
    fig.savefig(p, dpi=600, bbox_inches="tight", pil_kwargs={"compression": "tiff_lzw"})
    fig.savefig(PREV / f"{stem}_{lang}.png", dpi=150, bbox_inches="tight")
    plt.close(fig)
    print("saved", p.name)


s120.save = save600


def setup(lang):
    s120.setup(lang)
    plt.rcParams.update({"savefig.dpi": 600, "figure.dpi": 600})


def T(zh, en, lang):
    return zh if lang == "zh" else en


# ---------------- 图S1 前置分诊取舍曲线 ----------------
def figS1(lang):
    qc = pd.read_csv(ROOT / "results/Step97_structure_qc/pair_structure_qc.csv")
    qc["pair_id"] = qc["record_id"] + "__" + qc["apo_pdb_id"].str.lower()
    TH = 0.30
    df = qc[["pair_id", "global_ca_rmsd", "pesto_apo_pair_auprc", "dataset"]].dropna()
    df = df.sort_values("global_ca_rmsd").reset_index(drop=True)
    n = len(df)
    hit = (df["pesto_apo_pair_auprc"] >= TH).astype(int)
    base = hit.mean()
    fracs = np.arange(1, n + 1) / n
    cum = np.cumsum(hit) / np.arange(1, n + 1)
    enrich = cum / base

    fig, ax = plt.subplots(figsize=(s120.W, 2.85))
    ax.plot(fracs, enrich, color="#c0392b", lw=1.2,
            label=T("按叠合 RMSD 排序的前置分诊", "triage ranked by superposition RMSD", lang))
    ax.axhline(1.0, color="#7f8c8d", ls="--", lw=0.8,
               label=T("随机保留（基线）", "random retention (baseline)", lang))
    for f, ls in ((1 / 3, ":"), (0.5, "-.")):
        ax.axvline(f, color="#2c3e50", ls=ls, lw=0.8)
    for f, txt in ((1 / 3, T(f"保留 1/3：{enrich[int(n / 3) - 1]:.2f}×",
                            f"top 1/3: {enrich[int(n / 3) - 1]:.2f}×", lang)),
                   (0.5, T(f"保留 1/2：{enrich[int(n / 2) - 1]:.2f}×",
                           f"top 1/2: {enrich[int(n / 2) - 1]:.2f}×", lang))):
        ax.annotate(txt, xy=(f, enrich[int(f * n) - 1]), xytext=(f + 0.06, enrich[int(f * n) - 1] + 0.12),
                    fontsize=9, color="#2c3e50",
                    arrowprops=dict(arrowstyle="->", color="#2c3e50", lw=0.6))
    ax.axhline(0.904, color="#c0392b", ls=":", lw=0.6, alpha=0.6)
    ax.set_xlabel(T("保留的 apo 结构比例（按 apo–holo 叠合 RMSD 从低到高）",
                    "fraction of apo structures retained (low to high apo–holo RMSD)", lang))
    ax.set_ylabel(T(f"命中率富集倍数（AUPRC ≥ {TH} 占比 / 全集基线 {base:.3f}）",
                    f"enrichment of hit rate (AUPRC ≥ {TH} / baseline {base:.3f})", lang))
    ax.set_title(T("前置分诊取舍曲线（83 对主基准）", "Triage trade-off curve (83-pair main set)", lang), loc="left")
    ax.set_xlim(0, 1)
    ax.set_ylim(0.85, max(enrich) + 0.15)
    ax.legend(frameon=False, loc="upper right")
    fig.tight_layout()
    save600(fig, "FigS7_triage_tradeoff", lang)


FIGS = ["fig01", "fig03", "fig04", "fig05", "fig06", "figS3", "figS4", "figS5"]

if __name__ == "__main__":
    for lang in ("zh", "en"):
        setup(lang)
        for name in FIGS:
            try:
                getattr(s120, name)(lang)
            except Exception as e:
                print("FAIL", name, lang, type(e).__name__, e)
        try:
            figS1(lang)
        except Exception as e:
            print("FAIL figS1", lang, type(e).__name__, e)
    print("done")
