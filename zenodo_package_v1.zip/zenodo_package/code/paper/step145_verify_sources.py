# -*- coding: utf-8 -*-
"""从结果文件提取关键数字，用于与 docx 表格核对"""
import json, os, glob
import pandas as pd

R = r"D:\hnnm\Metabolic_Inflammation_Functional_Interface\results"

def show(title, obj, maxlines=30):
    print(f"\n########## {title} ##########")
    if isinstance(obj, str):
        print(obj[:3000])
    else:
        s = json.dumps(obj, ensure_ascii=False, indent=1, default=str)
        print(s[:3500])

# ---- 表4/表S? H1 预注册 ----
p = os.path.join(R, "Step82_h1_prereg", "h1_confirmation_result.json")
show("H1 prereg", json.load(open(p, encoding="utf-8")))
df = pd.read_csv(os.path.join(R, "Step82_h1_prereg", "pair_level_table.csv"))
print("pair_level_table cols:", list(df.columns), "n =", len(df))
print(df.head(3).to_string())

# ---- 可塑性预测 (lift) ----
for cand in glob.glob(os.path.join(R, "Step9*", "*.json")) + glob.glob(os.path.join(R, "Step44*", "*.json")) + glob.glob(os.path.join(R, "Step45*", "*.json")):
    print("CAND:", cand)

# ---- Step92 消融/家族 ----
show("Step92 ablation", json.load(open(os.path.join(R, "Step92_h2_thickening", "ablation_summary.json"), encoding="utf-8")))
fam = pd.read_csv(os.path.join(R, "Step92_h2_thickening", "family_h2_performance.csv"))
print("family_h2 cols:", list(fam.columns))
print(fam.to_string()[:2500])
show("Step92 holo baseline", json.load(open(os.path.join(R, "Step92_h2_thickening", "holo_supervised_baseline.json"), encoding="utf-8")))

# ---- Step95 功能边界 ----
show("Step95", json.load(open(os.path.join(R, "Step95_plasticity_ddg", "step95_result.json"), encoding="utf-8")))

# ---- Step96 变异 ----
show("Step96", json.load(open(os.path.join(R, "Step96_variants", "step96_result.json"), encoding="utf-8")))

# ---- Step91 D支持 ----
show("Step91", json.load(open(os.path.join(R, "Step91_d_support", "d_support_result.json"), encoding="utf-8")))

# ---- Step07 SKEMPI ----
for f in ["multitask_summary.json", "step07_summary.json"]:
    fp = os.path.join(R, "Step07_multitask_skempi", f)
    if os.path.exists(fp):
        show(f"Step07 {f}", json.load(open(fp, encoding="utf-8")))

# ---- Step23 时间外 ----
show("Step23 temporal", json.load(open(os.path.join(R, "Step23_frozen_temporal", "temporal_summary.json"), encoding="utf-8")))

# ---- Step65 PeSTo 零训练 ----
for f in sorted(os.listdir(os.path.join(R, "Step65_pesto_zero_training_reanalysis"))):
    if f.endswith(".json"):
        print("Step65 json:", f)

# ---- Step38 外部统计 ----
show("Step38 stats", json.load(open(os.path.join(R, "Step38_external_statistics", "statistics_summary.json"), encoding="utf-8")))

# ---- Step123 补充 ----
for f in ["tradeoff_curve.json", "overlap_stratified.json", "cross_method_consistency.json", "pesto_overlap_audit.json"]:
    fp = os.path.join(R, "Step123_jcim_supplements", f)
    if os.path.exists(fp):
        show(f"Step123 {f}", json.load(open(fp, encoding="utf-8")))
res = pd.read_csv(os.path.join(R, "Step123_jcim_supplements", "resolution_strata.csv"))
print("resolution_strata:\n", res.to_string())

# ---- Step126 敏感性 ----
for f in ["holo_selection_rule.json", "sidechain_sensitivity.json"]:
    fp = os.path.join(R, "Step126_sensitivity_complete", f)
    show(f"Step126 {f}", json.load(open(fp, encoding="utf-8")))

# ---- Step121 统计加固 ----
show("Step121", json.load(open(os.path.join(R, "Step121_jcim_stat_hardening", "jcim_stats.json"), encoding="utf-8")))

# ---- Step110/111 扩样 ----
show("Step110 expansion", json.load(open(os.path.join(R, "Step110_apo_expansion_stats", "expansion_stats.json"), encoding="utf-8")))
show("Step110 record CI", json.load(open(os.path.join(R, "Step110_apo_expansion_stats", "record_level_ci.json"), encoding="utf-8")))
show("Step111 scale", json.load(open(os.path.join(R, "Step111_expansion_summary", "scale.json"), encoding="utf-8")))

# ---- Step59 BM5 构象机制 ----
if os.path.isdir(os.path.join(R, "Step59_bm5_conformation_mechanism")):
    for f in os.listdir(os.path.join(R, "Step59_bm5_conformation_mechanism")):
        print("Step59 file:", f)

# ---- Step44/45 conformation reliability ----
for d in ["Step44_conformation_reliability", "Step45_reliability_statistics"]:
    dd = os.path.join(R, d)
    if os.path.isdir(dd):
        for f in os.listdir(dd):
            print(d, "file:", f)
