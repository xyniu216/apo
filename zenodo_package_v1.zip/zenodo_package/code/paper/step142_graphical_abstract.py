# -*- coding: utf-8 -*-
"""Step142: 图形摘要（ACS TOC graphic：8.5 x 5 cm，600 dpi，中英双语）。"""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, FancyBboxPatch, FancyArrowPatch

ROOT = Path(r"D:\hnnm\Metabolic_Inflammation_Functional_Interface")
OUT = ROOT / "docs" / "paper" / "figures"
PREV = ROOT / "docs" / "paper" / "_revision_work" / "fig_preview"

INK, GREY = "#1b1b1b", "#5f5f5f"


def T(zh, en, lang):
    return zh if lang == "zh" else en


def draw(lang):
    plt.rcParams.update({
        "font.family": ["Arial", "SimSun"] if lang == "zh" else ["Arial"],
        "axes.unicode_minus": False, "savefig.facecolor": "white",
    })
    fig = plt.figure(figsize=(8.5 / 2.54, 5.0 / 2.54))  # 8.5 x 5 cm
    fig.savefig  # noqa
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_xlim(0, 100); ax.set_ylim(0, 59); ax.axis("off")

    # ---------- title ----------
    ax.text(50, 55.5, T("诱导契合的可计算边界", "Induced fit has a computable boundary", lang),
            ha="center", va="center", fontsize=8.6, fontweight="bold", color=INK)
    ax.text(50, 51.5, T("肽结合界面：信息缺失由偏离决定，可塑性由几何决定",
                        "Peptide-binding interfaces: information loss scales with deviation; plasticity is geometric",
                        lang), ha="center", va="center", fontsize=4.6, color=GREY)

    # ---------- apo cartoon (left) ----------
    apo_c = "#c9ccd1"
    for cx in (15, 26):
        ax.add_patch(Circle((cx, 31), 6.4, facecolor=apo_c, edgecolor="#9aa0a8", linewidth=0.8, zorder=2))
    ax.add_patch(Circle((20.5, 26.2), 3.6, facecolor="none", edgecolor="#8a909a",
                        linewidth=0.9, linestyle=(0, (3, 2)), zorder=3))
    ax.text(20.5, 41.2, "apo", ha="center", fontsize=7.5, color=INK, style="italic")
    ax.text(20.5, 17.6, T("口袋未成形", "pocket not formed", lang), ha="center", fontsize=4.4, color=GREY)

    # ---------- RMSD arrow (middle) ----------
    ax.add_patch(FancyArrowPatch((34.5, 31), (60.5, 31), arrowstyle="<|-|>",
                                 mutation_scale=9, linewidth=1.0, color="#4a5560", zorder=2))
    ax.text(47.5, 34.6, T("叠合 RMSD", "aligned RMSD", lang), ha="center", fontsize=5.6, color="#4a5560")
    ax.text(47.5, 27.0, T("构象偏离", "deviation", lang), ha="center", fontsize=4.4, color=GREY)

    # ---------- holo cartoon (right) ----------
    for cx in (69, 80):
        ax.add_patch(Circle((cx, 31), 6.4, facecolor="#a8c6e8", edgecolor="#5b7ea6", linewidth=0.8, zorder=2))
    ax.add_patch(Circle((74.5, 26.2), 3.6, facecolor="#c0392b", edgecolor="#8f2d22",
                        linewidth=0.7, alpha=0.85, zorder=3))
    pep = [(68.5, 20.6), (71.6, 19.7), (74.8, 19.5), (77.9, 20.4)]
    for px, py in pep:
        ax.add_patch(Circle((px, py), 1.55, facecolor="#e6b93d", edgecolor="#a8842a", linewidth=0.6, zorder=3))
    ax.text(74.5, 41.2, "holo", ha="center", fontsize=7.5, color=INK, style="italic")
    ax.text(74.5, 15.2, T("红色：结合界面（肽，黄色）", "red: interface (peptide in yellow)", lang),
            ha="center", fontsize=4.4, color=GREY)

    # ---------- bottom panel A: interface conditional ----------
    ax.add_patch(FancyBboxPatch((2, 2), 45, 10.5, boxstyle="round,pad=0.4,rounding_size=1.2",
                                facecolor="#f7e6e3", edgecolor="#8f4436", linewidth=0.9, zorder=2))
    ax.text(24.5, 10.0, T("界面定位：条件可计算", "interface localization: conditional", lang),
            ha="center", fontsize=5.4, fontweight="bold", color="#8f4436")
    xs = [7, 13, 19, 25, 31, 38, 43]
    ys = [7.6, 7.0, 6.2, 5.4, 4.8, 4.3, 4.0]
    ax.plot(xs, ys, color="#8f4436", linewidth=1.1, zorder=3)
    ax.plot(xs, ys, "o", color="#8f4436", markersize=1.4, zorder=3)
    ax.text(8.5, 4.4, T("AUPRC", "AUPRC", lang), fontsize=3.8, color=GREY)
    ax.text(41.5, 8.4, T("RMSD", "RMSD", lang), fontsize=3.8, color=GREY)
    ax.text(24.5, 3.0, T("随偏离增大而退化（ρ = −0.336）", "decays with deviation (ρ = −0.336)", lang),
            ha="center", fontsize=4.2, color=GREY)

    # ---------- bottom panel B: plasticity robust ----------
    ax.add_patch(FancyBboxPatch((53, 2), 45, 10.5, boxstyle="round,pad=0.4,rounding_size=1.2",
                                facecolor="#e4f2ea", edgecolor="#2c6b5a", linewidth=0.9, zorder=2))
    ax.text(75.5, 10.0, T("可塑性排序：apo 直接可读", "plasticity ranking: readable from apo", lang),
            ha="center", fontsize=5.4, fontweight="bold", color="#2c6b5a")
    ax.add_patch(FancyBboxPatch((59, 5.0), 28, 2.6, boxstyle="round,pad=0.15,rounding_size=0.6",
                                facecolor="#2c6b5a", edgecolor="none", zorder=3))
    ax.add_patch(FancyBboxPatch((59, 5.0), 15.1, 2.6, boxstyle="round,pad=0.15,rounding_size=0.6",
                                facecolor="#8fbf9f", edgecolor="none", zorder=4))
    ax.text(73, 6.3, T("lift 1.85（CI 1.69–2.04）", "lift 1.85 (CI 1.69–2.04)", lang),
            fontsize=3.8, color="white", zorder=5, va="center", ha="center")
    ax.text(59, 3.0, T("87 维 apo 内在特征 · 14/14 家族一致",
                        "87 apo intrinsic features · 14/14 families", lang),
            fontsize=4.2, color=GREY)

    p = OUT / f"GraphicalAbstract_{lang}.tiff"
    fig.savefig(p, dpi=600, pil_kwargs={"compression": "tiff_lzw"})
    fig.savefig(PREV / f"GraphicalAbstract_{lang}.png", dpi=150)
    fig.savefig(OUT / f"GraphicalAbstract_{lang}.png", dpi=600)
    plt.close(fig)
    print("saved", p.name)


for lang in ("zh", "en"):
    draw(lang)
