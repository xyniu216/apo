# -*- coding: utf-8 -*-
"""Step124: 正文 docx 增补修订（P1-5/P1-6/P1-7/P2-8/P2-9/P2-10 + B1 重叠审计）。
所有新增/替换文字以深红色（C00000）标注；参考文献 [4][5] 为新增，原 [4]–[15] 顺延为 [6]–[17]。
"""
import re, copy, shutil, datetime, hashlib, pathlib
import docx
from docx.shared import RGBColor, Pt
from docx.oxml.ns import qn

ROOT = pathlib.Path(r"D:\hnnm\Metabolic_Inflammation_Functional_Interface")
P = ROOT / "docs/paper/论文初稿_诱导契合的可计算边界.docx"
BK = P.parent / "_revision_work"
stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
shutil.copy2(P, BK / f"main_backup_{stamp}.docx")
print("backup", stamp, hashlib.sha256(P.read_bytes()).hexdigest()[:12])

d = docx.Document(str(P))
RED = RGBColor(0xC0, 0x00, 0x00)
paras = d.paragraphs


def fontize(run, red=False, template_rpr=None):
    if template_rpr is not None:
        run._element.insert(0, copy.deepcopy(template_rpr))
    run.font.name = "Times New Roman"
    if red:
        run.font.color.rgb = RED
    rpr = run._element.get_or_add_rPr()
    rfonts = rpr.find(qn("w:rFonts"))
    if rfonts is None:
        rfonts = rpr.makeelement(qn("w:rFonts"), {})
        rpr.insert(0, rfonts)
    rfonts.set(qn("w:eastAsia"), "宋体")


def get_rpr(para):
    for r in para.runs:
        rpr = r._element.find(qn("w:rPr"))
        if rpr is not None:
            return rpr
    return None


def append_red(para, text):
    r = para.add_run(text)
    fontize(r, red=True)
    return r


def rebuild(para, segments):
    """segments: list of (text, is_red)。整段重建。"""
    tpl = get_rpr(para)
    for r in list(para.runs):
        r._element.getparent().remove(r._element)
    for text, is_red in segments:
        r = para.add_run(text)
        fontize(r, red=is_red, template_rpr=tpl)


def insert_para_after(para, text, red=True):
    new_p = copy.deepcopy(para._p)
    for child in list(new_p):
        if child.tag == qn("w:r"):
            new_p.remove(child)
    para._p.addnext(new_p)
    from docx.text.paragraph import Paragraph
    np = Paragraph(new_p, para._parent)
    r = np.add_run(text)
    fontize(r, red=red)
    return np


# ---------- 0. 参考文献重编号：正文与表格单元格中 [4]–[15] -> [6]–[17] ----------
pat = re.compile(r"\[([^\[\]]*)\]")

def renumber_text(text):
    def rep(m):
        content = m.group(1)
        tokens = [t.strip() for t in content.split(",")]
        if all(re.fullmatch(r"\d{1,2}", t) for t in tokens) and tokens:
            out = []
            for t in tokens:
                n = int(t)
                out.append(str(n + 2) if 4 <= n <= 15 else t)
            return "[" + ",".join(out) + "]"
        return m.group(0)
    return pat.sub(rep, text)

def fix_runs_in_paragraph(p):
    for r in p.runs:
        t = r.text
        if "[" in t:
            nt = renumber_text(t)
            if nt != t:
                r.text = nt

nfix = 0
for p in d.paragraphs:
    if "[" in p.text:
        before = p.text
        fix_runs_in_paragraph(p)
        if fix_runs_in_paragraph.__name__ and p.text != before:
            nfix += 1
for tb in d.tables:
    for row in tb.rows:
        for cell in row.cells:
            for p in cell.paragraphs:
                if "[" in p.text:
                    fix_runs_in_paragraph(p)
print("renumber paragraphs touched:", nfix)

# ---------- 1. 引言 P8 重写（P2-8：让出已知结论，新增 [4][5]） ----------
p8 = paras[8]
assert p8.text.startswith("以 PeSTo 为代表"), p8.text[:30]
new_p8 = ("以 PeSTo 为代表的几何深度学习模型仅凭原子坐标即可预测结合界面，性能优于既往方法[3]，"
          "面向肽结合位点的几何注意力网络等方案也在发展[7]。这类模型的评价普遍依赖蛋白–蛋白对接基准"
          "（如对接基准第 5 版，BM5.5）[6]，其中可供评价的 apo 结构大多已经接近结合构象。文献报道的"
          "“apo 性能”因此是在构象偏离较小的结构上测得的：在对接研究中，以未结合结构替代结合结构已反复"
          "被观察到成功率下降（肽对接中 unbound/unbound 条件较结合结构基准成功率降低约四分之一[4]），"
          "CryptoBench 在 1107 个 apo–holo 结构对上系统量化了这种偏差，并明确提示基于 holo 结构的"
          "评价会给出不切实际的性能预期[5]。已知的是现象——apo 与 holo 评价的差距确实存在；尚缺的是"
          "一个逐结构、可复算的判据：给定一个 apo 结构，何时界面信息仍在、何时已不可恢复。本文的切入点"
          "正是把这一差距分解为单个几何量（apo 与结合态的叠合 RMSD），并检验它能否事先标定 apo 界面"
          "定位的可靠边界。")
rebuild(p8, [(new_p8, True)])
print("P8 rewritten")

# ---------- 2. 摘要 P3：末尾追加两个可引用数字（P2-10） ----------
p3 = paras[3]
assert p3.text.startswith("肽配体结合常诱导"), p3.text[:30]
append_red(p3, "按可塑性排序的前置分诊可将 apo 界面定位的命中率富集约 1.4 倍（按叠合 RMSD 保留最预成的"
               "三分之一结构时，命中率由 20.5% 升至约 29%）；对 PeSTo 官方训练划分的重叠审计排除了该"
               "趋势来自模型记忆化训练结构的可能。")
print("P3 appended")

# ---------- 3. 方法 2.3 P29：追加重叠审计方法句 ----------
p29 = paras[29]
assert p29.text.startswith("PeSTo（i_v4_1"), p29.text[:30]
append_red(p29, "PeSTo 官方发布的数据划分（subunits_train/validation/test_set，按 PDB 条目标识）与本文 "
               "apo、holo 条目的重叠已逐一审计，并按是否暴露于官方训练划分对配对级结果分层（3.1.2 节、"
               "表 S18）。")
print("P29 appended")

# ---------- 4. 结果：P58 之后插入训练记忆化审计段（B1） ----------
p58 = paras[58]
assert p58.text.startswith("上述数字以配对为单元"), p58.text[:30]
audit_para = ("主结果的另一个可能解释是训练记忆化：PeSTo 的官方训练数据可能已包含与本文 apo 条目同源"
              "甚至相同的结构。把本文 28 个 apo 条目与 PeSTo 官方训练、验证、测试划分逐一比对（按 PDB "
              "条目标识），7 个条目出现在官方训练集、7 个出现在验证集、1 个出现在测试集。按“apo 条目"
              "是否进入官方训练集”分层后，叠合 RMSD–AUPRC 相关在未暴露子集中反而更强（暴露子集 22 对，"
              "ρ = −0.188，AUPRC 中位 0.138；未暴露子集 61 对，ρ = −0.395，中位 0.176）；按“是否进入"
              "任一官方划分”分层得到同一方向（暴露 43 对，ρ = −0.283，中位 0.168；未暴露 40 对，"
              "ρ = −0.433，中位 0.156）。两个子集中方向一致且未暴露子集效应量更大，说明配对级趋势并非由"
              "训练记忆化驱动。重叠清单与分层数字见表 S18。")
insert_para_after(p58, audit_para, red=True)
print("audit paragraph inserted after P58")

# ---------- 5. 结果 P67：追加严格排序取舍曲线（P1-5） ----------
p67 = paras[67]
assert p67.text.startswith("把这一关系用于实际取舍"), p67.text[:30]
append_red(p67, "把分组换成连续排序，结论不变（图 S7、表 S17B）：按叠合 RMSD 对全部 83 对严格升序保留，"
               "基线命中率（AUPRC ≥ 0.30 的比例）为 20.5%，保留最预成的三分之一后升至 29.6%（富集 "
               "1.45 倍），与固定截断分层的 28.6% 一致；整条富集曲线相对随机保留的超额面积（AUC）为 "
               "0.168。按排序分段的三组平均 AUPRC 依次为 0.248、0.158、0.175，第三段未继续下降，提示"
               "该判据的判别力主要来自最预成的一端，对高可塑性一端的区分能力有限。")
print("P67 appended")

# ---------- 6. P67 之后插入分辨率分层段（P1-6） ----------
reso_para = ("结构分辨率是另一个需要检查的混杂维度。按 apo 结构分辨率分层（表 S17A）：≤2.5 Å 的 28 对 "
             "AUPRC 中位为 0.300，2.5–3.0 Å 的 19 对为 0.132，>3.0 Å 的 27 对为 0.115，NMR 结构（9 对）"
             "为 0.145。分辨率与 AUPRC 的整体相关为 ρ = −0.563，与叠合 RMSD 的相关为 ρ = +0.244："
             "低分辨率结构偏向高可塑性体系，分辨率梯度部分由构象构成差异解释；在各分层内部，"
             "RMSD–AUPRC 相关均减弱（组内 ρ 介于 −0.14 与 +0.12 之间），与 2.4 节“效应量随分析单元"
             "收紧而减弱”的读法一致。分辨率与可塑性并非两个独立的解释，将二者同时作为敏感性维度报告"
             "（表 S17A）比单独归因更稳健。")
insert_para_after(p67, reso_para, red=True)
print("resolution paragraph inserted after P67")

# ---------- 7. 结果 P68：追加跨方法剖面一致性（P1-7） ----------
p68 = paras[68]
assert p68.text.startswith("同一 apo 面板上另做一次跨方法检查"), p68.text[:30]
append_red(p68, "尽管 GAPS 本身不具备可用判别力，两个方法的逐对 AUPRC 剖面在 83 对上显著同向变化"
               "（Spearman ρ = 0.48，Kendall τ = 0.34）：PeSTo 判定为难的对，GAPS 同样判定为难。这提示"
               "“哪些结构对单结构界面预测偏难”的变异是结构自身的性质，而非某一方法特有的噪声；同时也"
               "再次确认，AUPRC 随叠合 RMSD 下降的方向性趋势目前仍由 PeSTo 单独给出，跨方法的方向性复现"
               "尚待具备判别力的第二方法完成。")
print("P68 appended")

# ---------- 8. 讨论 P104：句中替换 + 追加（P1-7/B1 收口） ----------
p104 = paras[104]
assert p104.text.startswith("本文的证据有三处边界"), p104.text[:30]
t104 = p104.text
old_s = "据此，「可塑性越高、apo 界面信息越少」目前仍是单一方法上的规律，跨方法一致性尚待独立检验，这是最需要后续工作补上的一环。"
new_s = ("据此，「可塑性越高、apo 界面信息越少」目前仍是单一方法上的规律；新增的剖面一致性检验显示两个方法"
         "在“哪些对更难”上显著同向（ρ = 0.48），但不构成方向性证据的跨方法复现。训练记忆化也已按官方划分"
         "审计并排除（3.1.2 节、表 S18）：该相关既非来自模型见过测试结构的 holo 形态，也非来自同源结构泄漏。"
         "跨方法的方向性复现仍是最需要后续工作补上的一环。")
assert old_s in t104, "P104 target sentence not found"
head, tail = t104.split(old_s, 1)
rebuild(p104, [(head, False), (new_s, True), (tail, False)])
print("P104 patched")

# ---------- 9. 讨论 P105：追加 Implications 内容（P2-9） ----------
p105 = paras[105]
assert p105.text.startswith("对下游建模而言"), p105.text[:30]
append_red(p105, "这一判据对下游建模的含义可再具体化为两点。其一，对 docking 与虚拟筛选：已有研究表明 "
               "holo 偏向的评价会系统性高估成功率[4,5]，本文的构象偏离判据可在计算前把高可塑性目标标出，"
               "使其单结构打分结果被当作上限估计而非点估计使用。其二，对基准设计：以 holo 或预成 apo 为主的"
               "评价集会压缩构象多样性（3.1.3 节、图 S1），方法排名因此偏向在预成构象上表现好的配置；本文的"
               "严格配对基准（表 S12）可作为此类评价的补充集。")
print("P105 appended")

# ---------- 10. 数据可用性 P115：追加新增文件 ----------
p115 = paras[115]
assert p115.text.startswith("全部原始结构列表"), p115.text[:30]
append_red(p115, "本次补充的分析数据一并归档：RMSD 排序取舍曲线与分辨率分层（tradeoff_curve.json、"
               "resolution_strata.csv、图 S7、表 S17）、PeSTo 官方训练划分重叠审计（pesto_overlap_audit.json、"
               "overlap_stratified.json、表 S18），以及 PeSTo 与 GAPS 逐对 AUPRC 剖面的一致性统计"
               "（cross_method_consistency.json）。")
print("P115 appended")

# ---------- 11. 参考文献：在 [3] 之后插入新 [4][5] ----------
ref3 = next(p for p in d.paragraphs if p.text.strip().startswith("[3] Krapp"))
tpl = get_rpr(ref3)
new_refs = [
    "[4] Trellet M., Melquiond A.S.J., Bonvin A.M.J.J. A Unified Conformational Selection and Induced Fit "
    "Approach to Protein–Peptide Docking. PLoS ONE 2013, 8 (3), e58769.",
    "[5] Škrhák V., Novotný M., Feidakis C.P., Krivák R., Hoksza D. CryptoBench: Cryptic Protein–Ligand "
    "Binding Sites Dataset and Benchmark. Bioinformatics 2025, 41 (1), btae745.",
]
anchor = ref3._p
for txt in new_refs:
    new_p = copy.deepcopy(ref3._p)
    for child in list(new_p):
        if child.tag == qn("w:r"):
            new_p.remove(child)
    anchor.addnext(new_p)
    anchor = new_p
    from docx.text.paragraph import Paragraph
    np = Paragraph(new_p, ref3._parent)
    r = np.add_run(txt)
    fontize(r, red=False, template_rpr=tpl)
print("refs inserted")

d.save(str(P))
print("saved", P.stat().st_size)
