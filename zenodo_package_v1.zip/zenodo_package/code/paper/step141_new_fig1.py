# -*- coding: utf-8 -*-
"""Step141: 按最终论文流程重绘图1（中英双语，330 dpi TIFF + 预览 PNG）。"""
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

ROOT = Path(r"D:\hnnm\Metabolic_Inflammation_Functional_Interface")
OUT = ROOT / "docs" / "paper" / "figures_tiff"
PREV = ROOT / "docs" / "paper" / "_revision_work" / "fig_preview"
PREV.mkdir(parents=True, exist_ok=True)

FS, TICK = 10, 8.5
TICK_EN = 7.6


def setup(lang):
    fam = ["Times New Roman", "SimSun"] if lang == "zh" else ["Times New Roman"]
    plt.rcParams.update({
        "font.family": fam, "font.size": FS, "axes.unicode_minus": False,
        "savefig.facecolor": "white", "figure.dpi": 600, "savefig.dpi": 600,
    })


def T(zh, en, lang):
    return zh if lang == "zh" else en


INK, GREY = "#1b1b1b", "#5f5f5f"


def box(ax, x0, y0, w, h, fc, ec):
    ax.add_patch(FancyBboxPatch((x0, y0), w, h,
                 boxstyle="round,pad=0.6,rounding_size=1.6",
                 linewidth=1.1, edgecolor=ec, facecolor=fc, zorder=2))


def arrow(ax, x1, y1, x2, y2, color="#2f5871"):
    ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2), arrowstyle="-|>",
                 mutation_scale=11, linewidth=1.1, color=color, zorder=1))


def fig01(lang):
    global TICK
    TICK = TICK_EN if lang == "en" else 8.5
    fig = plt.figure(figsize=(6.90, 4.90))
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_xlim(0, 100); ax.set_ylim(0, 100); ax.axis("off")

    # ---- Row 1: data → pairing → evaluation (blue) ----
    fcB, ecB = "#e3ecf6", "#2f5871"
    for (x0, w) in [(1, 31), (34.5, 31), (68, 31)]:
        box(ax, x0, 66, w, 30, fcB, ecB)
    arrow(ax, 32.6, 81, 34.0, 81); arrow(ax, 66.1, 81, 67.5, 81)

    ax.text(3, 91.5, T("① 数据构建", "1  Data", lang), fontsize=FS, fontweight="bold", color=INK, va="center")
    b1_lines = {
        "zh": [("代谢炎症蛋白–肽复合物（PDB/BioLiP）", 86.5),
               ("检索面板 21 个家族 · 125 条受体记录", 82.5),
               ("122 条可评价 · 30,325 个 17-mer 窗口", 78.5),
               ("19,861 个逐残基构象位移标注", 74.5),
               ("逐残基位移：序列比对 + Kabsch 叠合", 70.0)],
        "en": [("Metabolic-inflammation protein–peptide", 87.8),
               ("complexes (PDB / BioLiP)", 84.6),
               ("21 families · 125 receptor records", 81.0),
               ("122 evaluable · 30,325 windows", 77.8),
               ("19,861 residue displacement labels", 74.6),
               ("Displacements: alignment + Kabsch fit", 71.4)],
    }
    for txt, yy in b1_lines[lang]:
        ax.text(3, yy, txt, fontsize=TICK, color=GREY, va="center")

    ax.text(36.5, 91.5, T("② 严格 apo–holo 配对", "2  Strict apo–holo pairing", lang), fontsize=FS, fontweight="bold", color=INK, va="center")
    ax.text(36.5, 86.5, T("序列同一性 ≥ 0.8 · 界面覆盖度 ≥ 0.5", "identity ≥ 0.8 · coverage ≥ 0.5", lang), fontsize=TICK, color=GREY, va="center")
    ax.text(36.5, 82.5, T("83 对 · 28 个 apo 结构 · 18,965 窗口", "83 pairs · 28 apo · 18,965 windows", lang), fontsize=TICK, color=GREY, va="center")
    ax.text(36.5, 78.5, T("14 个家族 · 14 个同源簇", "14 families · 14 homology clusters", lang), fontsize=TICK, color=GREY, va="center")
    ax.text(36.5, 74.5, T("扩样敏感性集 226 对 · 54,021 窗口", "226-pair sensitivity set (54,021 win.)", lang), fontsize=TICK, color=GREY, va="center")
    ax.text(36.5, 70.0, T("时间外测试集：2024-01-01 后发表结构", "Temporal holdout: post-2024 structures", lang), fontsize=TICK, color=GREY, va="center")

    ax.text(70, 91.5, T("③ 评价设计", "3  Evaluation design", lang), fontsize=FS, fontweight="bold", color=INK, va="center")
    ax.text(70, 86.5, T("同源簇分组交叉验证（GroupKFold）", "Homology-cluster GroupKFold CV", lang), fontsize=TICK, color=GREY, va="center")
    ax.text(70, 82.5, T("预注册确认性协议（Holm 校正）", "Preregistered protocols (Holm)", lang), fontsize=TICK, color=GREY, va="center")
    ax.text(70, 78.5, T("簇块 bootstrap · 混合效应模型", "Cluster-block bootstrap · mixed models", lang), fontsize=TICK, color=GREY, va="center")
    ax.text(70, 74.5, T("留一 apo · 块置换检验", "Leave-one-apo-out · block permutation", lang), fontsize=TICK, color=GREY, va="center")
    ax.text(70, 70.0, T("apo 为分析单元（n = 28）", "apo as analysis unit (n = 28)", lang), fontsize=TICK, color=GREY, va="center")

    # ---- Row 1 → Row 2 arrows ----
    arrow(ax, 16.5, 65.4, 16.5, 60.6)
    arrow(ax, 50.0, 65.4, 50.0, 60.6)
    arrow(ax, 83.5, 65.4, 83.5, 60.6)
    arrow(ax, 50.0, 65.4, 20.0, 60.6, color="#8fa8bf")
    arrow(ax, 50.0, 65.4, 80.0, 60.6, color="#8fa8bf")

    # ---- Row 2: three tasks ----
    fc1, ec1 = "#f7e6e3", "#8f4436"
    fc2, ec2 = "#e4f2ea", "#2c6b5a"
    fc3, ec3 = "#fbf0dd", "#8a6224"
    box(ax, 1, 30, 31, 30, fc1, ec1)
    box(ax, 34.5, 30, 31, 30, fc2, ec2)
    box(ax, 68, 30, 31, 30, fc3, ec3)

    ax.text(3, 55.0, T("④ 任务一：界面定位", "4  Task 1: interface localization", lang), fontsize=FS, fontweight="bold", color=ec1, va="center")
    ax.text(3, 50.5, T("PeSTo 零训练 lift 1.25", "PeSTo zero-shot lift 1.25", lang), fontsize=TICK, color=GREY, va="center")
    ax.text(3, 47.0, T("（监督基线 1.64 · BM5.5 3.22）", "(supervised 1.64 · BM5.5 3.22)", lang), fontsize=TICK, color=GREY, va="center")
    ax.text(3, 43.0, T("退化随叠合 RMSD 增大：ρ = −0.336", "Degradation with RMSD: ρ = −0.336", lang), fontsize=TICK, color=GREY, va="center")
    ax.text(3, 39.5, T("前置分诊命中率富集约 1.4 倍", "Triage enriches hit rate ~1.4×", lang), fontsize=TICK, color=GREY, va="center")
    ax.text(3, 35.0, T("跨方法：ScanNet 复现（ρ = −0.486）", "ScanNet reproduces (ρ = −0.486)", lang), fontsize=TICK, color=GREY, va="center")
    ax.text(3, 31.8, T("GAPS 近随机（AUC 0.509）", "GAPS near-random (AUC 0.509)", lang), fontsize=TICK, color=GREY, va="center")

    ax.text(36.5, 55.0, T("⑤ 任务二：可塑性排序", "5  Task 2: plasticity ranking", lang), fontsize=FS, fontweight="bold", color=ec2, va="center")
    ax.text(36.5, 50.5, T("87 维 apo 内在特征", "87 apo intrinsic features", lang), fontsize=TICK, color=GREY, va="center")
    ax.text(36.5, 47.0, T("折外 lift 1.85（CI 1.69–2.04）", "Out-of-fold lift 1.85 (1.69–2.04)", lang), fontsize=TICK, color=GREY, va="center")
    ax.text(36.5, 43.0, T("14/14 个家族方向一致", "14/14 families concordant", lang), fontsize=TICK, color=GREY, va="center")
    ax.text(36.5, 39.5, T("时间外测试集不降", "No decay on temporal holdout", lang), fontsize=TICK, color=GREY, va="center")
    ax.text(36.5, 35.0, T("ANM 固有柔性无解释力（ρ = 0.049）", "ANM flexibility uninformative (ρ=0.049)", lang), fontsize=TICK, color=GREY, va="center")
    ax.text(36.5, 31.8, T("界面残基并非整体更易动", "Interfaces not overall more mobile", lang), fontsize=TICK, color=GREY, va="center")

    ax.text(70, 55.0, T("⑥ 任务三：功能边界", "6  Task 3: functional boundary", lang), fontsize=FS, fontweight="bold", color=ec3, va="center")
    ax.text(70, 50.5, T("SKEMPI ΔΔG：可塑性分数无增量", "SKEMPI ΔΔG: no added gain", lang), fontsize=TICK, color=GREY, va="center")
    ax.text(70, 47.0, T("（Δρ = +0.007，CI 跨 0）", "(Δρ = +0.007, CI crosses 0)", lang), fontsize=TICK, color=GREY, va="center")
    ax.text(70, 43.0, T("疾病变异无界面富集", "Disease variants not enriched", lang), fontsize=TICK, color=GREY, va="center")
    ax.text(70, 39.5, T("（OR 1.10 · p = 0.82）", "(OR 1.10 · p = 0.82)", lang), fontsize=TICK, color=GREY, va="center")
    ax.text(70, 35.0, T("界面 6 个变异均有机制注释", "6 interface variants annotated", lang), fontsize=TICK, color=GREY, va="center")
    ax.text(70, 31.8, T("信号限于几何层面", "Signal is geometric in nature", lang), fontsize=TICK, color=GREY, va="center")

    # ---- Row 2 → Row 3 arrows ----
    arrow(ax, 16.5, 29.4, 24.0, 22.6)
    arrow(ax, 50.0, 29.4, 44.0, 22.6)
    arrow(ax, 83.5, 29.4, 83.5, 22.6)

    # ---- Row 3 ----
    fcG, ecG = "#fdf6d8", "#7a6a1f"
    fcC, ecC = "#ece5f5", "#4b3a72"
    box(ax, 1, 2, 64, 20, fcG, ecG)
    box(ax, 68, 2, 31, 20, fcC, ecC)
    arrow(ax, 65.6, 12, 67.4, 12, color="#7a6a8f")

    ax.text(3, 18.0, T("⑦ 跨体系泛化验证", "7  Cross-system generalization", lang), fontsize=FS, fontweight="bold", color=ecG, va="center")
    ax.text(3, 14.2, T("钙调蛋白 3 对 + 核受体 LBD 5 对：结合态信号 8/8 高于 apo", "CaM 3 + NR LBD 5 pairs: holo > apo 8/8", lang), fontsize=TICK, color=GREY, va="center")
    ax.text(3, 10.9, T("apo 侧按界面是否成形分层（apo AUC 0.32–0.78 · apo lift 0.81–5.63）", "apo stratified by pocket (AUC 0.32–0.78)", lang), fontsize=TICK, color=GREY, va="center")
    ax.text(3, 7.2, T("连同 BM5.5 九类别构成十二组对照，", "+ BM5.5 (9 classes): 12-group comparison", lang), fontsize=TICK, color=GREY, va="center")
    ax.text(3, 4.0, T("覆盖预成–重排的连续谱", "preformed → rearranged spectrum", lang), fontsize=TICK, color=GREY, va="center")

    ax.text(70, 18.0, T("⑧ 可计算边界", "8  Computable boundary", lang), fontsize=FS, fontweight="bold", color=ecC, va="center")
    ax.text(70, 13.5, T("界面定位：条件可计算，", "Interface: conditional — set by", lang), fontsize=TICK, color=GREY, va="center")
    ax.text(70, 9.5, T("由 apo–holo 叠合 RMSD 决定", "the apo–holo RMSD", lang), fontsize=TICK, color=GREY, va="center")
    ax.text(70, 5.0, T("可塑性：apo 局部几何直接可读", "Plasticity: readable from apo geometry", lang), fontsize=TICK, color=GREY, va="center")

    d = OUT / lang
    d.mkdir(parents=True, exist_ok=True)
    p = d / f"Fig1_overview_{lang}.tiff"
    fig.savefig(p, pil_kwargs={"compression": "tiff_lzw"})
    fig.savefig(PREV / f"Fig1_overview_{lang}.png", dpi=150)
    plt.close(fig)
    print("saved", p)


for lang in ("zh", "en"):
    setup(lang)
    fig01(lang)
