from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "results"
OUT = RESULTS / "Step42_final_evidence"
OUT.mkdir(parents=True, exist_ok=True)


def read_json(relative: str):
    return json.loads((RESULTS / relative).read_text(encoding="utf-8"))


def read_csv(relative: str):
    with (RESULTS / relative).open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def row_by(rows, **criteria):
    for row in rows:
        if all(row.get(key) == value for key, value in criteria.items()):
            return row
    raise KeyError(criteria)


bm5 = read_json("Step29_bm5_zero_homology/zero_homology_summary.json")
generalization = read_json("Step24_generalization_summary/generalization_summary.json")
abbind = read_json("Step30_abbind_preparation/abbind_preparation_summary.json")
abbind_novel = read_json("Step31_abbind_novel_complexes/novel_complex_summary.json")
abbind_holdout = read_json("Step35_abbind_functional_holdout/functional_holdout_summary.json")
biolip = read_json("Step39_biolip_frozen_cases/frozen_case_summary.json")
statistics = read_json("Step38_external_statistics/statistics_summary.json")
metrics = read_csv("Step38_external_statistics/bm5_metrics_calibration.csv")
bootstrap = read_csv("Step38_external_statistics/bm5_bootstrap_complex.csv")
cluster_bootstrap = read_csv("Step38_external_statistics/bm5_bootstrap_homology_cluster.csv")
abbind_metrics = read_csv("Step38_external_statistics/abbind_functional_metrics.csv")
abbind_bootstrap = read_csv("Step38_external_statistics/abbind_complex_bootstrap.csv")
contrast = read_csv("Step38_external_statistics/bm5_unbound_bound_paired_contrast.csv")
topk = read_csv("Step38_external_statistics/bm5_topk_enrichment.csv")
categories = read_csv("Step38_external_statistics/bm5_primary_metrics_by_category.csv")
case_metrics = read_csv("Step39_biolip_frozen_cases/case_metrics.csv")
case_homology = read_csv("Step39_biolip_frozen_cases/training_homology_audit.csv")
primary_metrics = read_csv("Step32_bm5_frozen_models/random_forest/base_structure/external_metrics.csv")

primary = row_by(metrics, model="RF_base_structure")
primary_auc = row_by(bootstrap, model="RF_base_structure", metric="AUC")
primary_auprc = row_by(bootstrap, model="RF_base_structure", metric="AUPRC")
unbound = row_by(primary_metrics, seed="ENSEMBLE", state="UNBOUND")
auc_contrast = row_by(contrast, metric="AUC")
auprc_contrast = row_by(contrast, metric="AUPRC")
ab_all_contact = row_by(abbind_metrics, stratum="ALL", model="contact_only")
ab_all_multi = row_by(abbind_metrics, stratum="ALL", model="multitask")
ab_pdb_contact = row_by(abbind_metrics, stratum="PDB_DISJOINT", model="contact_only")
ab_pdb_multi = row_by(abbind_metrics, stratum="PDB_DISJOINT", model="multitask")
ab_multi_spearman = row_by(abbind_bootstrap, stratum="ALL", model="multitask", metric="Spearman")
ab_multi_auc = row_by(abbind_bootstrap, stratum="ALL", model="multitask", metric="hotspot_AUC")

risk_rows = [
    {
        "风险编号": "R01",
        "危险表述": "5 Å 几何接触残基就是功能结合热点。",
        "审稿质疑": "接触标签只描述结构邻近，不等同于突变导致的结合自由能变化。",
        "已补实验": "在 AB-Bind 上按复合物完全留出重训，并比较接触、功能单任务和多任务模型。",
        "真实结果": f"AB-Bind 全量接触模型 Spearman={float(ab_all_contact['Spearman']):.6f}、热点 AUC={float(ab_all_contact['hotspot_AUC']):.6f}，仅为中等关联。",
        "允许结论": "几何接触可用于界面候选优先级排序，功能敏感性需独立评价。",
        "剩余限制": "接触与功能标签不可互换；AB-Bind 与 SKEMPI 存在数据库重叠。",
    },
    {
        "风险编号": "R02",
        "危险表述": "接触—功能多任务学习稳定提高外部功能预测。",
        "审稿质疑": "小样本内部留出可能产生偶然收益，外部数据库可能推翻该结论。",
        "已补实验": "排除全部 AB-Bind PDB 后重训；实施 2,000 次复合物 bootstrap。",
        "真实结果": f"全量多任务 Spearman={float(ab_all_multi['Spearman']):.6f}，相对接触模型差值 95% CI {float(ab_multi_spearman['difference_ci_low']):.6f} 至 {float(ab_multi_spearman['difference_ci_high']):.6f}；热点 AUC 差值 CI {float(ab_multi_auc['difference_ci_low']):.6f} 至 {float(ab_multi_auc['difference_ci_high']):.6f}。",
        "允许结论": "多任务监督在外部功能任务上未形成优势，不作为主要创新结论。",
        "剩余限制": "模型为残基分辨率，且 PDB 独立子集仅 3 个复合物。",
    },
    {
        "风险编号": "R03",
        "危险表述": "主模型在所有指标上显著优于全部基线。",
        "审稿质疑": "只比较 AUC 会掩盖不平衡任务中的精确率—召回率不足。",
        "已补实验": "统一零同源划分比较 10 个配置，复合物和同源簇各 1,000 次 bootstrap，Holm 校正。",
        "真实结果": "主模型 AUC 相对多数基线显著；对 ESM35M+结构 AUC 的校正 p=0.069930；对 LightGBM 和逻辑回归 AUPRC 的校正 p 均为 0.811189，逻辑回归 AUPRC 点估计更高。",
        "允许结论": "主模型具有较稳定的 AUC 优势，但 AUPRC 并非全面显著优势。",
        "剩余限制": "不同 bootstrap 分组下部分显著性减弱；不应只报告有利比较。",
    },
    {
        "风险编号": "R04",
        "危险表述": "apo 与 holo 预测完全等价，构象迁移没有损失。",
        "审稿质疑": "未结合态结构可能改变局部表面几何并降低界面识别。",
        "已补实验": "在 BM5 同一残基上配对比较结合态与非结合态，并按复合物 bootstrap 差值。",
        "真实结果": f"AUC 差值={float(auc_contrast['observed_unbound_minus_bound']):.6f}（95% CI {float(auc_contrast['ci_low']):.6f} 至 {float(auc_contrast['ci_high']):.6f}）；AUPRC 差值={float(auprc_contrast['observed_unbound_minus_bound']):.6f}（95% CI {float(auprc_contrast['ci_low']):.6f} 至 {float(auprc_contrast['ci_high']):.6f}）。",
        "允许结论": "外部 apo 迁移存在幅度较小但可测的性能下降。",
        "剩余限制": "平均差值不能代表每个复合物；局部构象变化具有异质性。",
    },
    {
        "风险编号": "R05",
        "危险表述": "时间外高指标证明未知同源蛋白泛化。",
        "审稿质疑": "时间切分并不自动消除同源簇重叠。",
        "已补实验": "审计时间外同源簇，并增加 BM5 零同源外部集。",
        "真实结果": f"时间外 AUC={generalization['frozen_temporal']['AUC']:.6f}、AUPRC={generalization['frozen_temporal']['AUPRC']:.6f}，但 12 个时间外同源簇中 11 个已在开发集；BM5 外部 AUC={float(primary['AUC']):.6f}。",
        "允许结论": "时间外结果仅支持后续已知同源结构上的迁移。",
        "剩余限制": "外部性能明显低于时间外点估计，需以零同源结果为主要泛化证据。",
    },
    {
        "风险编号": "R06",
        "危险表述": "三个 BioLiP 案例均为独立正面验证。",
        "审稿质疑": "训练同源污染和失败案例会造成选择性报告。",
        "已补实验": "冻结预测后审计每个案例与训练受体的全局序列同一性。",
        "真实结果": "1G0Y、5VBL 与训练受体最高同一性分别为 100% 和 82.7%；零同源 8J6F 仅 14 个窗口，接触 AUC=0.325000、BioLiP 注释 AUC=0.333333。",
        "允许结论": "1G0Y 和 5VBL 仅为同源迁移案例；8J6F 揭示失败边界。",
        "剩余限制": "案例数量少，8J6F 样本尤其有限，不能作总体性能推断。",
    },
    {
        "风险编号": "R07",
        "危险表述": "疾病变异结果证明临床判别或致病机制。",
        "审稿质疑": "严格良性对照不足，VUS 不能作为良性人群对照。",
        "已补实验": "严格 ClinVar 映射、Fisher 检验及野生型氨基酸和 RSA 匹配经验检验。",
        "真实结果": "仅 17 个 P/LP 和 1 个严格 B/LB 结构残基；敏感性分析 Fisher p=0.453，匹配经验 p=0.247。",
        "允许结论": "疾病变异分析仅用于界定数据与统计效能边界。",
        "剩余限制": "不能作临床有效性、致病机制阴性或人群风险结论。",
    },
    {
        "风险编号": "R08",
        "危险表述": "模型可预测每个氨基酸替换的突变特异 ΔΔG。",
        "审稿质疑": "输入不含突变型氨基酸，同一残基的多个替换会得到相同表示。",
        "已补实验": "以同一野生型残基的实验 ΔΔG 均值作为主要终点，逐突变仅作映射审计。",
        "真实结果": f"AB-Bind 评价单位为 {abbind_holdout['external_residues']} 个残基、{abbind_novel['all_mapped_mutations']} 条映射突变。",
        "允许结论": "模型评价的是残基扰动敏感性，而非替换特异性自由能预测。",
        "剩余限制": "需要显式突变型输入才能研究不同替换之间的差异。",
    },
    {
        "风险编号": "R09",
        "危险表述": "已证明优于当前所有界面预测方法。",
        "审稿质疑": "缺少与已发表方法在完全相同划分和标签上的复现比较。",
        "已补实验": "补充传统模型、ESM2-8M、ESM2-35M 及结构组合的统一外部评价。",
        "真实结果": "主模型在零同源集 AUC 具有较稳定优势，但 ESM35M+结构的 AUC 差异未达校正显著，AUPRC 也非全面领先。",
        "允许结论": "结论限于本研究实现的基线与统一数据条件。",
        "剩余限制": "未复现 ScanNet、PeSTo 等已发表方法的同划分结果，不能作领域全面领先声明。",
    },
    {
        "风险编号": "R10",
        "危险表述": "AB-Bind 是完全独立数据库验证。",
        "审稿质疑": "AB-Bind 与 SKEMPI 在 PDB 和具体突变层面存在大量重叠。",
        "已补实验": "量化精确重叠；排除全部 AB-Bind PDB 后重训；单独报告 PDB 不重叠子集。",
        "真实结果": f"623 条原始单点突变中 260 条与 SKEMPI 精确重叠；精确重叠 ΔΔG Spearman={abbind['exact_overlap_spearman']:.6f}；PDB 独立子集仅 {abbind_novel['pdb_disjoint_complexes']} 个复合物、{abbind_novel['pdb_disjoint_functional_residues']} 个残基。",
        "允许结论": "AB-Bind 是重训后的复合物留出评价，PDB 不重叠子集仅作探索性补充。",
        "剩余限制": "不能将数据库名称不同等同于证据完全独立。",
    },
    {
        "风险编号": "R11",
        "危险表述": "模型已解决代谢炎症界面预测并可普遍部署。",
        "审稿质疑": "训练规模、独立同源簇数量、阳性率和家族异质性限制广泛适用性。",
        "已补实验": "同源簇五折、留一家族、时间外与 269 复合物零同源外部评价联合审计。",
        "真实结果": f"主训练仅 122 组界面；外部主模型 AUC={float(primary['AUC']):.6f}、AUPRC={float(primary['AUPRC']):.6f}，外部阳性率={bm5['zero_homology_positive_rate']:.6f}。",
        "允许结论": "模型适合作为结构覆盖范围内的候选排序工具，并需按适用域解释。",
        "剩余限制": "类别不平衡、复合物类型差异和有限训练规模仍限制精度与普适性。",
    },
    {
        "风险编号": "R12",
        "危险表述": "高 AUC 已足以证明实际候选筛选价值。",
        "审稿质疑": "在不平衡数据中，校准、前列富集和绝对精确率比单一 AUC 更接近使用场景。",
        "已补实验": "报告 Brier、ECE15、Top 1%/5% 精确率和富集，并按复合物类别分层。",
        "真实结果": f"Brier={float(primary['Brier']):.6f}、ECE15={float(primary['ECE15']):.6f}；Top 1% 精确率={float(row_by(topk, model='RF_base_structure', top_fraction='0.01')['precision_at_k']):.6f}，Top 5% 精确率={float(row_by(topk, model='RF_base_structure', top_fraction='0.05')['precision_at_k']):.6f}。",
        "允许结论": "模型在前列候选中呈现富集，但概率校准和绝对精确率仍需改进。",
        "剩余限制": "富集不等于实验确认率，阈值相关指标对校准敏感。",
    },
]

risk_path = OUT / "review_risk_matrix.csv"
with risk_path.open("w", encoding="utf-8-sig", newline="") as handle:
    writer = csv.DictWriter(handle, fieldnames=list(risk_rows[0]))
    writer.writeheader()
    writer.writerows(risk_rows)

abb_path = ROOT / "data/raw/external/abbind/AB-Bind_experimental_data.csv"
abb_sha256 = hashlib.sha256(abb_path.read_bytes()).hexdigest() if abb_path.exists() else None

summary = {
    "status": "COMPLETE_FROM_FROZEN_REAL_OUTPUTS",
    "risk_rows": len(risk_rows),
    "bm5_zero_homology": bm5,
    "bm5_primary": {
        "model": primary["model"],
        "bound": {key: float(primary[key]) for key in ["AUC", "AUPRC", "MCC", "F1", "Brier", "ECE15"]},
        "auc_complex_ci95": [float(primary_auc["ci_low"]), float(primary_auc["ci_high"])],
        "auprc_complex_ci95": [float(primary_auprc["ci_low"]), float(primary_auprc["ci_high"])],
        "unbound": {"AUC": float(unbound["AUC"]), "AUPRC": float(unbound["AUPRC"])},
        "unbound_minus_bound": {
            "AUC": {key: float(auc_contrast[key]) for key in ["observed_unbound_minus_bound", "ci_low", "ci_high"]},
            "AUPRC": {key: float(auprc_contrast[key]) for key in ["observed_unbound_minus_bound", "ci_low", "ci_high"]},
        },
        "topk": [row for row in topk if row["model"] == "RF_base_structure"],
    },
    "bm5_category_count": len(categories),
    "bm5_category_window_sum": sum(int(row["n"]) for row in categories),
    "bm5_bootstrap": {
        "complex_replicates": statistics["complex_bootstrap_replicates"],
        "homology_cluster_replicates": statistics["cluster_bootstrap_replicates"],
        "comparison_rows": len(bootstrap),
        "cluster_comparison_rows": len(cluster_bootstrap),
    },
    "abbind": {
        "preparation": abbind,
        "novel_complexes": abbind_novel,
        "holdout": abbind_holdout,
        "metrics": abbind_metrics,
        "bootstrap": abbind_bootstrap,
        "source_csv": str(abb_path),
        "source_csv_sha256": abb_sha256,
    },
    "biolip": {
        "summary": biolip,
        "metrics": case_metrics,
        "homology_audit": case_homology,
    },
    "interpretation": {
        "supported": "Zero-homology external contact ranking with modest discrimination and top-ranked enrichment.",
        "not_supported": [
            "universal superiority across AUPRC and all baselines",
            "stable external advantage of functional multitask supervision",
            "independent positive BioLiP validation for all three cases",
            "unknown-homology interpretation of temporal validation",
            "clinical variant interpretation",
            "mutation-specific ddG prediction",
        ],
    },
}
(OUT / "evidence_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")

checks = {
    "risk_rows_at_least_11": len(risk_rows) >= 11,
    "bm5_window_totals_match": int(primary["n"]) == bm5["zero_homology_windows"] == 115215,
    "bm5_category_totals_match": sum(int(row["n"]) for row in categories) == bm5["zero_homology_windows"],
    "bm5_category_complex_totals_match": sum(int(row["complexes"]) for row in categories) == bm5["zero_homology_complexes"],
    "abbind_all_residues_match": int(ab_all_contact["n"]) == abbind_holdout["external_residues"] == 246,
    "abbind_pdb_disjoint_residues_match": int(ab_pdb_contact["n"]) == abbind_holdout["pdb_disjoint_residues"] == 31,
    "biolip_case_count_match": len({row["pdb_id"] for row in case_metrics}) == biolip["direct_cases"] == 3,
    "abb_bind_source_present": abb_path.exists(),
}
(OUT / "evidence_audit.json").write_text(json.dumps({"passed": all(checks.values()), "checks": checks}, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps({"output": str(OUT), "checks": checks, "passed": all(checks.values())}, ensure_ascii=False, indent=2))
if not all(checks.values()):
    raise SystemExit(1)
