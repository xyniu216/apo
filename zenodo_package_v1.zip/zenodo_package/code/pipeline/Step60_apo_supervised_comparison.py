"""Unified contact-only, apo-augmentation and apo-holo-consistency comparison without functional labels."""
from __future__ import annotations

import json
import time
from pathlib import Path
import numpy as np
import pandas as pd
import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset
from sklearn.metrics import roc_auc_score, average_precision_score
from sklearn.model_selection import StratifiedGroupKFold

from Step07_multitask_skempi import MultiTaskNet, predict

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "results/Step60_apo_supervised_comparison"
VARIANTS = ("contact_only", "apo_augmentation", "apo_holo_consistency")
SEEDS = (42, 43, 44)
SPLIT_SEED = 20261028
EPOCHS = 12
torch.set_num_threads(4)


def metrics(y, score) -> dict:
    y = np.asarray(y, dtype=int)
    score = np.asarray(score, dtype=float)
    order = np.argsort(-score, kind="stable")
    return {"windows": len(y), "positive_rate": float(y.mean()), "AUC": float(roc_auc_score(y, score)),
            "AUPRC": float(average_precision_score(y, score)),
            "Top1_precision": float(y[order[:max(1, int(np.ceil(len(y) * .01))) ]].mean()),
            "Top5_precision": float(y[order[:max(1, int(np.ceil(len(y) * .05))) ]].mean())}


def train_variant(kind, hx, hy, ax, ay, ph, pa, seed, epochs=EPOCHS):
    torch.manual_seed(seed)
    np.random.seed(seed)
    model = MultiTaskNet(hx.shape[1])
    optimizer = torch.optim.AdamW(model.parameters(), lr=1e-3, weight_decay=1e-4)
    pos_weight = torch.tensor(float(((hy == 0).sum() / max((hy == 1).sum(), 1)) ** 0.5))
    weighted_bce = nn.BCEWithLogitsLoss(pos_weight=pos_weight)
    apo_bce = nn.BCEWithLogitsLoss()
    generator = torch.Generator().manual_seed(seed)
    holo_loader = DataLoader(TensorDataset(torch.from_numpy(hx), torch.from_numpy(hy.astype(np.float32))),
                             batch_size=1024, shuffle=True, generator=generator)
    apo_loader = DataLoader(TensorDataset(torch.from_numpy(ax), torch.from_numpy(ay.astype(np.float32))),
                            batch_size=1024, shuffle=True, generator=generator)
    pair_loader = DataLoader(TensorDataset(torch.from_numpy(ph), torch.from_numpy(pa)),
                             batch_size=1024, shuffle=True, generator=generator)
    for _ in range(epochs):
        model.train()
        apo_iter, pair_iter = iter(apo_loader), iter(pair_loader)
        for xh, yh in holo_loader:
            optimizer.zero_grad()
            ch, _ = model(xh)
            loss = weighted_bce(ch, yh)
            if kind in ("apo_augmentation", "apo_holo_consistency"):
                try:
                    xa, ya = next(apo_iter)
                except StopIteration:
                    apo_iter = iter(apo_loader)
                    xa, ya = next(apo_iter)
                ca, _ = model(xa)
                loss = loss + 0.5 * apo_bce(ca, ya)
            if kind == "apo_holo_consistency":
                try:
                    xph, xpa = next(pair_iter)
                except StopIteration:
                    pair_iter = iter(pair_loader)
                    xph, xpa = next(pair_iter)
                cph, _ = model(xph)
                cpa, _ = model(xpa)
                loss = loss + 0.2 * nn.functional.mse_loss(torch.sigmoid(cph), torch.sigmoid(cpa))
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            optimizer.step()
    return model


def paired_arrays(apo_meta, holo_index, apo_indices):
    paired = apo_indices[apo_meta.holo_window_id.iloc[apo_indices].fillna("").ne("").to_numpy()]
    holo = apo_meta.holo_window_id.iloc[paired].map(holo_index).astype(int).to_numpy()
    return holo, paired


def bootstrap_delta(external, score_columns, iterations=1000):
    rng = np.random.default_rng(20261029)
    complexes = np.array(sorted(external.complex_id.unique()))
    parts = {key: part for key, part in external.groupby("complex_id", sort=True)}
    rows = []
    for iteration in range(iterations):
        sampled = rng.choice(complexes, size=len(complexes), replace=True)
        boot = pd.concat([parts[key] for key in sampled], ignore_index=True)
        row = {"iteration": iteration}
        for state, suffix in (("holo", "holo"), ("apo", "apo")):
            baseline = average_precision_score(boot.label, boot[f"contact_only_{suffix}"])
            for variant in VARIANTS:
                value = average_precision_score(boot.label, boot[f"{variant}_{suffix}"])
                row[f"{variant}_{suffix}_AUPRC"] = value
                if variant != "contact_only":
                    row[f"{variant}_minus_contact_{suffix}"] = value - baseline
        rows.append(row)
    return pd.DataFrame(rows)


def main():
    started = time.time()
    OUT.mkdir(parents=True, exist_ok=True)
    holo_meta = pd.read_csv(ROOT / "data/processed/holo/window_metadata.csv")
    holo_archive = np.load(ROOT / "data/processed/holo/holo_features.npz")
    holo_all = np.nan_to_num(np.concatenate([holo_archive["base"], holo_archive["structure"]], 1).astype(np.float32))
    apo_meta = pd.read_csv(ROOT / "data/processed/apo/apo_window_metadata.csv")
    apo_archive = np.load(ROOT / "data/processed/apo/apo_features.npz")
    apo_all = np.nan_to_num(np.concatenate([apo_archive["base"], apo_archive["structure"]], 1).astype(np.float32))
    dev_index = holo_meta.index[holo_meta.dataset == "DEVELOPMENT"].to_numpy()
    dev = holo_meta.loc[dev_index].reset_index(drop=True)
    holo_index = pd.Series(holo_meta.index, index=holo_meta.window_id)
    splitter = StratifiedGroupKFold(n_splits=5, shuffle=True, random_state=SPLIT_SEED)
    splits = list(splitter.split(dev, dev.label, dev.sequence_cluster))
    development_predictions, development_metrics = [], []
    for fold, (train_local, valid_local) in enumerate(splits, 1):
        train_receptors = set(dev.sequence_cluster.iloc[train_local])
        valid_receptors = set(dev.sequence_cluster.iloc[valid_local])
        train_holo = dev_index[train_local]
        valid_holo = dev_index[valid_local]
        train_apo = apo_meta.index[apo_meta.partner_uniprot.isin(train_receptors) & (apo_meta.dataset == "DEVELOPMENT")].to_numpy()
        valid_apo = apo_meta.index[apo_meta.partner_uniprot.isin(valid_receptors) & (apo_meta.dataset == "DEVELOPMENT")].to_numpy()
        pair_holo, pair_apo = paired_arrays(apo_meta, holo_index, train_apo)
        mean, std = holo_all[train_holo].mean(0), holo_all[train_holo].std(0) + 1e-5
        hx, ax = (holo_all - mean) / std, (apo_all - mean) / std
        for variant in VARIANTS:
            print("DEV", fold, variant, flush=True)
            model = train_variant(variant, hx[train_holo], holo_meta.label.to_numpy()[train_holo],
                                  ax[train_apo], apo_meta.label.to_numpy()[train_apo],
                                  hx[pair_holo], ax[pair_apo], 42)
            for state, indices, source_meta, x in (("holo", valid_holo, holo_meta, hx), ("apo", valid_apo, apo_meta, ax)):
                probability = predict(model, x[indices])[0]
                development_predictions.append(pd.DataFrame({"fold": fold, "variant": variant, "state": state,
                    "window_id": source_meta.window_id.iloc[indices].to_numpy(), "label": source_meta.label.iloc[indices].to_numpy(),
                    "probability": probability}))
                development_metrics.append({"fold": fold, "variant": variant, "state": state,
                                            **metrics(source_meta.label.iloc[indices], probability)})
    pd.concat(development_predictions, ignore_index=True).to_csv(OUT / "development_oof_predictions.csv", index=False)
    development_metrics = pd.DataFrame(development_metrics)
    development_metrics.to_csv(OUT / "development_fold_metrics.csv", index=False)
    development_summary = development_metrics.groupby(["variant", "state"]).agg(mean_AUPRC=("AUPRC", "mean"),
        sd_AUPRC=("AUPRC", "std"), mean_AUC=("AUC", "mean"), mean_Top1_precision=("Top1_precision", "mean")).reset_index()
    development_summary.to_csv(OUT / "development_variant_summary.csv", index=False)
    apo_rank = development_summary[development_summary.state == "apo"].sort_values(["mean_AUPRC", "mean_AUC"], ascending=False)
    selected = str(apo_rank.variant.iloc[0])
    selection = {"basis": "five-fold receptor-isolated development apo AUPRC; one common seed for variant selection",
                 "selected_variant": selected, "external_used_for_selection": False, "epochs": EPOCHS,
                 "functional_or_SKEMPI_labels_used": False}
    (OUT / "development_selection.json").write_text(json.dumps(selection, indent=2), encoding="utf-8")

    external = pd.read_csv(ROOT / "data/processed/external/bm5/window_metadata_zero_homology.csv")
    external_archive = np.load(ROOT / "data/processed/external/bm5/bm5_features_zero_homology.npz")
    bound = np.nan_to_num(np.concatenate([external_archive["base"], external_archive["structure"]], 1).astype(np.float32))
    unbound = np.nan_to_num(np.concatenate([external_archive["unbound_base"], external_archive["unbound_structure"]], 1).astype(np.float32))
    train_apo = apo_meta.index[apo_meta.partner_uniprot.isin(set(dev.sequence_cluster)) & (apo_meta.dataset == "DEVELOPMENT")].to_numpy()
    pair_holo, pair_apo = paired_arrays(apo_meta, holo_index, train_apo)
    mean, std = holo_all[dev_index].mean(0), holo_all[dev_index].std(0) + 1e-5
    hx, ax = (holo_all - mean) / std, (apo_all - mean) / std
    bx, ux = (bound - mean) / std, (unbound - mean) / std
    seed_frames = []
    for seed in SEEDS:
        for variant in VARIANTS:
            print("EXTERNAL", seed, variant, flush=True)
            model = train_variant(variant, hx[dev_index], holo_meta.label.to_numpy()[dev_index],
                                  ax[train_apo], apo_meta.label.to_numpy()[train_apo], hx[pair_holo], ax[pair_apo], seed)
            seed_frames.append(pd.DataFrame({"window_id": external.window_id, "seed": seed, "variant": variant,
                "holo": predict(model, bx)[0], "apo": predict(model, ux)[0]}))
    seeds = pd.concat(seed_frames, ignore_index=True)
    seeds.to_csv(OUT / "bm5_seed_predictions.csv", index=False)
    ensemble = seeds.groupby(["window_id", "variant"])[["holo", "apo"]].mean().reset_index()
    wide = ensemble.pivot(index="window_id", columns="variant", values=["holo", "apo"])
    wide.columns = [f"{variant}_{state}" for state, variant in wide.columns]
    external = external.merge(wide.reset_index(), on="window_id", validate="one_to_one")
    external.to_csv(OUT / "bm5_ensemble_predictions.csv", index=False)
    rows = []
    for variant in VARIANTS:
        for state in ("holo", "apo"):
            rows.append({"variant": variant, "state": state, "selected_on_development": variant == selected,
                         **metrics(external.label, external[f"{variant}_{state}"])})
    external_metrics = pd.DataFrame(rows)
    external_metrics.to_csv(OUT / "bm5_external_metrics.csv", index=False)
    bootstrap = bootstrap_delta(external, VARIANTS)
    bootstrap.to_csv(OUT / "complex_bootstrap_iterations.csv", index=False)
    intervals = []
    for variant in VARIANTS[1:]:
        for state in ("holo", "apo"):
            column = f"{variant}_minus_contact_{state}"
            intervals.append({"comparison": column, "mean_delta_AUPRC": bootstrap[column].mean(),
                              "ci95_low": bootstrap[column].quantile(.025), "ci95_high": bootstrap[column].quantile(.975),
                              "probability_delta_gt_0": float((bootstrap[column] > 0).mean())})
    intervals = pd.DataFrame(intervals)
    intervals.to_csv(OUT / "paired_complex_bootstrap_ci.csv", index=False)
    gates = []
    for variant in VARIANTS[1:]:
        apo_row = external_metrics[(external_metrics.variant == variant) & (external_metrics.state == "apo")].iloc[0]
        contact_apo = external_metrics[(external_metrics.variant == "contact_only") & (external_metrics.state == "apo")].iloc[0]
        holo_variant = external_metrics[(external_metrics.variant == variant) & (external_metrics.state == "holo")].iloc[0]
        contact_holo = external_metrics[(external_metrics.variant == "contact_only") & (external_metrics.state == "holo")].iloc[0]
        apo_gain = apo_row.AUPRC - contact_apo.AUPRC
        apo_interval = intervals[intervals.comparison == f"{variant}_minus_contact_apo"].iloc[0]
        holo_loss = contact_holo.AUPRC - holo_variant.AUPRC
        gates.append({"variant": variant, "apo_AUPRC_gain": apo_gain, "apo_ci95_low": apo_interval.ci95_low,
                      "holo_AUPRC_loss": holo_loss, "meets_suggested_gate": bool(apo_gain >= .01 and apo_interval.ci95_low > 0 and holo_loss <= .005)})
    pd.DataFrame(gates).to_csv(OUT / "prespecified_success_gate.csv", index=False)
    summary = {"selected_variant": selected, "development_folds": 5, "final_seeds": list(SEEDS), "epochs": EPOCHS,
               "external_windows": len(external), "external_complexes": external.complex_id.nunique(),
               "SKEMPI_or_functional_labels_used": False, "elapsed_seconds": time.time() - started}
    (OUT / "run_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(development_summary.to_string(index=False))
    print(external_metrics.to_string(index=False))
    print(intervals.to_string(index=False))


if __name__ == "__main__":
    main()
