"""Complete frozen zero-training PeSTo analysis without fitting or selecting models."""
from __future__ import annotations

import json
import time
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import spearmanr
from sklearn.metrics import average_precision_score, roc_auc_score

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "results/Step65_pesto_zero_training_reanalysis"
BM5_DATA = ROOT / "data/processed/external/bm5"
BM5_PRED = ROOT / "results/Step57_published_baselines/pesto_per_chain"
SEED = 20261029


def metric_row(frame: pd.DataFrame, score: str, label: str = "label", **identity) -> dict:
    y = frame[label].to_numpy(dtype=int)
    values = frame[score].to_numpy(dtype=float)
    if np.isnan(values).any():
        raise ValueError(f"Missing scores in {identity}")
    prevalence = float(y.mean()) if len(y) else np.nan
    row = {**identity, "windows": int(len(frame)), "positives": int(y.sum()),
           "prevalence": prevalence}
    if len(frame) == 0 or len(np.unique(y)) < 2:
        row.update({"AUC": np.nan, "AUPRC": np.nan, "normalized_AUPRC": np.nan,
                    "Top1_precision": np.nan, "Top5_precision": np.nan})
    else:
        auc = float(roc_auc_score(y, values))
        auprc = float(average_precision_score(y, values))
        order = np.argsort(-values, kind="stable")
        row.update({"AUC": auc, "AUPRC": auprc,
                    "normalized_AUPRC": auprc / prevalence if prevalence > 0 else np.nan,
                    "Top1_precision": float(y[order[:max(1, int(np.ceil(len(y) * .01))) ]].mean()),
                    "Top5_precision": float(y[order[:max(1, int(np.ceil(len(y) * .05))) ]].mean())})
    return row


def load_state_predictions(record_ids: list[str], state: str, directory: Path) -> tuple[pd.DataFrame, pd.DataFrame]:
    frames = []
    audits = []
    for record_id in record_ids:
        path = directory / f"{record_id}_{state}.csv"
        if not path.exists():
            raise FileNotFoundError(path)
        block = pd.read_csv(path)
        required = {"record_id", "auth_seq_id", "pesto_protein"}
        if not required.issubset(block.columns) or block.empty:
            raise ValueError(f"Invalid prediction file: {path}")
        if block.pesto_protein.isna().any():
            raise ValueError(f"Missing probability: {path}")
        audits.append({"record_id": record_id, "state": state, "residue_rows": len(block),
                       "probability_min": block.pesto_protein.min(), "probability_max": block.pesto_protein.max()})
        frames.append(block[["record_id", "auth_seq_id", "pesto_protein"]])
    predictions = pd.concat(frames, ignore_index=True)
    duplicates = predictions[predictions.duplicated(["record_id", "auth_seq_id"], keep=False)].copy()
    predictions = predictions.groupby(["record_id", "auth_seq_id"], as_index=False).agg(
        pesto_protein=("pesto_protein", "mean"), duplicate_source_rows=("pesto_protein", "size"))
    return predictions, pd.DataFrame(audits).assign(duplicate_rows=len(duplicates))


def merge_scores(meta: pd.DataFrame, directory: Path, states: list[str]) -> tuple[pd.DataFrame, pd.DataFrame]:
    merged = meta.copy()
    audits = []
    for state in states:
        prediction, audit = load_state_predictions(sorted(meta.record_id.unique()), state, directory)
        prediction = prediction.rename(columns={"pesto_protein": f"pesto_{state}"})
        merged = merged.merge(prediction[["record_id", "auth_seq_id", f"pesto_{state}"]],
                              on=["record_id", "auth_seq_id"], how="left", validate="one_to_one", indicator=f"merge_{state}")
        if not (merged[f"merge_{state}"] == "both").all():
            counts = merged[f"merge_{state}"].value_counts().to_dict()
            raise ValueError(f"Incomplete {state} matching: {counts}")
        merged = merged.drop(columns=f"merge_{state}")
        audits.append(audit)
    return merged, pd.concat(audits, ignore_index=True)


def per_unit(frame: pd.DataFrame, unit: str, scores: list[str], dataset: str) -> pd.DataFrame:
    rows = []
    for key, part in frame.groupby(unit, sort=True):
        for score in scores:
            rows.append(metric_row(part, score, dataset=dataset, unit=unit, value=str(key), model=score,
                                   complexes=part.complex_id.nunique() if "complex_id" in part else np.nan,
                                   chains=part.record_id.nunique()))
    return pd.DataFrame(rows)


def macro_complex(frame: pd.DataFrame, scores: list[str]) -> tuple[pd.DataFrame, pd.DataFrame]:
    complex_metrics = per_unit(frame, "complex_id", scores, "BM5.5")
    macro = complex_metrics.groupby("model").agg(
        evaluable_complexes=("AUPRC", "count"), macro_complex_AUC=("AUC", "mean"),
        median_complex_AUC=("AUC", "median"), macro_complex_AUPRC=("AUPRC", "mean"),
        median_complex_AUPRC=("AUPRC", "median"), macro_normalized_AUPRC=("normalized_AUPRC", "mean")).reset_index()
    return complex_metrics, macro


def bm5_bootstrap(frame: pd.DataFrame, scores: list[str], iterations: int = 1000) -> pd.DataFrame:
    rng = np.random.default_rng(SEED)
    complexes = np.array(sorted(frame.complex_id.unique()))
    parts = {key: part for key, part in frame.groupby("complex_id", sort=True)}
    rows = []
    for iteration in range(iterations):
        sampled = rng.choice(complexes, size=len(complexes), replace=True)
        boot = pd.concat([parts[key] for key in sampled], ignore_index=True)
        y = boot.label.to_numpy(dtype=int)
        row = {"iteration": iteration}
        for score in scores:
            values = boot[score].to_numpy(dtype=float)
            row[f"{score}_AUC"] = roc_auc_score(y, values)
            row[f"{score}_AUPRC"] = average_precision_score(y, values)
        row["PeSTo_apo_minus_holo_AUC"] = row["pesto_apo_AUC"] - row["pesto_holo_AUC"]
        row["PeSTo_apo_minus_holo_AUPRC"] = row["pesto_apo_AUPRC"] - row["pesto_holo_AUPRC"]
        row["RF_apo_minus_holo_AUC"] = row["rf_holo_AUC"] * 0 + row["rf_apo_AUC"] - row["rf_holo_AUC"]
        row["RF_apo_minus_holo_AUPRC"] = row["rf_apo_AUPRC"] - row["rf_holo_AUPRC"]
        rows.append(row)
    return pd.DataFrame(rows)


def interval_table(frame: pd.DataFrame, skip: str = "iteration") -> pd.DataFrame:
    rows = []
    for column in frame.columns:
        if column == skip:
            continue
        values = frame[column].dropna()
        rows.append({"metric": column, "mean": values.mean(), "ci95_low": values.quantile(.025),
                     "ci95_high": values.quantile(.975), "iterations": len(values)})
    return pd.DataFrame(rows)


def analyze_bm5() -> tuple[pd.DataFrame, dict]:
    print("BM5: loading and matching predictions", flush=True)
    meta = pd.read_csv(BM5_DATA / "window_metadata_zero_homology.csv")
    frame, inference_audit = merge_scores(meta, BM5_PRED, ["holo" if False else "bound", "unbound"])
    frame = frame.rename(columns={"pesto_bound": "pesto_holo", "pesto_unbound": "pesto_apo"})
    rf = pd.read_csv(ROOT / "results/Step32_bm5_frozen_models/random_forest/base_structure/ensemble_predictions.csv",
                     usecols=["window_id", "probability", "unbound_probability"])
    frame = frame.merge(rf.rename(columns={"probability": "rf_holo", "unbound_probability": "rf_apo"}),
                        on="window_id", how="left", validate="one_to_one")
    scores = ["pesto_holo", "pesto_apo", "rf_holo", "rf_apo"]
    if frame[scores].isna().any().any():
        raise ValueError("Missing BM5 model scores")
    chains = pd.read_csv(BM5_DATA / "chain_sequences_zero_homology.csv")
    keep = ["record_id", "max_training_identity", "max_training_coverage", "direct_pdb_overlap"]
    frame = frame.merge(chains[keep], on="record_id", how="left", validate="many_to_one")
    frame["identity_percent"] = 100 * frame.max_training_identity
    frame["identity_stratum"] = pd.cut(frame.identity_percent, bins=[-np.inf, 20, 30, 40, np.inf],
        right=False, labels=["identity_lt_20", "identity_20_30", "identity_30_40", "identity_ge_40"])
    frame.to_csv(OUT / "bm5_paired_residue_scores.csv", index=False)
    inference_audit.to_csv(OUT / "bm5_inference_audit.csv", index=False)

    rows = []
    for score in scores:
        rows.append(metric_row(frame, score, dataset="BM5.5", group="overall", value="all", model=score,
                               complexes=frame.complex_id.nunique(), chains=frame.record_id.nunique()))
    for score in ["pesto_holo", "pesto_apo"]:
        for stratum in ["identity_lt_20", "identity_20_30", "identity_30_40", "identity_ge_40"]:
            part = frame[frame.identity_stratum == stratum]
            if len(part):
                rows.append(metric_row(part, score, dataset="BM5.5", group="identity", value=stratum, model=score,
                                       complexes=part.complex_id.nunique(), chains=part.record_id.nunique()))
        for threshold in [0.0, 0.5, 0.8, 0.9, 0.95, 1.0]:
            part = frame[frame.max_training_coverage >= threshold - 1e-12]
            rows.append(metric_row(part, score, dataset="BM5.5", group="minimum_coverage", value=f"{threshold:.2f}", model=score,
                                   complexes=part.complex_id.nunique(), chains=part.record_id.nunique()))
        for category, part in frame.groupby("category", sort=True):
            rows.append(metric_row(part, score, dataset="BM5.5", group="benchmark_category", value=str(category), model=score,
                                   complexes=part.complex_id.nunique(), chains=part.record_id.nunique()))
    metrics = pd.DataFrame(rows)
    metrics.to_csv(OUT / "bm5_global_and_stratified_metrics.csv", index=False)
    complex_metrics, macro = macro_complex(frame, scores)
    complex_metrics.to_csv(OUT / "bm5_per_complex_metrics.csv", index=False)
    macro.to_csv(OUT / "bm5_macro_complex_metrics.csv", index=False)
    chain_metrics = per_unit(frame, "record_id", scores, "BM5.5")
    chain_metrics.to_csv(OUT / "bm5_per_chain_metrics.csv", index=False)
    print("BM5: complex-cluster bootstrap", flush=True)
    bootstrap = bm5_bootstrap(frame, scores, 1000)
    bootstrap.to_csv(OUT / "bm5_complex_bootstrap_iterations.csv", index=False)
    interval_table(bootstrap).to_csv(OUT / "bm5_complex_bootstrap_ci.csv", index=False)
    summary = {"windows": len(frame), "complexes": frame.complex_id.nunique(), "chains": frame.record_id.nunique(),
               "both_states_complete": bool(frame[["pesto_holo", "pesto_apo"]].notna().all().all()),
               "bootstrap_iterations": len(bootstrap), "external_status": "Previously analyzed BM5.5; not an untouched cohort"}
    return frame, summary


def grouped_spearman(frame: pd.DataFrame, unit: str) -> pd.DataFrame:
    predictors = ["local_interface_CA_RMSD", "interface_sidechain_change", "interface_absolute_delta_RSA",
                  "local_contact_degree_change", "structure_quality"]
    outcomes = ["apo_minus_holo_AUC", "apo_minus_holo_AUPRC", "paired_probability_MAE"]
    rows = []
    for predictor in predictors:
        for outcome in outcomes:
            part = frame[[unit, predictor, outcome]].dropna()
            if len(part) >= 3 and part[predictor].nunique() > 1 and part[outcome].nunique() > 1:
                test = spearmanr(part[predictor], part[outcome])
                rho, pvalue = test.statistic, test.pvalue
            else:
                rho, pvalue = np.nan, np.nan
            rows.append({"unit": unit, "predictor": predictor, "outcome": outcome, "n": len(part),
                         "spearman_rho": rho, "p_value": pvalue})
    return pd.DataFrame(rows)


def analyze_mechanism(frame: pd.DataFrame) -> dict:
    print("Mechanism: recomputing PeSTo-only outcomes", flush=True)
    structural_columns = ["record_id", "complex_id", "chain_id", "side", "category", "matched_residues",
        "interface_residues", "local_interface_residues", "global_ca_rmsd", "local_interface_CA_RMSD",
        "interface_ca_rmsd", "interface_sidechain_change", "interface_sidechain_max", "interface_absolute_delta_RSA",
        "local_contact_degree_change", "evaluated_windows", "evaluated_interface_windows", "status", "pdb_id",
        "structure_quality", "experimental_method_quality"]
    mechanism = pd.read_csv(ROOT / "results/Step59_bm5_conformation_mechanism/per_chain_conformation_mechanism.csv",
                            usecols=structural_columns)
    chain_metrics = pd.read_csv(OUT / "bm5_per_chain_metrics.csv")
    pesto = chain_metrics[chain_metrics.model.isin(["pesto_holo", "pesto_apo"])]
    wide = pesto.pivot(index="value", columns="model", values=["AUC", "AUPRC"]).reset_index()
    wide.columns = ["record_id"] + [f"{metric}_{model}" for metric, model in wide.columns.tolist()[1:]]
    mae = frame.assign(abs_difference=np.abs(frame.pesto_holo - frame.pesto_apo)).groupby("record_id").abs_difference.mean().rename(
        "paired_probability_MAE").reset_index()
    mechanism = mechanism.merge(wide, on="record_id", how="left", validate="one_to_one").merge(
        mae, on="record_id", how="left", validate="one_to_one")
    mechanism["apo_minus_holo_AUC"] = mechanism.AUC_pesto_apo - mechanism.AUC_pesto_holo
    mechanism["apo_minus_holo_AUPRC"] = mechanism.AUPRC_pesto_apo - mechanism.AUPRC_pesto_holo
    mechanism.to_csv(OUT / "pesto_per_chain_conformation_mechanism.csv", index=False)
    usable = mechanism[mechanism.status == "OK"].copy()
    correlations = [grouped_spearman(usable, "record_id")]
    aggregations = {column: (column, "mean") for column in ["local_interface_CA_RMSD", "interface_sidechain_change",
        "interface_absolute_delta_RSA", "local_contact_degree_change", "structure_quality", "apo_minus_holo_AUC",
        "apo_minus_holo_AUPRC", "paired_probability_MAE"]}
    complex_frame = usable.groupby("complex_id").agg(**aggregations).reset_index()
    complex_frame.to_csv(OUT / "pesto_per_complex_conformation_mechanism.csv", index=False)
    correlations.append(grouped_spearman(complex_frame, "complex_id"))
    pd.concat(correlations, ignore_index=True).to_csv(OUT / "pesto_mechanism_spearman_associations.csv", index=False)
    rng = np.random.default_rng(SEED)
    complexes = np.array(sorted(usable.complex_id.unique()))
    predictors = ["local_interface_CA_RMSD", "interface_sidechain_change", "interface_absolute_delta_RSA",
                  "local_contact_degree_change", "structure_quality"]
    rows = []
    for iteration in range(2000):
        sampled = rng.choice(complexes, size=len(complexes), replace=True)
        indices = np.concatenate([np.flatnonzero(usable.complex_id.to_numpy() == key) for key in sampled])
        boot = usable.iloc[indices]
        for predictor in predictors:
            part = boot[[predictor, "apo_minus_holo_AUPRC"]].dropna()
            rho = spearmanr(part[predictor], part.apo_minus_holo_AUPRC).statistic if len(part) > 2 else np.nan
            rows.append({"iteration": iteration, "predictor": predictor, "rho": rho})
    bootstrap = pd.DataFrame(rows)
    bootstrap.to_csv(OUT / "pesto_mechanism_complex_bootstrap_spearman.csv", index=False)
    bootstrap.groupby("predictor").rho.agg(mean="mean", ci95_low=lambda x: x.quantile(.025),
        ci95_high=lambda x: x.quantile(.975)).reset_index().to_csv(OUT / "pesto_mechanism_complex_bootstrap_ci.csv", index=False)
    return {"usable_chains": len(usable), "complexes": usable.complex_id.nunique(), "bootstrap_iterations": len(bootstrap)}


def analyze_main() -> dict:
    print("Main: family-stratified zero-shot evaluation", flush=True)
    meta = pd.read_csv(ROOT / "results/Step17_homology_clusters/window_metadata_homology.csv")
    residue_frames = [pd.read_csv(path, usecols=["record_id", "partner_chain", "position", "auth_seq_id"])
                      for path in sorted((ROOT / "data/processed/holo/interfaces").glob("*_residues.csv"))
                      if path.read_text(encoding="utf-8").strip()]
    coordinates = pd.concat(residue_frames, ignore_index=True).drop_duplicates(["record_id", "position"])
    centers = meta.merge(coordinates[["record_id", "position", "auth_seq_id"]], left_on=["record_id", "center_position"],
                         right_on=["record_id", "position"], how="left", validate="one_to_one")
    if centers.auth_seq_id.isna().any():
        raise ValueError("Main window-to-author-coordinate mapping incomplete")
    frame, audit = merge_scores(centers, OUT / "pesto_main_per_chain", ["bound"])
    frame = frame.rename(columns={"pesto_bound": "pesto_zero_shot", "pdb_id": "complex_id"})
    frame.to_csv(OUT / "main_family_stratified_residue_scores.csv", index=False)
    audit.to_csv(OUT / "main_inference_audit.csv", index=False)
    rows = []
    scopes = [("overall", "all", frame)] + [("dataset", key, part) for key, part in frame.groupby("dataset", sort=True)] + [
        ("family", key, part) for key, part in frame.groupby("family", sort=True)] + [
        ("homology_cluster", key, part) for key, part in frame.groupby("homology_cluster", sort=True)]
    for group, value, part in scopes:
        rows.append(metric_row(part, "pesto_zero_shot", dataset="METABOLIC_INFLAMMATION", group=group, value=str(value),
                               model="PeSTo_i_v4_1", complexes=part.complex_id.nunique(), chains=part.record_id.nunique()))
    pd.DataFrame(rows).to_csv(OUT / "main_zero_shot_stratified_metrics.csv", index=False)
    per_interface = per_unit(frame, "record_id", ["pesto_zero_shot"], "METABOLIC_INFLAMMATION")
    per_interface.to_csv(OUT / "main_zero_shot_per_interface_metrics.csv", index=False)
    return {"windows": len(frame), "interfaces": frame.record_id.nunique(), "complexes": frame.complex_id.nunique(),
            "development_windows": int((frame.dataset == "DEVELOPMENT").sum()),
            "temporal_holdout_windows": int((frame.dataset == "TEMPORAL_HOLDOUT").sum()),
            "families": frame.family.nunique(), "all_probabilities_present": bool(frame.pesto_zero_shot.notna().all())}


def analyze_biolip() -> dict:
    print("BioLiP: evaluating both prespecified targets", flush=True)
    meta = pd.read_csv(ROOT / "data/processed/external/biolip/direct_case_window_metadata.csv")
    frame, audit = merge_scores(meta, OUT / "pesto_biolip_per_chain", ["bound"])
    frame = frame.rename(columns={"pesto_bound": "pesto_zero_shot"})
    frame.to_csv(OUT / "biolip_zero_shot_residue_scores.csv", index=False)
    audit.to_csv(OUT / "biolip_inference_audit.csv", index=False)
    rows = []
    for pdb, part in frame.groupby("pdb_id", sort=True):
        for target in ["contact_label", "biolip_annotated"]:
            row = metric_row(part, "pesto_zero_shot", label=target, dataset="BIOLIP", pdb_id=pdb,
                             target=target, model="PeSTo_i_v4_1")
            for k in [5, 10]:
                selected = part.nlargest(min(k, len(part)), "pesto_zero_shot")
                row[f"precision_at_{k}"] = float(selected[target].mean())
                row[f"recovery_at_{k}"] = float(selected[target].sum() / max(part[target].sum(), 1))
            rows.append(row)
    pd.DataFrame(rows).to_csv(OUT / "biolip_zero_shot_case_metrics.csv", index=False)
    return {"cases": frame.pdb_id.nunique(), "windows": len(frame), "case_windows": frame.groupby("pdb_id").size().to_dict(),
            "all_probabilities_present": bool(frame.pesto_zero_shot.notna().all())}


def main() -> None:
    started = time.time()
    OUT.mkdir(parents=True, exist_ok=True)
    _, bm5_summary = analyze_bm5()
    mechanism_summary = analyze_mechanism(pd.read_csv(OUT / "bm5_paired_residue_scores.csv"))
    main_summary = analyze_main()
    biolip_summary = analyze_biolip()
    global_metrics = pd.read_csv(OUT / "bm5_global_and_stratified_metrics.csv")
    overall = global_metrics[global_metrics.group == "overall"].set_index("model")
    intervals = pd.read_csv(OUT / "bm5_complex_bootstrap_ci.csv").set_index("metric")
    summary = {
        "method": "Official PeSTo i_v4_1; zero training, zero fine-tuning, zero model or threshold selection",
        "weights_sha256": "b16332284675a0c08fc13ddc783255e46b8d9c9f7ab4306b6908e5009b5b2d1a",
        "bm5": bm5_summary, "mechanism": mechanism_summary, "main": main_summary, "biolip": biolip_summary,
        "headline": {
            "PeSTo_holo_AUC": float(overall.loc["pesto_holo", "AUC"]),
            "PeSTo_holo_AUPRC": float(overall.loc["pesto_holo", "AUPRC"]),
            "PeSTo_apo_AUC": float(overall.loc["pesto_apo", "AUC"]),
            "PeSTo_apo_AUPRC": float(overall.loc["pesto_apo", "AUPRC"]),
            "RF_apo_AUC": float(overall.loc["rf_apo", "AUC"]),
            "RF_apo_AUPRC": float(overall.loc["rf_apo", "AUPRC"]),
            "PeSTo_apo_minus_holo_AUPRC_ci95": [float(intervals.loc["PeSTo_apo_minus_holo_AUPRC", "ci95_low"]),
                                                  float(intervals.loc["PeSTo_apo_minus_holo_AUPRC", "ci95_high"])]},
        "interpretation_rule": "PeSTo is a published comparator, not the study's innovation. Apo adaptation is a candidate gap only if supported by measured transfer loss or failure strata.",
        "seed": SEED, "elapsed_seconds": time.time() - started}
    (OUT / "zero_training_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2), flush=True)


if __name__ == "__main__":
    main()
