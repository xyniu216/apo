# -*- coding: utf-8 -*-
"""Step86b: per-residue apo-holo CA displacement for the cap-relaxed (226-pair) set.

Same operators as Step86 (identical PairwiseAligner settings, global Kabsch on all
mapped residues) so the sensitivity set is directly comparable with v3.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "code"))
sys.path.append(str(ROOT / "docs/paper/_revision_work/_bio"))

OUT = ROOT / "results/Step86_displacement_sens"
CACHE = OUT / "_cache"
RAW = ROOT / "data/raw/apo/structures_v3"
OLD = ROOT.parent / "Metabolic_Inflammation_Binding_Expanded"
for p in (OUT, CACHE):
    p.mkdir(parents=True, exist_ok=True)


def kabsch_rotation(a, b):
    ac = a - a.mean(0); bc = b - b.mean(0)
    u, s, vt = np.linalg.svd(ac.T @ bc)
    d = np.sign(np.linalg.det(u @ vt))
    return u @ np.diag([1, 1, d]) @ vt


def main() -> None:
    from Bio.Align import PairwiseAligner
    from Bio.PDB import MMCIFParser
    import structure_utils as su

    meta = pd.read_csv(ROOT / "data/processed/apo_v4_sens/apo_window_metadata_sens.csv")
    pairs = meta[["record_id", "holo_pdb_id", "apo_pdb_id", "apo_chain"]].drop_duplicates()
    holo = pd.concat([pd.read_csv(p) for p in (ROOT / "data/processed/holo/interfaces").glob("*_residues.csv")
                      if p.stat().st_size > 10], ignore_index=True)

    parser = MMCIFParser(QUIET=True)
    aligner = PairwiseAligner()
    aligner.mode = "global"; aligner.match_score = 2; aligner.mismatch_score = -1
    aligner.open_gap_score = -5; aligner.extend_gap_score = -0.5

    def align_maps(hseq, aseq):
        a = aligner.align(hseq, aseq)[0]
        mapping = {}
        for (hs, he), (as_, ae) in zip(*a.aligned):
            for h, p in zip(range(hs, he), range(as_, ae)):
                mapping[h + 1] = p + 1
        return mapping

    done, frames = 0, []
    for row in pairs.itertuples(index=False):
        cache = CACHE / f"{row.record_id}__{row.apo_pdb_id}_{row.apo_chain}.csv"
        if cache.exists():
            frames.append(pd.read_csv(cache)); done += 1; continue
        block = holo[holo.record_id == row.record_id].sort_values("position")
        hseq = "".join(block.amino_acid)
        apo_path = RAW / f"{row.apo_pdb_id}.cif"
        if not apo_path.exists():
            print("MISSING APO", row.apo_pdb_id); continue
        try:
            model = parser.get_structure(row.apo_pdb_id, str(apo_path))[0]
            if row.apo_chain not in model:
                print("MISSING CHAIN", row.apo_pdb_id, row.apo_chain); continue
            obs = su.residues(model[row.apo_chain])
            aseq = "".join(a for _, a in obs)
            mapping = align_maps(hseq, aseq)
            hmodel = parser.get_structure(block.pdb_id.iloc[0], str(
                OLD / "data/raw/pdb" / f"{block.pdb_id.iloc[0]}.cif"))[0]
            hchain = hmodel[block.partner_chain.iloc[0]]
            hobs = su.residues(hchain)
            common = [p for p in mapping if p <= len(hobs) and mapping[p] <= len(obs)]
            if len(common) < 3:
                print("TOO FEW COMMON", row.record_id); continue
            hc = np.array([hobs[p - 1][0]["CA"].coord for p in common])
            ac = np.array([obs[mapping[p] - 1][0]["CA"].coord for p in common])
            R = kabsch_rotation(ac, hc)
            rows = []
            for p in common:
                ap = mapping[p]
                a_ca = obs[ap - 1][0]["CA"].coord
                h_ca = hobs[p - 1][0]["CA"].coord
                a_rot = (a_ca - ac.mean(0)) @ R + hc.mean(0)
                rows.append({"record_id": row.record_id, "apo_pdb_id": row.apo_pdb_id,
                             "apo_chain": row.apo_chain, "holo_position": p, "apo_position": ap,
                             "raw_ca_displacement": float(np.linalg.norm(a_ca - h_ca)),
                             "local_ca_displacement": float(np.linalg.norm(a_rot - h_ca))})
            df = pd.DataFrame(rows)
            df.to_csv(cache, index=False)
            frames.append(df); done += 1
        except Exception as e:
            print("ERROR", row.record_id, row.apo_pdb_id, repr(e)[:120])
        if done % 20 == 0:
            print("progress", done, flush=True)
    out = pd.concat(frames, ignore_index=True)
    out.to_csv(OUT / "per_residue_displacement_sens.csv", index=False)
    print("pairs done:", done, "/", len(pairs), "rows:", len(out))


if __name__ == "__main__":
    main()
