# -*- coding: utf-8 -*-
"""Step82: H1 正式预注册确认（协议 PRE-FORM-H1-2026-10-30，单次运行）。

主指标：Spearman(aligned_ca_rmsd, PeSTo 配对级 apo AUPRC)，配对 bootstrap 2000 次，通过线 CI 上限<0。
Holm 族：aligned_ca_rmsd / interface_ca_rmsd 均值 / interface_coverage 均值。
时间一致性（报告-only）与 BM5.5 复现（局域 RMSD vs pesto_apo AUPRC）同协议执行。
"""
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.stats.multitest import multipletests

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "results/Step82_h1_prereg"
OUT.mkdir(parents=True, exist_ok=True)
rng = np.random.default_rng(42)
N_BOOT = 2000


def auprc(y, s):
    y = np.asarray(y, dtype=int); s = np.asarray(s, dtype=float)
    order = np.argsort(-s, kind="mergesort")
    y = y[order]; tp = np.cumsum(y); prec = tp / np.arange(1, len(y) + 1)
    return float((prec * y).sum() / y.sum())


def pair_boot_spearman(x, y, n=N_BOOT):
    x = np.asarray(x, dtype=float); y = np.asarray(y, dtype=float)
    rhos = np.empty(n)
    for i in range(n):
        idx = rng.integers(0, len(x), len(x))
        if len(np.unique(x[idx])) < 3 or len(np.unique(y[idx])) < 3:
            rhos[i] = np.nan
        else:
            rhos[i] = stats.spearmanr(x[idx], y[idx])[0]
    rhos = rhos[~np.isnan(rhos)]
    return [float(np.percentile(rhos, 2.5)), float(np.percentile(rhos, 97.5))]


# ---- 主数据 83 配对 ----
meta = pd.read_csv(ROOT / "data/processed/apo_v3/apo_window_metadata_v3.csv")
oof = pd.read_csv(ROOT / "results/Step79_c1_v3/c1_v3_oof_scores.csv")
df = oof.merge(meta[["window_id", "interface_ca_rmsd",
                     "aligned_ca_rmsd", "interface_coverage"]], on="window_id", how="left")

rows = []
for (rec, apo), g in df.groupby(["record_id", "apo_pdb_id"]):
    iface = g[g["label"] == 1]
    rows.append({
        "pair_id": f"{rec}__{apo}", "record_id": rec, "apo_pdb_id": apo,
        "cluster": g["homology_cluster"].iloc[0], "dataset": g["dataset"].iloc[0],
        "preformation_aligned": float(g["aligned_ca_rmsd"].iloc[0]),
        "preformation_iface_rmsd": float(iface["interface_ca_rmsd"].mean()),
        "preformation_coverage": float(iface["interface_coverage"].mean()),
        "pesto_pair_auprc": auprc(g["label"], g["pesto_protein"]),
    })
pairs = pd.DataFrame(rows)
y = pairs["pesto_pair_auprc"].to_numpy()

candidates = {
    "aligned_ca_rmsd": pairs["preformation_aligned"].to_numpy(),
    "interface_ca_rmsd_mean": pairs["preformation_iface_rmsd"].to_numpy(),
    "interface_coverage_mean": pairs["preformation_coverage"].to_numpy(),
}
pvals, rhos_, cis_ = {}, {}, {}
for name, x in candidates.items():
    rho, pv = stats.spearmanr(x, y)
    rhos_[name] = float(rho); pvals[name] = float(pv)
    cis_[name] = pair_boot_spearman(x, y)
rej, pvals_holm, _, _ = multipletests(list(pvals.values()), method="holm")
holm = dict(zip(pvals.keys(), [float(v) for v in pvals_holm]))
primary_pass = bool(cis_["aligned_ca_rmsd"][1] < 0 and holm["aligned_ca_rmsd"] < 0.05)

temporal = pairs[pairs["dataset"] == "TEMPORAL_HOLDOUT"]
temporal_rho = float(stats.spearmanr(temporal["preformation_aligned"], temporal["pesto_pair_auprc"])[0])

# ---- BM5.5 复现 ----
s59 = pd.read_csv(ROOT / "results/Step59_bm5_conformation_mechanism/per_complex_conformation_mechanism.csv")
ps = pd.read_csv(ROOT / "results/Step65_pesto_zero_training_reanalysis/bm5_paired_residue_scores.csv")


def _auprc_group(g, col):
    if g["label"].sum() < 2:
        return np.nan
    return auprc(g["label"], g[col])


bm_apo = ps.groupby("complex_id").apply(_auprc_group, "pesto_apo", include_groups=False).rename("apo_auprc").reset_index()
bm_holo = ps.groupby("complex_id").apply(_auprc_group, "pesto_holo", include_groups=False).rename("holo_auprc").reset_index()
bm_apo["complex_id"] = bm_apo["complex_id"].str.upper()
bm_holo["complex_id"] = bm_holo["complex_id"].str.upper()
bm = s59.merge(bm_apo, on="complex_id").merge(bm_holo, on="complex_id")
bm["apo_minus_holo"] = bm["apo_auprc"] - bm["holo_auprc"]
bm = bm.dropna(subset=["local_interface_CA_RMSD", "apo_auprc"])
bx = bm["local_interface_CA_RMSD"].to_numpy(); by = bm["apo_auprc"].to_numpy()
bm_rho, bm_p = stats.spearmanr(bx, by)
bm_ci = pair_boot_spearman(bx, by)
bm_delta_rho, bm_delta_p = stats.spearmanr(bx, bm["apo_minus_holo"].to_numpy())
bm_pass = bool(bm_ci[1] < 0)

result = {
    "protocol_id": "PRE-FORM-H1-2026-10-30",
    "protocol_sha256": "fdd7c748dbb0c52cabcacdd8210120fb98382aaeaa7b15f2b8b5e7f506def3c3",
    "n_pairs": int(len(pairs)),
    "n_bootstrap": N_BOOT,
    "main": {
        "candidates": {
            name: {"rho": rhos_[name], "p_raw": pvals[name],
                   "p_holm": holm[name], "boot_95ci": cis_[name]}
            for name in candidates
        },
        "primary_metric": "aligned_ca_rmsd",
        "primary_pass": primary_pass,
    },
    "temporal_consistency_report_only": {"n_pairs": int(len(temporal)), "rho": temporal_rho},
    "bm55_replication": {
        "n_complexes": int(len(bm)),
        "metric": "local_interface_CA_RMSD vs pesto_apo AUPRC",
        "rho": float(bm_rho), "p_raw": float(bm_p), "boot_95ci": bm_ci,
        "rho_vs_apo_minus_holo": float(bm_delta_rho), "p_vs_apo_minus_holo": float(bm_delta_p),
        "pass_ci_upper_below_zero": bm_pass,
    },
    "random_baseline_prevalence": float((df["label"].mean())),
    "single_run": True,
}
(OUT / "h1_confirmation_result.json").write_text(
    json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
pairs.to_csv(OUT / "pair_level_table.csv", index=False)
print(json.dumps(result, indent=2, ensure_ascii=False))
