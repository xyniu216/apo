# -*- coding: utf-8 -*-
"""Step121: JCIM 投稿前的统计加固（全部基于既有 pair_level_table.csv，不新增实验）。

产出：
1) apo 聚类结构描述（83 对 → 多少 apo、多少同源簇、每 apo 的 holo 数分布）
2) 混合效应模型（apo 随机截距）：auprc ~ 预成型 RMSD，含斜率的 CI
3) apo 层聚类 bootstrap：Spearman rho 的 95% CI（以 apo 为重采样单位）
4) 留一 apo：逐个剔除一个 apo 后 rho 的范围
5) apo 块置换检验：在 apo 层打乱可塑性赋值，得到 rho 的经验 p
6) 分层判别收益：按预成型 RMSD 三分层，各层 AUPRC 中位数/均值/达标率
7) 三分层前置筛选（triage）：只保留最低可塑性 1/3 时的达标率增益
8) 同一 apo 内多 holo 的一致性（apo 内 Spearman）
输出：results/Step121_jcim_stat_hardening/jcim_stats.json + jcim_stats.txt
"""
import json, os
import numpy as np
import pandas as pd
from scipy import stats
import statsmodels.formula.api as smf

ROOT = r"D:\hnnm\Metabolic_Inflammation_Functional_Interface"
SRC = os.path.join(ROOT, "results", "Step82_h1_prereg", "pair_level_table.csv")
OUT = os.path.join(ROOT, "results", "Step121_jcim_stat_hardening")
os.makedirs(OUT, exist_ok=True)
RNG = np.random.default_rng(20261125)

df = pd.read_csv(SRC)
df = df.dropna(subset=["preformation_aligned", "pesto_pair_auprc"]).reset_index(drop=True)
x = df["preformation_aligned"].to_numpy(float)
y = df["pesto_pair_auprc"].to_numpy(float)
apo = df["apo_pdb_id"].astype(str).to_numpy()
clu = df["cluster"].astype(str).to_numpy()

res = {}
res["n_pairs"] = int(len(df))
res["n_apo"] = int(df["apo_pdb_id"].nunique())
res["n_clusters"] = int(df["cluster"].nunique())
vc = df.groupby("apo_pdb_id").size().value_counts().sort_index()
res["pairs_per_apo_distribution"] = {str(k): int(v) for k, v in vc.items()}
res["apo_with_multiple_holo"] = int((df.groupby("apo_pdb_id").size() > 1).sum())
res["n_holo_states"] = int((df["dataset"] == "DEVELOPMENT").sum())

rho, p = stats.spearmanr(x, y)
res["spearman"] = {"rho": round(float(rho), 4), "p": float(p)}

# 1) 混合效应模型：apo 随机截距
m = smf.mixedlm("pesto_pair_auprc ~ preformation_aligned", df, groups=df["apo_pdb_id"]).fit(reml=True)
b = float(m.params["preformation_aligned"])
se = float(m.bse["preformation_aligned"])
res["mixedlm_apo_random_intercept"] = {
    "slope_per_A": round(b, 5),
    "se": round(se, 5),
    "ci95": [round(b - 1.96 * se, 5), round(b + 1.96 * se, 5)],
    "p": float(m.pvalues["preformation_aligned"]),
    "intercept": round(float(m.params["Intercept"]), 4),
    "group_var_apo": round(float(m.cov_re.iloc[0, 0]), 5),
    "resid_var": round(float(m.scale), 5),
}
# 敏感性：以同源簇为随机截距
mc = smf.mixedlm("pesto_pair_auprc ~ preformation_aligned", df, groups=df["cluster"]).fit(reml=True)
bc = float(mc.params["preformation_aligned"])
sec = float(mc.bse["preformation_aligned"])
res["mixedlm_cluster_random_intercept"] = {
    "slope_per_A": round(bc, 5),
    "ci95": [round(bc - 1.96 * sec, 5), round(bc + 1.96 * sec, 5)],
    "p": float(mc.pvalues["preformation_aligned"]),
}

# 2) apo 层聚类 bootstrap
apoes = np.unique(apo)
boot = []
for _ in range(3000):
    pick = RNG.choice(apoes, len(apoes), replace=True)
    idx = np.concatenate([np.where(apo == a)[0] for a in pick])
    if len(idx) < 10:
        continue
    r, _ = stats.spearmanr(x[idx], y[idx])
    boot.append(r)
boot = np.asarray(boot)
res["apo_cluster_bootstrap"] = {
    "replicates": int(len(boot)),
    "rho_median": round(float(np.median(boot)), 4),
    "ci95": [round(float(np.percentile(boot, 2.5)), 4), round(float(np.percentile(boot, 97.5)), 4)],
    "fraction_negative": round(float((boot < 0).mean()), 4),
}

# 3) 留一 apo
loo = {}
for a in apoes:
    sub = apo != a
    if sub.sum() < 10:
        continue
    r, _ = stats.spearmanr(x[sub], y[sub])
    loo[a] = round(float(r), 4)
res["leave_one_apo_out"] = {
    "n_folds": len(loo),
    "rho_min": min(loo.values()),
    "rho_max": max(loo.values()),
    "rho_median": round(float(np.median(list(loo.values()))), 4),
    "all_negative": bool(all(v < 0 for v in loo.values())),
}

# 4) apo 块置换：把每个 apo 的可塑性赋值整体换到另一个 apo（保持块内多重度形状）
g = df.groupby("apo_pdb_id")["preformation_aligned"]
blocks = [v.to_numpy(float) for _, v in g]
idx_by_apo = {a: np.where(apo == a)[0] for a in apoes}
perm_rho = []
for _ in range(3000):
    order = RNG.permutation(len(blocks))
    newx = np.empty_like(x)
    for src_i, tgt_i in zip(order, range(len(blocks))):
        a_t = apoes[tgt_i]
        src_block = blocks[src_i]
        reps = len(idx_by_apo[a_t])
        vals = np.resize(src_block, reps) if len(src_block) != reps else src_block
        newx[idx_by_apo[a_t]] = vals
    r, _ = stats.spearmanr(newx, y)
    perm_rho.append(r)
perm_rho = np.asarray(perm_rho)
res["apo_block_permutation"] = {
    "replicates": int(len(perm_rho)),
    "p_two_sided": float((np.abs(perm_rho) >= abs(rho)).mean()),
    "perm_rho_median": round(float(np.median(perm_rho)), 4),
}

# 5) 三分层判别收益（按预成型 RMSD 升序 = 可塑性降序）
q1, q2 = np.percentile(x, [33.333, 66.667])
tiers = {"低可塑性(tier1)": x <= q1, "中可塑性(tier2)": (x > q1) & (x <= q2), "高可塑性(tier3)": x > q2}
strat = {}
for k, mask in tiers.items():
    strat[k] = {
        "n_pairs": int(mask.sum()),
        "n_apo": int(df.loc[mask, "apo_pdb_id"].nunique()),
        "median_auprc": round(float(np.median(y[mask])), 4),
        "mean_auprc": round(float(np.mean(y[mask])), 4),
        "rate_auprc_ge_0.30": round(float((y[mask] >= 0.30).mean()), 4),
    }
res["stratification_by_preformation_rmsd"] = {
    "cut_points": [round(float(q1), 3), round(float(q2), 3)],
    "tiers": strat,
}
res["tier1_vs_tier3"] = {
    "median_auprc_diff": round(strat["低可塑性(tier1)"]["median_auprc"] - strat["高可塑性(tier3)"]["median_auprc"], 4),
    "rate_ge_0.30_diff": round(strat["低可塑性(tier1)"]["rate_auprc_ge_0.30"] - strat["高可塑性(tier3)"]["rate_auprc_ge_0.30"], 4),
}

# 6) triage：只保留最低可塑性的 1/3 / 1/2
base_rate = float((y >= 0.30).mean())
n_take1 = int(np.ceil(len(y) / 3))
order_idx = np.argsort(x)
triage = {}
for label, k in {"take_top1/3": n_take1, "take_top1/2": int(np.ceil(len(y) / 2))}.items():
    sel = order_idx[:k]
    triage[label] = {
        "n_selected": int(k),
        "median_auprc": round(float(np.median(y[sel])), 4),
        "rate_auprc_ge_0.30": round(float((y[sel] >= 0.30).mean()), 4),
        "enrichment_vs_base": round(float((y[sel] >= 0.30).mean()) / base_rate, 3) if base_rate > 0 else None,
        "base_rate": round(base_rate, 4),
    }
res["triage"] = triage

# 7) 同一 apo 内多 holo 的一致性
within = []
for a, sub in df.groupby("apo_pdb_id"):
    if len(sub) >= 3 and sub["preformation_aligned"].nunique() > 1:
        r, _ = stats.spearmanr(sub["preformation_aligned"], sub["pesto_pair_auprc"])
        within.append((a, len(sub), float(r) if np.isfinite(r) else None))
valid = [w[2] for w in within if w[2] is not None]
res["within_apo_consistency"] = {
    "n_apo_with_3plus": len(within),
    "n_valid": len(valid),
    "median_rho": round(float(np.median(valid)), 4) if valid else None,
    "n_negative": int(sum(1 for v in valid if v < 0)),
}

with open(os.path.join(OUT, "jcim_stats.json"), "w", encoding="utf-8") as f:
    json.dump(res, f, ensure_ascii=False, indent=2)

lines = []
lines.append("JCIM 统计加固结果（基于 83 对既有数据，未新增实验）")
lines.append(json.dumps(res, ensure_ascii=False, indent=2))
txt = "\n".join(lines)
with open(os.path.join(OUT, "jcim_stats.txt"), "w", encoding="utf-8") as f:
    f.write(txt)
print(txt)
