"""GAPS inference over the BM5.5 zero-homology bound structures.

Runs the official GAPS weights (CPU) on every *_target.pdb, repairs non-standard
PDB charge columns instead of dropping structures, and maps per-residue scores
back to original auth_seq_id via the continuous internal residue numbering.

Outputs per-record residue scores; metrics are computed in Step106b.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(r"D:\hnnm\Metabolic_Inflammation_Functional_Interface")
GAPS_DIR = ROOT / "docs/paper/_revision_work/gaps"
sys.path.insert(0, str(GAPS_DIR / "GAPS"))
sys.path.insert(0, str(GAPS_DIR / "_pylibs"))

import torch as pt  # noqa: E402
import gemmi  # noqa: E402
from src.structure_io import read_pdb  # noqa: E402
from src.structure import cle_structure, delete_hetatm, split_by_chain, fil_non_atomic_sub, rm_duplicate_tagged_sub, concatenate_chains, res3to1  # noqa: E402
from src.data_encoding import en_structure, en_features, ext_topology  # noqa: E402
from src.dataset import col_batch  # noqa: E402
from src.config import config_model  # noqa: E402
from model.model import Model  # noqa: E402

BM5 = ROOT / "data/raw/external/bm5/BM5-clean-master/HADDOCK-ready"
OUT = ROOT / "results/Step106_gaps_baseline"
FIXED = GAPS_DIR / "_fixed_pdb"


def repair_pdb(src: Path, dst: Path) -> bool:
    """Blank malformed charge columns (79-80) that gemmi rejects. Returns True if changed."""
    text = src.read_text(errors="replace")
    changed = False
    out = []
    for line in text.splitlines():
        if line.startswith(("ATOM", "HETATM")):
            line = line.ljust(80)
            charge = line[78:80]
            if charge != "  " and not (charge[0].isdigit() and charge[1] in "+-"):
                line = line[:78] + "  "
                changed = True
        out.append(line.rstrip())
    dst.write_text("\n".join(out) + "\n")
    return changed


def read_structure(path: Path):
    """Read PDB, repairing charge columns on failure."""
    try:
        return read_pdb(str(path)), False
    except Exception:
        dst = FIXED / path.name
        dst.parent.mkdir(parents=True, exist_ok=True)
        repair_pdb(path, dst)
        return read_pdb(str(dst)), True


def residue_map(raw):
    """Return list of (internal_resid, chain_letter, auth_seq_id) for protein residues.

    Applies the same water/H removal and hetatm filtering as the official pipeline,
    then reads the continuous internal residue numbering produced by cle_structure.
    """
    s = {k: (v.copy() if hasattr(v, "copy") else v) for k, v in raw.items()}
    s = cle_structure(s)
    s = delete_hetatm(s)

    m_wat = raw["resname"] == "HOH"
    m_h = raw["element"] == "H"
    m_d = raw["element"] == "D"
    m_hwat = raw["resname"] == "DOD"
    keep = ~(m_wat | m_h | m_d | m_hwat) & (raw["het_flag"] != "H")

    internal = s["resid"]
    o_resid = raw["resid"][keep]
    o_chain = raw["chain_name"][keep]
    o_icode = raw["icode"][keep]
    o_resname = raw["resname"][keep]

    n = len(internal)
    assert n == int(keep.sum()), "mask/reindex mismatch"

    levels = []
    for i in range(n):
        key = int(internal[i])
        if not levels or levels[-1][0] != key:
            levels.append([key, str(o_chain[i]).split(":")[0], int(o_resid[i]), str(o_icode[i]).strip(), str(o_resname[i])])
    return levels, s


def forward(model, subunits):
    structure = concatenate_chains(subunits)
    X, M = en_structure(structure)
    q = en_features(structure)[0]
    ids_topk, _, _, _, _ = ext_topology(X, 64)
    X, ids_topk, q, M = col_batch([[X, ids_topk, q, M]])
    with pt.no_grad():
        p = pt.sigmoid(model(X, ids_topk, q, M.float())).cpu().numpy().ravel()
    return p, M.shape[1]


def run_one(model, pdb_id: str, record_ids: dict):
    path = BM5 / pdb_id / f"{pdb_id}_target.pdb"
    if not path.exists():
        return [], {"pdb_id": pdb_id, "status": "missing_file"}
    t0 = time.time()
    raw, repaired = read_structure(path)
    levels, s = residue_map(raw)

    subunits = split_by_chain(s)
    subunits = fil_non_atomic_sub(subunits)
    subunits = rm_duplicate_tagged_sub(subunits)
    if not subunits:
        return [], {"pdb_id": pdb_id, "status": "empty_subunits", "repaired": repaired}

    p, n_cols = forward(model, subunits)
    if len(p) != n_cols:
        return [], {"pdb_id": pdb_id, "status": f"length_mismatch p={len(p)} cols={n_cols}"}

    rows = []
    for (r, chain, auth, icode, resname) in levels:
        if r < 1 or r > len(p):
            continue
        rows.append({"pdb_id": pdb_id, "chain_id": chain, "auth_seq_id": auth,
                     "icode": icode, "resname": resname, "gaps_probability": float(p[r - 1])})
    meta = {"pdb_id": pdb_id, "status": "ok", "repaired": repaired, "n_residues": len(p),
            "n_levels": len(levels), "n_atoms": int(s["xyz"].shape[0]),
            "seconds": round(time.time() - t0, 2)}
    return rows, meta


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--threads", type=int, default=8)
    ap.add_argument("--tag", default="full")
    args = ap.parse_args()

    pt.set_num_threads(args.threads)
    device = pt.device("cpu")
    model = Model(config_model)
    model.load_state_dict(pt.load(str(GAPS_DIR / "GAPS/checkpoints/model.pt"), map_location=device))
    model.eval().to(device)

    chains = pd.read_csv(ROOT / "data/processed/external/bm5/chain_sequences_zero_homology.csv")
    chains = chains[chains.external_included == True]  # noqa: E712
    pdb_ids = sorted(chains.pdb_id.unique().tolist())
    if args.limit:
        pdb_ids = pdb_ids[: args.limit]
    print(f"structures: {len(pdb_ids)}", flush=True)

    OUT.mkdir(parents=True, exist_ok=True)
    rows, log = [], []
    t0 = time.time()
    for i, pdb_id in enumerate(pdb_ids, 1):
        try:
            r, m = run_one(model, pdb_id, None)
        except Exception as e:  # noqa: BLE001
            r, m = [], {"pdb_id": pdb_id, "status": f"exception: {type(e).__name__}: {e}"}
        rows.extend(r)
        log.append(m)
        if i % 10 == 0 or i == len(pdb_ids):
            print(f"[{i}/{len(pdb_ids)}] {pdb_id} status={m.get('status')} "
                  f"elapsed={time.time()-t0:.0f}s rows={len(rows)}", flush=True)

    scores = pd.DataFrame(rows)
    scores.to_csv(OUT / f"residue_scores_{args.tag}.csv", index=False)
    pd.DataFrame(log).to_csv(OUT / f"run_log_{args.tag}.csv", index=False)
    ok = sum(1 for m in log if m.get("status") == "ok")
    (OUT / f"run_summary_{args.tag}.json").write_text(json.dumps({
        "structures": len(pdb_ids), "ok": ok, "failed": len(log) - ok,
        "repaired": sum(1 for m in log if m.get("repaired")),
        "rows": len(rows), "seconds": round(time.time() - t0, 1),
    }, indent=2, ensure_ascii=False))
    print("done", flush=True)


if __name__ == "__main__":
    main()
