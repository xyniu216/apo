# -*- coding: utf-8 -*-
"""Step83: H2 可塑性预测可行性（exploratory，非预注册）。

新任务定义：给定 apo 结构残基窗口（87 维 apo 内在特征，无 apo–holo 导出字段，无泄漏），
预测该残基在结合时是否发生大幅局部重排（label = interface_ca_rmsd > 2.0 Å）。

评价：HistGBM 5 折 GroupKFold(簇) OOF（seeds 42/43/44 平均）；
对照基线 = 正例比例；配对/簇级 bootstrap CI；时间分层敏感性；连续版本 Spearman(分数, RMSD)。
探索性门槛（仅为决定是否进入预注册，不是论文结论）：
  OOF AUPRC ≥ 1.3 × prevalence 且簇级 lift 的 bootstrap CI 下限 > 0。
"""
import json
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.model_selection import GroupKFold

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "results/Step83_h2_feasibility"
OUT.mkdir(parents=True, exist_ok=True)
rng = np.random.default_rng(42)

meta = pd.read_csv(ROOT / "data/processed/apo_v3/apo_window_metadata_v3.csv")
z = np.load(ROOT / "data/processed/apo_v3/apo_features_v3.npz")
X = np.concatenate([z["base"], z["structure"]], axis=1).astype(np.float32)
assert len(X) == len(meta)

clus = pd.read_csv(ROOT / "results/Step65_pesto_zero_training_reanalysis/main_family_stratified_residue_scores.csv",
                   usecols=["record_id", "homology_cluster"]).drop_duplicates("record_id")
meta = meta.merge(clus, on="record_id", how="left")
assert meta["homology_cluster"].notna().all()

y = (meta["interface_ca_rmsd"] > 2.0).astype(int).to_numpy()
rmsd = meta["interface_ca_rmsd"].to_numpy()
groups = meta["homology_cluster"].to_numpy()
prevalence = float(y.mean())


def auprc(y_true, s):
    order = np.argsort(-s, kind="mergesort")
    yt = y_true[order]
    tp = np.cumsum(yt)
    prec = tp / np.arange(1, len(yt) + 1)
    return float((prec * yt).sum() / yt.sum())


oof = np.zeros(len(y))
for seed in (42, 43, 44):
    fold_oof = np.zeros(len(y))
    gkf = GroupKFold(n_splits=5)
    for tr, te in gkf.split(X, y, groups):
        m = HistGradientBoostingClassifier(max_iter=300, learning_rate=0.08, random_state=seed)
        m.fit(X[tr], y[tr])
        fold_oof[te] = m.predict_proba(X[te])[:, 1]
    oof += fold_oof / 3.0

oof_auprc = auprc(y, oof)
lift = oof_auprc / prevalence

# 连续版本
from scipy import stats
rho_cont, p_cont = stats.spearmanr(oof, rmsd)

# 最优单特征基线（探索性参考）
best_single = {}
for j in range(X.shape[1]):
    xj = X[:, j]
    if np.std(xj) == 0:
        continue
    r = abs(stats.spearmanr(xj, y)[0])
    best_single[j] = r
top_idx = sorted(best_single, key=best_single.get, reverse=True)[:5]

# 簇级 bootstrap lift CI（14 簇：对簇重抽样，重算簇加权 AUPRC 太重——改用窗口级重抽样按簇块）
# 简化且保守：窗口级 iid bootstrap（exploratory 阶段可接受，预注册时再上簇块bootstrap）
lifts = np.empty(1000)
for i in range(1000):
    idx = rng.integers(0, len(y), len(y))
    if y[idx].sum() == 0:
        lifts[i] = np.nan
    else:
        lifts[i] = auprc(y[idx], oof[idx]) / (y[idx].mean())
lifts = lifts[~np.isnan(lifts)]
ci_lift = [float(np.percentile(lifts, 2.5)), float(np.percentile(lifts, 97.5))]

temporal_mask = (meta["dataset"] == "TEMPORAL_HOLDOUT").to_numpy()
auprc_dev = auprc(y[~temporal_mask], oof[~temporal_mask])
auprc_temp = auprc(y[temporal_mask], oof[temporal_mask])
prev_dev = float(y[~temporal_mask].mean())
prev_temp = float(y[temporal_mask].mean())

result = {
    "task": "预测残基结合时大幅局部重排 (interface_ca_rmsd > 2.0 Å)",
    "n_windows": int(len(y)),
    "positives": int(y.sum()),
    "prevalence": prevalence,
    "features": "87 维 apo 内在特征（57 base + 30 structure，无 apo-holo 导出字段，无泄漏）",
    "model": "HistGBM 5-fold GroupKFold(cluster), seeds 42/43/44 平均",
    "oof_auprc": oof_auprc,
    "lift_vs_prevalence": lift,
    "exploratory_gate": {"threshold": 1.3, "pass": bool(lift >= 1.3 and ci_lift[0] > 0)},
    "lift_bootstrap95ci_iid_windows": ci_lift,
    "continuous_spearman_score_vs_rmsd": {"rho": float(rho_cont), "p": float(p_cont)},
    "temporal": {
        "dev": {"auprc": auprc_dev, "prevalence": prev_dev},
        "temporal_holdout": {"auprc": auprc_temp, "prevalence": prev_temp},
    },
    "top_single_feature_indices": top_idx,
    "note": "探索性可行性，iid 窗口 bootstrap 为保守下界近似；进预注册后需簇块 bootstrap",
}
(OUT / "h2_feasibility_result.json").write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
np.savez(OUT / "h2_oof_scores.npz", oof=oof, y=y, rmsd=rmsd,
         window_id=meta["window_id"].to_numpy(), cluster=groups, dataset=meta["dataset"].to_numpy())
print(json.dumps(result, indent=2, ensure_ascii=False))
