# -*- coding: utf-8 -*-
"""Step89b: H2 pre-registered configuration re-evaluated on the 226-pair
cap-relaxed sensitivity set (identical model, features, labels and CV scheme).
"""
import json
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.model_selection import GroupKFold
from statsmodels.stats.multitest import multipletests

ROOT = Path(r"D:\hnnm\Metabolic_Inflammation_Functional_Interface")
OUT = ROOT / "results/Step89_h2_sens"
OUT.mkdir(parents=True, exist_ok=True)
rng = np.random.default_rng(42)
N_BOOT = 2000

meta = pd.read_csv(ROOT / "data/processed/apo_v4_sens/apo_window_metadata_sens.csv")
disp = pd.read_csv(ROOT / "results/Step86_displacement_sens/per_residue_displacement_sens.csv")
meta = meta.merge(disp[["record_id", "apo_pdb_id", "apo_chain", "apo_position",
                        "local_ca_displacement", "raw_ca_displacement"]],
                  on=["record_id", "apo_pdb_id", "apo_chain", "apo_position"], how="left")
print("join coverage", meta.local_ca_displacement.notna().mean(), flush=True)
meta = meta[meta.local_ca_displacement.notna()].reset_index(drop=True)

z = np.load(ROOT / "data/processed/apo_v4_sens/apo_features_sens.npz")
X = np.concatenate([z["base"], z["structure"]], axis=1).astype(np.float32)
assert len(X) == len(meta), f"features {len(X)} != meta {len(meta)}"

clus = pd.read_csv(ROOT / "results/Step65_pesto_zero_training_reanalysis/main_family_stratified_residue_scores.csv",
                   usecols=["record_id", "homology_cluster"]).drop_duplicates("record_id")
meta = meta.merge(clus, on="record_id", how="left")
groups = meta["homology_cluster"].fillna(meta["family"]).to_numpy()
uniq = np.unique(groups)
idx_by = {g: np.where(groups == g)[0] for g in uniq}
key = list(zip(meta["record_id"], meta["apo_pdb_id"], meta["apo_chain"]))


def auprc(yt, s):
    order = np.argsort(-s, kind="mergesort")
    yt = yt[order]
    tp = np.cumsum(yt)
    if yt.sum() == 0:
        return np.nan
    return float(((tp / np.arange(1, len(yt) + 1)) * yt).sum() / yt.sum())


def run_oof(X_, y):
    oof = np.zeros(len(y))
    for seed in (42, 43, 44):
        fold = np.zeros(len(y))
        for tr, te in GroupKFold(n_splits=5).split(X_, y, groups):
            m = HistGradientBoostingClassifier(max_iter=300, learning_rate=0.08, random_state=seed)
            m.fit(X_[tr], y[tr])
            fold[te] = m.predict_proba(X_[te])[:, 1]
        oof += fold / 3.0
    return oof


def cluster_lift_ci(y, oof, n=N_BOOT):
    lifts = []
    for _ in range(n):
        pick = rng.choice(uniq, size=len(uniq), replace=True)
        idx = np.concatenate([idx_by[g] for g in pick])
        a = auprc(y[idx], oof[idx])
        if not np.isnan(a) and y[idx].mean() > 0:
            lifts.append(a / y[idx].mean())
    return [float(np.percentile(lifts, 2.5)), float(np.percentile(lifts, 97.5))]


q75 = meta.groupby(["record_id", "apo_pdb_id", "apo_chain"])["local_ca_displacement"].quantile(0.75).to_dict()
y_rel = (meta.local_ca_displacement.to_numpy() >= np.array([q75[k] for k in key])).astype(int)
y_loc = (meta.local_ca_displacement > 2.0).astype(int).to_numpy()
y_raw = (meta.raw_ca_displacement > 2.0).astype(int).to_numpy()

configs = {"relative_top25": y_rel, "global_local_2A": y_loc, "global_raw_2A": y_raw}
res = {}
for name, y in configs.items():
    prev = float(y.mean())
    if prev <= 0.02 or prev >= 0.98:
        res[name] = {"status": "not_evaluable", "prevalence": round(prev, 4),
                     "note": "正例率退化为 0/1，AUC/AUPRC 无定义；如实标注不参与比较。"}
        print(name, res[name], flush=True)
        continue
    print("running", name, "n=", len(y), "prevalence", round(prev, 4), flush=True)
    oof = run_oof(X, y)
    lift = auprc(y, oof) / y.mean()
    ci = cluster_lift_ci(y, oof)
    res[name] = {"auprc": round(float(auprc(y, oof)), 4), "prevalence": round(prev, 4),
                 "lift": round(float(lift), 4), "cluster_block_ci": [round(c, 4) for c in ci],
                 "pass_ci_lower_gt1": bool(ci[0] > 1.0)}
    print(name, res[name], flush=True)

summary = {"set": "cap-relaxed 226-pair sensitivity set", "n_windows": int(len(y_rel)),
           "n_pairs": int(meta.groupby(["record_id", "apo_pdb_id", "apo_chain"]).ngroups),
           "n_clusters": int(len(uniq)), "configs": res}
(OUT / "h2_sens_result.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False))
print(json.dumps(summary, indent=2, ensure_ascii=False))
