# -*- coding: utf-8 -*-
"""Step89: H2 预注册正式确认（协议 PLASTICITY-H2-2026-10-30，单次运行）。

主配置：相对 top-25% local 位移标签；门槛 lift≥1.3 且簇块 bootstrap CI 下限>1.0。
Holm 族：相对标签 / 全局 local>2.0 / 全局 raw>2.0。
"""
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.model_selection import GroupKFold
from statsmodels.stats.multitest import multipletests

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "results/Step89_h2_prereg"
rng = np.random.default_rng(42)
N_BOOT = 2000

meta = pd.read_csv(ROOT / "data/processed/apo_v3/apo_window_metadata_v3.csv")
disp = pd.read_csv(ROOT / "results/Step86_displacement/per_residue_displacement_v3.csv")
meta = meta.merge(disp[["record_id", "apo_pdb_id", "apo_position",
                        "local_ca_displacement", "raw_ca_displacement"]],
                  on=["record_id", "apo_pdb_id", "apo_position"], how="left")
assert meta["local_ca_displacement"].notna().all(), "join 覆盖率不足 100%"

z = np.load(ROOT / "data/processed/apo_v3/apo_features_v3.npz")
X = np.concatenate([z["base"], z["structure"]], axis=1).astype(np.float32)
clus = pd.read_csv(ROOT / "results/Step65_pesto_zero_training_reanalysis/main_family_stratified_residue_scores.csv",
                   usecols=["record_id", "homology_cluster"]).drop_duplicates("record_id")
meta = meta.merge(clus, on="record_id", how="left")
groups = meta["homology_cluster"].to_numpy()
uniq_clusters = np.unique(groups)
idx_by_cluster = {g: np.where(groups == g)[0] for g in uniq_clusters}
key = list(zip(meta["record_id"], meta["apo_pdb_id"]))


def auprc(yt, s):
    order = np.argsort(-s, kind="mergesort")
    yt = yt[order]
    tp = np.cumsum(yt)
    if yt.sum() == 0:
        return np.nan
    return float(((tp / np.arange(1, len(yt) + 1)) * yt).sum() / yt.sum())


def run_oof(X_, y):
    oof = np.zeros(len(y))
    for seed in (42, 43, 44):
        fold = np.zeros(len(y))
        for tr, te in GroupKFold(n_splits=5).split(X_, y, groups):
            m = HistGradientBoostingClassifier(max_iter=300, learning_rate=0.08, random_state=seed)
            m.fit(X_[tr], y[tr])
            fold[te] = m.predict_proba(X_[te])[:, 1]
        oof += fold / 3.0
    return oof


def cluster_block_lift_ci(y, oof, n=N_BOOT):
    lifts = []
    for _ in range(n):
        pick = rng.choice(uniq_clusters, size=len(uniq_clusters), replace=True)
        idx = np.concatenate([idx_by_cluster[g] for g in pick])
        a = auprc(y[idx], oof[idx])
        if not np.isnan(a) and y[idx].mean() > 0:
            lifts.append(a / y[idx].mean())
    lifts = np.asarray(lifts)
    return [float(np.percentile(lifts, 2.5)), float(np.percentile(lifts, 97.5))]


# 三个候选配置的标签
q75 = meta.groupby(["record_id", "apo_pdb_id"])["local_ca_displacement"].quantile(0.75).to_dict()
y_rel = (meta["local_ca_displacement"].to_numpy() >= np.array([q75[k] for k in key])).astype(int)
assert 0.24 <= y_rel.mean() <= 0.26, f"相对标签正例率异常: {y_rel.mean()}"
y_loc = (meta["local_ca_displacement"] > 2.0).astype(int).to_numpy()
y_raw = (meta["raw_ca_displacement"] > 2.0).astype(int).to_numpy()

configs = {"relative_top25": y_rel, "global_local_2A": y_loc, "global_raw_2A": y_raw}
res = {}
for name, y in configs.items():
    oof = run_oof(X, y)
    lift = auprc(y, oof) / y.mean()
    ci = cluster_block_lift_ci(y, oof)
    # iid 窗口级 lift CI（Holm 辅助 p 值用：lift>1 的单侧检验）
    iid = []
    for _ in range(500):
        b = rng.integers(0, len(y), len(y))
        if y[b].sum() > 0:
            iid.append(auprc(y[b], oof[b]) / y[b].mean())
    iid = np.asarray(iid)
    p_one_sided = float((iid <= 1.0).mean())
    res[name] = {"lift": float(lift), "prevalence": float(y.mean()),
               "cluster_block_ci95": ci, "p_lift_gt1_iid": p_one_sided, "oof": oof}

pvals = [res[c]["p_lift_gt1_iid"] for c in configs]
rej, p_holm, _, _ = multipletests(pvals, method="holm")
holm = dict(zip(configs.keys(), [float(v) for v in p_holm]))

tm = (meta["dataset"] == "TEMPORAL_HOLDOUT").to_numpy()
primary = res["relative_top25"]
temporal_lift = float(auprc(configs["relative_top25"][tm], primary["oof"][tm]) / configs["relative_top25"][tm].mean())
primary_pass = bool(primary["lift"] >= 1.3 and primary["cluster_block_ci95"][0] > 1.0 and holm["relative_top25"] < 0.05)

result = {
    "protocol_id": "PLASTICITY-H2-2026-10-30",
    "protocol_sha256": "3a7273a9c88198ba22f7af6979d17b906543bb7297b6a6441037004ee07cef94",
    "n_windows": int(len(y_rel)),
    "n_clusters": int(len(uniq_clusters)),
    "n_bootstrap": N_BOOT,
    "configs": {c: {k: v for k, v in res[c].items() if k != "oof"} | {"p_holm": holm[c]}
                for c in configs},
    "primary": "relative_top25",
    "primary_pass": primary_pass,
    "temporal_lift_report_only": temporal_lift,
    "single_run": True,
}
(OUT / "h2_confirmation_result.json").write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
print(json.dumps(result, indent=2, ensure_ascii=False))
