# -*- coding: utf-8 -*-
"""Step95: 可塑性特征对 SKEMPI ΔΔG 功能预测的贡献（第二篇方法主张的检验）。

设计：
1. 在 v3 apo 数据上训练最终 H2 可塑性模型（相对 top-25% 标签，全量数据）。
2. 将 H2 模型施加于 SKEMPI 复合物窗口（87 维特征已存在）→ 每个窗口的可塑性分数。
3. 突变级数据集（4,166；按 complex 隔离 5 折，seeds 42/43/44）：
   模型A = 87 窗口特征 + wt/mut one-hot(40)
   模型B = A + 可塑性分数（+界面邻域均值）
   比较 Spearman/RMSE/热点AUC，复合物级 bootstrap CI。
4. 独立代谢靶点（37 突变，is_metabolic_target，全程排除训练）：迁移评估 A vs B。
"""
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats
from sklearn.ensemble import HistGradientBoostingClassifier, HistGradientBoostingRegressor
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import GroupKFold

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "results/Step95_plasticity_ddg"
OUT.mkdir(parents=True, exist_ok=True)
rng = np.random.default_rng(42)

AAS = list("ARNDCQEGHILKMFPSTWYV")

# ---- 1. H2 可塑性最终模型 ----
meta = pd.read_csv(ROOT / "data/processed/apo_v3/apo_window_metadata_v3.csv")
disp = pd.read_csv(ROOT / "results/Step86_displacement/per_residue_displacement_v3.csv")
meta = meta.merge(disp[["record_id", "apo_pdb_id", "apo_position", "local_ca_displacement"]],
                  on=["record_id", "apo_pdb_id", "apo_position"], how="left")
z3 = np.load(ROOT / "data/processed/apo_v3/apo_features_v3.npz")
X3 = np.concatenate([z3["base"], z3["structure"]], axis=1).astype(np.float32)
key = list(zip(meta["record_id"], meta["apo_pdb_id"]))
q75 = meta.groupby(["record_id", "apo_pdb_id"])["local_ca_displacement"].quantile(0.75).to_dict()
y3 = (meta["local_ca_displacement"].to_numpy() >= np.array([q75[k] for k in key])).astype(int)
h2 = HistGradientBoostingClassifier(max_iter=300, learning_rate=0.08, random_state=42)
h2.fit(X3, y3)

# ---- 2. SKEMPI 窗口可塑性分数 ----
zs = np.load(ROOT / "data/processed/skempi/skempi_features.npz")
Xs = np.concatenate([zs["base"], zs["structure"]], axis=1).astype(np.float32)
win = pd.read_csv(ROOT / "data/processed/skempi/window_metadata.csv")
assert len(Xs) == len(win)
win["plasticity_score"] = h2.predict_proba(Xs)[:, 1]
# 界面邻域均值：同 complex 内 ±5 位置的窗口分数均值
win = win.sort_values(["complex_id", "auth_seq_id"])
win["plas_neighborhood"] = win.groupby("complex_id")["plasticity_score"].transform(
    lambda s: s.rolling(11, center=True, min_periods=1).mean())

# ---- 3. 突变级数据集 ----
mut = pd.read_csv(ROOT / "data/processed/skempi/mapped_mutations.csv")
mut = mut[mut["mapping_status"] == "MAPPED"].merge(
    win[["window_id", "plasticity_score", "plas_neighborhood"]], on="window_id", how="left")
assert mut["plasticity_score"].notna().all()
widx = win.set_index("window_id")
Xw = Xs[widx.index.get_indexer(mut["window_id"])]


def aa_onehot(aa):
    v = np.zeros(len(AAS), dtype=np.float32)
    if aa in AAS:
        v[AAS.index(aa)] = 1.0
    return v


mut_feats = np.stack([np.concatenate([aa_onehot(a), aa_onehot(b)])
                      for a, b in zip(mut["wt_aa_expected"], mut["mut_aa"])])
XA = np.concatenate([Xw, mut_feats], axis=1)
XB = np.concatenate([XA, mut[["plasticity_score", "plas_neighborhood"]].to_numpy(np.float32)], axis=1)
y = mut["ddg_kcal_mol"].to_numpy()
h1 = mut["hotspot_1"].to_numpy()
groups = mut["complex_id"].to_numpy()

is_target = mut["is_metabolic_target"].to_numpy().astype(bool)  # 转布尔，~取反才有意义
mask = ~is_target  # 独立靶点全程排除


def run(X, train_mask, eval_mask):
    """返回 (spearman, rmse, hotspot_auc)；eval_mask 上的折外/迁移预测。"""
    oof = np.zeros(len(y))
    n_tr = int(train_mask.sum())
    for seed in (42, 43, 44):
        fold_pred = np.zeros(n_tr)
        gkf = GroupKFold(n_splits=5)
        for tr, te in gkf.split(X[train_mask], y[train_mask], groups[train_mask]):
            m = HistGradientBoostingRegressor(max_iter=300, learning_rate=0.08, random_state=seed)
            m.fit(X[train_mask][tr], y[train_mask][tr])
            fold_pred[te] = m.predict(X[train_mask][te])
        oof[train_mask] += fold_pred / 3.0
        # 迁移预测：每 seed 用全训练集模型预测 eval 集
        m = HistGradientBoostingRegressor(max_iter=300, learning_rate=0.08, random_state=seed)
        m.fit(X[train_mask], y[train_mask])
        oof[eval_mask] += m.predict(X[eval_mask]) / 3.0
    pred = oof[eval_mask]
    ye, he = y[eval_mask], h1[eval_mask]
    return (float(stats.spearmanr(pred, ye)[0]),
            float(np.sqrt(np.mean((pred - ye) ** 2))),
            float(roc_auc_score(he, np.abs(pred))))


res_dev = {}
for name, X in (("A_baseline", XA), ("B_plus_plasticity", XB)):
    s, r, a = run(X, mask, mask)
    res_dev[name] = {"spearman": s, "rmse": r, "hotspot_auc": a}
# 迁移（独立代谢靶点 37 条）
res_tr = {}
for name, X in (("A_baseline", XA), ("B_plus_plasticity", XB)):
    s, r, a = run(X, mask, is_target)
    res_tr[name] = {"n": int(is_target.sum()), "spearman": s, "rmse": r, "hotspot_auc": a}

# 复合物级 bootstrap：ΔSpearman 的 CI（dev 集）
diffs = []
for _ in range(1000):
    comps = rng.choice(np.unique(groups[mask]), size=len(np.unique(groups[mask])), replace=True)
    idx = np.concatenate([np.where((groups == c) & mask)[0] for c in comps])
    sA = stats.spearmanr(XA[idx].sum(1) * 0 + y[idx], y[idx])[0]  # placeholder 防错
    break


def boot_diff(X1, X2, n=1000):
    """配对 bootstrap：两个预测向量的 Spearman 差。"""
    oo1, oo2 = np.zeros(len(y)), np.zeros(len(y))
    n_tr = int(mask.sum())
    for seed in (42, 43, 44):
        p1 = np.zeros(n_tr)
        p2 = np.zeros(n_tr)
        for tr, te in GroupKFold(5).split(X1[mask], y[mask], groups[mask]):
            m1 = HistGradientBoostingRegressor(max_iter=300, learning_rate=0.08, random_state=seed).fit(X1[mask][tr], y[mask][tr])
            m2 = HistGradientBoostingRegressor(max_iter=300, learning_rate=0.08, random_state=seed).fit(X2[mask][tr], y[mask][tr])
            p1[te] = m1.predict(X1[mask][te])
            p2[te] = m2.predict(X2[mask][te])
        oo1[mask] += p1 / 3.0
        oo2[mask] += p2 / 3.0
    d = []
    comps = np.unique(groups[mask])
    for _ in range(n):
        pick = rng.choice(comps, size=len(comps), replace=True)
        idx = np.concatenate([np.where((groups == c) & mask)[0] for c in pick])
        if len(np.unique(y[idx])) < 5:
            continue
        d.append(stats.spearmanr(oo1[idx], y[idx])[0] - stats.spearmanr(oo2[idx], y[idx])[0])
    return [float(np.percentile(d, 2.5)), float(np.percentile(d, 97.5))]


# 上面 run() 已重训多次，为省时复用 boot_diff 重跑（样本小，可接受）
ci = boot_diff(XA, XB)

result = {
    "dev_complex_isolated": res_dev,
    "independent_metabolic_target": res_tr,
    "delta_spearman_A_minus_B_ci95": ci,
    "interpretation": "CI 全负=B显著优于A；跨0=差异不显著",
    "n_dev_mutations": int(mask.sum()), "n_target_mutations": int(is_target.sum()),
}
(OUT / "step95_result.json").write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
print(json.dumps(result, indent=2, ensure_ascii=False))
