# -*- coding: utf-8 -*-
"""Step96 加固分析：UniProt 天然变异（疾病相关）与预测/实验界面的重叠。

目的：把"代谢炎症"从应用情境升级为有证据支撑的选择动机——
这些蛋白的已知疾病相关变异是否落在结合界面上？

流程：
1. 从 holo window_metadata 重建每条记录的受体链序列（center_position -> 中心氨基酸）。
2. curl.exe 批量获取 35 个 partner UniProt 条目的 JSON（含序列与 Natural variant 特征），本地缓存。
3. 疾病相关分类：描述含疾病关键词 / "associated with" / "in <Disease>"（规则透明报告）。
4. 全局 Needleman-Wunsch 将链序列比对到 UniProt canonical 序列，建立 auth_pos -> uniprot_pos 映射
   （质量门槛：对齐残基对中同一性 >=0.85 且 UniProt 覆盖率 >=0.50，否则该记录跳过并计数）。
5. 重叠分析：疾病相关变异位点是否落在任一记录的界面残基（label==1）上；
   Fisher 精确检验（变异位点 vs 全部映射位点的界面富集）。
产物：results/Step96_variants/
"""
import json
import re
import subprocess
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "results/Step96_variants"
CACHE = OUT / "uniprotkb_cache"
OUT.mkdir(parents=True, exist_ok=True)
CACHE.mkdir(exist_ok=True)

DISEASE_KEYWORDS = [
    "disease", "carcinoma", "cancer", "diabetes", "obesity", "syndrome", "deficiency",
    "retinopathy", "nephropathy", "neuropathy", "insulin resistance", "asthma",
    "arthritis", "atherosclerosis", "myopathy", "cardiomyopathy", "deafness",
    "epilepsy", "leukemia", "lymphoma", "tumor", "tumour", "adenoma",
    "susceptibility", "impaired", "loss of function", "dysfunction",
]

# ---- 1. 重建链序列 ----
win = pd.read_csv(ROOT / "data/processed/holo/window_metadata.csv")
chain = {}  # record_id -> {auth_pos: aa}
rec_uniprot = {}
for wid, rid, up, pos, seq in win[["window_id", "record_id", "partner_uniprot", "center_position", "sequence"]].itertuples(index=False):
    aa = seq[8] if len(seq) >= 9 else "X"
    chain.setdefault(rid, {})[int(pos)] = aa
    rec_uniprot[rid] = up
print(f"records: {len(chain)}")

# ---- 2. 获取 UniProt 条目 ----
uniprots = sorted({u for u in rec_uniprot.values() if isinstance(u, str) and u})
print(f"unique partner uniprots: {len(uniprots)}")

entries = {}
missing = []
for up in uniprots:
    f = CACHE / f"{up}.json"
    if f.exists():
        entries[up] = json.loads(f.read_text(encoding="utf-8"))
        continue
    missing.append(up)

if missing:
    query = "%20OR%20".join(f"accession:{u}" for u in missing)
    url = f"https://rest.uniprot.org/uniprotkb/stream?format=json&query={query}"
    r = subprocess.run(["curl.exe", "-s", "--max-time", "120", url],
                       capture_output=True, text=True, encoding="utf-8")
    if r.returncode != 0 or not r.stdout.strip():
        raise RuntimeError(f"UniProt fetch failed rc={r.returncode}")
    first = r.stdout.strip()
    if first.startswith("{"):
        batch = json.loads(first).get("results", [])
    elif first.startswith("["):
        batch = json.loads(first)
    else:
        batch = [json.loads(l) for l in first.splitlines() if l.strip()]
    got = {e["primaryAccession"]: e for e in batch}
    for up in missing:
        if up in got:
            (CACHE / f"{up}.json").write_text(json.dumps(got[up]), encoding="utf-8")
            entries[up] = got[up]
        else:
            print(f"WARN not found: {up}")
print(f"entries fetched/cached: {len(entries)}")

# ---- 3. 变异提取与疾病分类 ----
def classify(desc):
    d = (desc or "").lower()
    if any(k in d for k in DISEASE_KEYWORDS):
        return True
    if re.search(r"\bin\s+[A-Z][a-zA-Z0-9 -]{3,}", desc or ""):
        return True
    return False

variant_rows = []
for up, e in entries.items():
    seq = e.get("sequence", {}).get("value", "")
    for ft in e.get("features", []):
        if ft.get("type") != "Natural variant":
            continue
        loc = ft.get("location", {})
        try:
            pos = int(loc["start"]["value"])
        except (KeyError, TypeError):
            continue
        desc = ft.get("description", "") or ""
        alt = ft.get("alternativeSequence", {}) or {}
        wt_aa = alt.get("originalSequence") or (seq[pos - 1] if 0 < pos <= len(seq) else "")
        alts = alt.get("alternativeSequences") or []
        mut_aa = alts[0] if alts else ""
        has_omim = any(x.get("database") == "OMIM" for x in ft.get("featureCrossReferences", []))
        variant_rows.append({
            "uniprot": up, "position": pos, "wt_aa": wt_aa, "mut_aa": mut_aa,
            "description": desc, "has_omim": bool(has_omim),
            "disease_linked": bool(classify(desc) or has_omim),
            "seq_len": len(seq),
        })
variants = pd.DataFrame(variant_rows)
variants.to_csv(OUT / "uniprot_variants.csv", index=False)
print(f"natural variants: {len(variants)}, disease-linked: {int(variants['disease_linked'].sum())}")

# ---- 4. 全局比对（NW）建立 auth_pos -> uniprot_pos ----
def nw_map(chain_seq_pos, up_seq):
    """chain_seq_pos: list[(auth_pos, aa)] 按 auth_pos 排序；返回 dict auth_pos->uniprot_pos(1-based)"""
    a = [aa for _, aa in chain_seq_pos]
    b = list(up_seq)
    n, m = len(a), len(b)
    MATCH, MISMATCH, GAP = 2, -1, -2
    F = np.zeros((n + 1, m + 1), dtype=np.int32)
    F[:, 0] = np.arange(n + 1) * GAP
    F[0, :] = np.arange(m + 1) * GAP
    for i in range(1, n + 1):
        ai = a[i - 1]
        Fi, Fim = F[i], F[i - 1]
        for j in range(1, m + 1):
            s = MATCH if ai == b[j - 1] else MISMATCH
            Fi[j] = max(Fim[j - 1] + s, Fi[j - 1] + GAP, Fim[j] + GAP)
    # 回溯
    i, j = n, m
    mapping, ident, pairs = {}, 0, 0
    while i > 0 and j > 0:
        s = MATCH if a[i - 1] == b[j - 1] else MISMATCH
        if F[i, j] == F[i - 1, j - 1] + s:
            if a[i - 1] == b[j - 1]:
                ident += 1
            pairs += 1
            mapping[chain_seq_pos[i - 1][0]] = j
            i -= 1
            j -= 1
        elif F[i, j] == F[i - 1, j] + GAP:
            i -= 1
        else:
            j -= 1
    ident_frac = ident / max(pairs, 1)
    coverage = pairs / max(m, 1)
    return mapping, ident_frac, coverage

label_lut = {}  # (record_id, auth_pos) -> label
for rid, pos, lab in win[["record_id", "center_position", "label"]].itertuples(index=False):
    label_lut[(rid, int(pos))] = int(lab)

overlap_rows = []
record_stats = []
for rid, pos_aa in chain.items():
    up = rec_uniprot[rid]
    e = entries.get(up)
    if e is None:
        continue
    up_seq = e.get("sequence", {}).get("value", "")
    csp = sorted(pos_aa.items())
    mapping, ident_frac, coverage = nw_map(csp, up_seq)
    ok = ident_frac >= 0.85 and coverage >= 0.50
    record_stats.append({"record_id": rid, "uniprot": up, "ident_frac": round(float(ident_frac), 3),
                         "coverage": round(float(coverage), 3), "mapping_ok": bool(ok),
                         "n_mapped": len(mapping)})
    if not ok:
        continue
    v = variants[variants["uniprot"] == up]
    for _, row in v.iterrows():
        auth = [ap for ap, uj in mapping.items() if uj == row["position"]]
        if not auth:
            continue
        if any(aa != row["wt_aa"] and row["wt_aa"] not in ("", "X") for aa in [pos_aa.get(a) for a in auth]):
            # wt 不一致的映射视为可疑，跳过
            continue
        for a in auth:
            overlap_rows.append({
                "record_id": rid, "uniprot": up, "auth_pos": a, "uniprot_pos": int(row["position"]),
                "wt_aa": row["wt_aa"], "mut_aa": row["mut_aa"],
                "disease_linked": bool(row["disease_linked"]),
                "description": row["description"],
                "interface": bool(label_lut.get((rid, a), 0) == 1),
            })

pd.DataFrame(record_stats).to_csv(OUT / "record_mapping_stats.csv", index=False)
overlap = pd.DataFrame(overlap_rows)
overlap.to_csv(OUT / "variant_interface_overlap.csv", index=False)

# ---- 5. 富集检验 ----
n_ok_records = sum(1 for r in record_stats if r["mapping_ok"])
# 背景：全部映射位点
bg = []
for rid, pos_aa in chain.items():
    st = next((s for s in record_stats if s["record_id"] == rid), None)
    if st is None or not st["mapping_ok"]:
        continue
    up = rec_uniprot[rid]
    e = entries.get(up)
    csp = sorted(pos_aa.items())
    mapping, _, _ = nw_map(csp, e["sequence"]["value"])
    for a, uj in mapping.items():
        bg.append({"record_id": rid, "uniprot": up, "auth_pos": a, "uniprot_pos": uj,
                   "interface": bool(label_lut.get((rid, a), 0) == 1)})
bg = pd.DataFrame(bg)
# 唯一（uniprot_pos 在任一记录为界面）层面统计
if len(overlap):
    var_pos = overlap.groupby(["uniprot", "uniprot_pos"]).agg(
        disease_linked=("disease_linked", "max"),
        at_interface=("interface", "max")).reset_index()
    bg_pos = bg.groupby(["uniprot", "uniprot_pos"])["interface"].max().reset_index()
    merged = bg_pos.merge(var_pos, on=["uniprot", "uniprot_pos"], how="left")
    merged["is_variant"] = merged["disease_linked"].notna()
    dis = merged[merged["disease_linked"] == True] if "disease_linked" in merged else merged.iloc[0:0]
    a_ = int(dis["interface"].sum()); b_ = int((~dis["interface"]).sum())
    nonvar = merged[~merged["is_variant"]]
    c_ = int(nonvar["interface"].sum())
    d_ = int((~nonvar["interface"]).sum())
    oddsratio, pval = stats.fisher_exact([[a_, b_], [c_, d_]], alternative="two-sided")
else:
    var_pos = pd.DataFrame()
    a_ = b_ = c_ = d_ = 0
    oddsratio, pval = np.nan, np.nan

per_protein = (overlap[overlap["disease_linked"]]
               .groupby("uniprot")
               .agg(n_variants=("uniprot_pos", "nunique"),
                    n_at_interface=("interface", "max"))
               .reset_index()) if len(overlap) else pd.DataFrame()

result = {
    "n_records_total": len(chain),
    "n_records_mapping_ok": n_ok_records,
    "n_uniprot": len(uniprots),
    "n_natural_variants": int(len(variants)),
    "n_disease_linked_variants": int(variants["disease_linked"].sum()),
    "n_disease_variants_mapped": int(var_pos[var_pos["disease_linked"] == True].shape[0]) if len(overlap) else 0,
    "n_disease_variants_at_interface": int(a_),
    "fisher": {"table": [[a_, b_], [c_, d_]], "odds_ratio": float(oddsratio), "p_two_sided": float(pval)},
    "per_protein_disease_variants": per_protein.to_dict("records"),
}
(OUT / "step96_result.json").write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
print(json.dumps(result, indent=2, ensure_ascii=False))
