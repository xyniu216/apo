"""Matched-residue comparison of frozen models and official PeSTo inference on BM5.5."""
from __future__ import annotations

import json
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.metrics import roc_auc_score, average_precision_score

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data/processed/external/bm5"
OUT = ROOT / "results/Step57_published_baselines"
SEED = 20261029


def metrics(frame, score) -> dict:
    y = frame.label.to_numpy(dtype=int)
    score = np.asarray(score, dtype=float)
    order = np.argsort(-score, kind="stable")
    return {"windows": len(frame), "positives": int(y.sum()), "prevalence": float(y.mean()),
            "AUC": float(roc_auc_score(y, score)), "AUPRC": float(average_precision_score(y, score)),
            "normalized_AUPRC": float(average_precision_score(y, score) / y.mean()),
            "Top1_precision": float(y[order[:max(1, int(np.ceil(len(y) * .01))) ]].mean()),
            "Top5_precision": float(y[order[:max(1, int(np.ceil(len(y) * .05))) ]].mean())}


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    chains = pd.read_csv(DATA / "chain_sequences_zero_homology.csv")
    chains = chains[chains.external_included == True]
    directory = OUT / "pesto_per_chain"
    frames, missing = [], []
    for row in chains.itertuples(index=False):
        path = directory / f"{row.record_id}_bound.csv"
        if path.exists():
            frames.append(pd.read_csv(path))
        else:
            missing.append(row.record_id)
    pd.DataFrame({"record_id": missing, "status": "MISSING_PREDICTION"}).to_csv(OUT / "pesto_missing_chains.csv", index=False)
    pesto = pd.concat(frames, ignore_index=True) if frames else pd.DataFrame()
    duplicates = pesto[pesto.duplicated(["record_id", "auth_seq_id"], keep=False)].copy()
    duplicates.to_csv(OUT / "pesto_duplicate_author_ids.csv", index=False)
    # Insertion-coded residues can share an author number. Average their probabilities and retain an audit.
    pesto = pesto.groupby(["record_id", "auth_seq_id"], as_index=False).agg(
        pesto_protein=("pesto_protein", "mean"), duplicate_source_rows=("pesto_protein", "size"))
    meta = pd.read_csv(DATA / "window_metadata_zero_homology.csv")
    merged = meta.merge(pesto[["record_id", "auth_seq_id", "pesto_protein"]], on=["record_id", "auth_seq_id"],
                        how="left", validate="one_to_one", indicator=True)
    coverage = merged.groupby("record_id").agg(windows=("window_id", "size"),
        matched_windows=("pesto_protein", lambda x: int(x.notna().sum())),
        coverage=("pesto_protein", lambda x: float(x.notna().mean()))).reset_index()
    coverage.to_csv(OUT / "pesto_window_coverage_by_chain.csv", index=False)
    complete = merged[merged.pesto_protein.notna()].copy()
    models = {
        "PeSTo_i_v4_1": (OUT / "pesto_per_chain", "pesto_protein"),
        "RF_base_structure": (ROOT / "results/Step32_bm5_frozen_models/random_forest/base_structure/ensemble_predictions.csv", "probability"),
        "LightGBM_base_structure": (ROOT / "results/Step32_bm5_frozen_models/lightgbm/base_structure/ensemble_predictions.csv", "probability"),
        "Logistic_base_structure": (ROOT / "results/Step32_bm5_frozen_models/logistic_classweight/base_structure/ensemble_predictions.csv", "probability"),
    }
    score_frame = complete[["window_id", "record_id", "complex_id", "category", "label", "pesto_protein"]].rename(
        columns={"pesto_protein": "PeSTo_i_v4_1"})
    rows = []
    for name, (path, column) in models.items():
        if name == "PeSTo_i_v4_1":
            scores = score_frame[name].to_numpy()
        else:
            prediction = pd.read_csv(path, usecols=["window_id", column])
            score_frame = score_frame.merge(prediction.rename(columns={column: name}), on="window_id",
                                            how="left", validate="one_to_one")
            scores = score_frame[name].to_numpy()
        if np.isnan(scores).any():
            raise ValueError(f"Missing matched scores for {name}")
        rows.append({"model": name, "scope": "PeSTo-matched common residues", **metrics(score_frame, scores)})
        full_meta = meta
        full_prediction = pd.read_csv(path, usecols=["window_id", column]) if name != "PeSTo_i_v4_1" else None
        if full_prediction is not None:
            full = full_meta.merge(full_prediction, on="window_id", validate="one_to_one")
            rows.append({"model": name, "scope": "all_external_windows", **metrics(full, full[column])})
    metric_frame = pd.DataFrame(rows)
    metric_frame.to_csv(OUT / "same_set_global_metrics.csv", index=False)
    complex_rows = []
    for complex_id, part in score_frame.groupby("complex_id", sort=True):
        if part.label.nunique() < 2:
            continue
        for name in models:
            complex_rows.append({"complex_id": complex_id, "model": name, **metrics(part, part[name])})
    complex_frame = pd.DataFrame(complex_rows)
    complex_frame.to_csv(OUT / "same_set_per_complex_metrics.csv", index=False)
    macro = complex_frame.groupby("model").agg(evaluable_complexes=("complex_id", "count"),
        macro_complex_AUC=("AUC", "mean"), median_complex_AUC=("AUC", "median"),
        macro_complex_AUPRC=("AUPRC", "mean"), median_complex_AUPRC=("AUPRC", "median"),
        macro_normalized_AUPRC=("normalized_AUPRC", "mean")).reset_index()
    macro.to_csv(OUT / "same_set_macro_complex_metrics.csv", index=False)
    score_frame.to_csv(OUT / "same_set_residue_scores.csv", index=False)
    rng = np.random.default_rng(SEED)
    complexes = np.array(sorted(score_frame.complex_id.unique()))
    parts = {key: part for key, part in score_frame.groupby("complex_id", sort=True)}
    boot_rows = []
    for iteration in range(1000):
        sampled = rng.choice(complexes, size=len(complexes), replace=True)
        boot = pd.concat([parts[key] for key in sampled], ignore_index=True)
        row = {"iteration": iteration}
        for name in models:
            row[f"{name}_AUPRC"] = average_precision_score(boot.label, boot[name])
            row[f"{name}_AUC"] = roc_auc_score(boot.label, boot[name])
        boot_rows.append(row)
    bootstrap = pd.DataFrame(boot_rows)
    bootstrap.to_csv(OUT / "complex_bootstrap_iterations.csv", index=False)
    intervals = []
    for name in models:
        for metric in ("AUPRC", "AUC"):
            column = f"{name}_{metric}"
            intervals.append({"comparison": column, "mean": bootstrap[column].mean(),
                              "ci95_low": bootstrap[column].quantile(.025), "ci95_high": bootstrap[column].quantile(.975)})
        if name != "RF_base_structure":
            delta = bootstrap[f"{name}_AUPRC"] - bootstrap["RF_base_structure_AUPRC"]
            intervals.append({"comparison": f"{name}_minus_RF_AUPRC", "mean": delta.mean(),
                              "ci95_low": delta.quantile(.025), "ci95_high": delta.quantile(.975)})
    pd.DataFrame(intervals).to_csv(OUT / "complex_bootstrap_ci.csv", index=False)
    summary = {"PeSTo_source": "https://github.com/LBM-EPFL/PeSTo", "PeSTo_version": "i_v4_1",
               "PeSTo_weights_sha256": "b16332284675a0c08fc13ddc783255e46b8d9c9f7ab4306b6908e5009b5b2d1a",
               "external_status": "Frozen same-set extension; BM5.5 was previously evaluated and is not a new untouched cohort",
               "requested_chains": len(chains), "completed_chains": len(frames), "missing_chains": len(missing),
               "all_external_windows": len(meta), "matched_windows": len(complete),
               "matched_complexes": complete.complex_id.nunique(), "matched_chains": complete.record_id.nunique(),
               "matching": "record_id plus author residue number; only matched windows enter same-set comparison",
               "pesto_state": "bound single chain; protein-protein interface output", "seed": SEED}
    (OUT / "comparison_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))
    print(metric_frame.to_string(index=False))
    print(macro.to_string(index=False))


if __name__ == "__main__":
    main()
