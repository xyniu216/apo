"""Cluster-level power and robustness analysis for H1 (apo AUPRC vs aligned CA RMSD)."""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "results/Step107_power_analysis"
TABLE = ROOT / "results/Step82_h1_prereg/pair_level_table.csv"
RNG = np.random.default_rng(20261116)


def fisher_ci(rho, n, alpha=0.05):
    z = np.arctanh(rho)
    se = 1.0 / np.sqrt(max(n - 3, 1))
    zc = stats.norm.ppf(1 - alpha / 2)
    return float(np.tanh(z - zc * se)), float(np.tanh(z + zc * se))


def mde_rho(n_eff, power=0.8, alpha=0.05):
    """Minimum detectable |rho| (Fisher z approximation)."""
    if n_eff <= 4:
        return float("nan")
    z = (stats.norm.ppf(1 - alpha / 2) + stats.norm.ppf(power)) / np.sqrt(n_eff - 3)
    return float(np.tanh(z))


def icc_from_clusters(values, clusters):
    """One-way ANOVA ICC(1)."""
    frame = pd.DataFrame({"v": values, "c": clusters})
    groups = [g.v.to_numpy() for _, g in frame.groupby("c") if len(g) > 1]
    k = len(groups)
    n = len(frame)
    grand = frame.v.mean()
    msb = sum(len(g) * (g.mean() - grand) ** 2 for g in groups) / max(k - 1, 1)
    msw = sum(((g - g.mean()) ** 2).sum() for g in groups) / max(n - k, 1)
    m0 = (n - sum(len(g) ** 2 for g in groups) / n) / max(k - 1, 1)
    if msb + (m0 - 1) * msw == 0:
        return 0.0
    return float(max(0.0, (msb - msw) / (msb + (m0 - 1) * msw)))


def main():
    frame = pd.read_csv(TABLE)
    x = frame.preformation_aligned.to_numpy(float)
    y = frame.pesto_pair_auprc.to_numpy(float)
    rho = stats.spearmanr(x, y).statistic
    n = len(frame)
    clusters = frame.cluster.to_numpy()

    # design effect / effective n
    avg_m = n / frame.cluster.nunique()
    icc_x = icc_from_clusters(x, clusters)
    icc_y = icc_from_clusters(y, clusters)
    icc_mean = float(np.mean([icc_x, icc_y]))
    deff = 1 + (avg_m - 1) * icc_mean
    n_eff = n / deff
    mde_pairs = mde_rho(n)
    mde_clusters = mde_rho(n_eff)

    # leave-one-cluster-out
    loo = []
    for c in sorted(frame.cluster.unique()):
        sub = frame[frame.cluster != c]
        r = stats.spearmanr(sub.preformation_aligned, sub.pesto_pair_auprc)
        loo.append({"cluster_left_out": c, "n_pairs": len(sub), "rho": float(r.statistic),
                    "p": float(r.pvalue)})

    # cluster-block bootstrap of rho
    boots = []
    cl = sorted(frame.cluster.unique())
    for _ in range(2000):
        picked = RNG.choice(cl, size=len(cl), replace=True)
        parts = [frame[frame.cluster == c] for c in picked]
        sub = pd.concat(parts, ignore_index=True)
        boots.append(stats.spearmanr(sub.preformation_aligned, sub.pesto_pair_auprc).statistic)
    boot = np.array(boots, dtype=float)
    ci = [float(np.nanpercentile(boot, 2.5)), float(np.nanpercentile(boot, 97.5))]

    # power at observed effect under pair-level and cluster-level effective n
    def power_at(r, n_used):
        zc = stats.norm.ppf(0.975)
        lam = np.sqrt(n_used - 3) * abs(np.arctanh(r))
        return float(1 - stats.norm.cdf(zc - lam) + stats.norm.cdf(-zc - lam))

    per_cluster = frame.groupby("cluster").agg(n_pairs=("pair_id", "size"),
                                               apo_auprc_mean=("pesto_pair_auprc", "mean"),
                                               rmsd_mean=("preformation_aligned", "mean"))
    rho_cluster_mean = stats.spearmanr(per_cluster.rmsd_mean, per_cluster.apo_auprc_mean)

    result = {
        "n_pairs": n, "n_clusters": int(frame.cluster.nunique()),
        "pairs_per_cluster_mean": float(avg_m),
        "rho_primary": float(rho),
        "fisher_ci_pairs": fisher_ci(float(rho), n),
        "cluster_block_bootstrap_ci": ci,
        "icc_rmsd": icc_x, "icc_auprc": icc_y, "icc_mean": icc_mean,
        "design_effect": float(deff), "effective_n": float(n_eff),
        "mde_rho_pair_level_80pct": mde_pairs,
        "mde_rho_cluster_effective_80pct": mde_clusters,
        "power_at_observed_rho_pair_level": power_at(float(rho), n),
        "power_at_observed_rho_effective": power_at(float(rho), n_eff),
        "cluster_mean_rho": float(rho_cluster_mean.statistic),
        "cluster_mean_p": float(rho_cluster_mean.pvalue),
        "loo_rho_range": [float(min(r["rho"] for r in loo)), float(max(r["rho"] for r in loo))],
        "loo_all_negative": bool(all(r["rho"] < 0 for r in loo)),
        "loo_all_p_lt_0_05": bool(all(r["p"] < 0.05 for r in loo)),
    }
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "power_analysis.json").write_text(json.dumps(result, indent=2, ensure_ascii=False))
    pd.DataFrame(loo).to_csv(OUT / "leave_one_cluster_out.csv", index=False)
    print(json.dumps(result, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
