# -*- coding: utf-8 -*-
"""Step126: 对 Step125 的映射做独立核查（结构侧、编号侧、指标侧）。

核查项
  A. ScanNet CSV 的 (Residue Index, Sequence) 与 CIF 的 auth 编号残基名是否逐位一致
  B. ScanNet CSV 是否存在重复残基编号
  C. meta.apo_position 是否全部落在 CIF 残基编号内，且与 PeSTo 的 auth_seq_id 同集合
  D. 手写 AUPRC 与 sklearn average_precision_score 是否一致（83 对）
  E. 换一条合并路径（纯 merge，不走 dict）重算全部 83 对 AUPRC，与 Step125 结果比对
"""
import glob
import json
import os
import sys

import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score

sys.path.insert(0, r"D:\hnnm\Metabolic_Inflammation_Functional_Interface\code")


def auprc(y, s):
    """与 Step82 / Step125 完全相同的实现（逐位相同代码）。"""
    y = np.asarray(y, dtype=int); s = np.asarray(s, dtype=float)
    order = np.argsort(-s, kind="mergesort")
    y = y[order]; tp = np.cumsum(y); prec = tp / np.arange(1, len(y) + 1)
    return float((prec * y).sum() / y.sum()) if y.sum() else float("nan")

ROOT = r"D:\hnnm\Metabolic_Inflammation_Functional_Interface"
SCAN = os.path.join(ROOT, "data/raw/external_methods/scannet_predictions")
CIF = os.path.join(ROOT, "data/raw/apo/structures")
PESTO = os.path.join(ROOT, "results/Step77_pesto_apo_v3")
META = os.path.join(ROOT, "data/processed/apo_v3/apo_window_metadata_v3.csv")
OOF = os.path.join(ROOT, "results/Step79_c1_v3/c1_v3_oof_scores.csv")
RES = os.path.join(ROOT, "results/Step125_scannet/scannet_pair_level.csv")

from Bio.PDB import MMCIFParser  # noqa: E402

AA3 = {"ALA": "A", "ARG": "R", "ASN": "N", "ASP": "D", "CYS": "C", "GLN": "Q", "GLU": "E",
       "GLY": "G", "HIS": "H", "ILE": "I", "LEU": "L", "LYS": "K", "MET": "M", "PHE": "F",
       "PRO": "P", "SER": "S", "THR": "T", "TRP": "W", "TYR": "Y", "VAL": "V"}

meta = pd.read_csv(META)
oof = pd.read_csv(OOF)
pairs_used = sorted({(a.lower(), c.upper()) for a, c in
                     zip(meta.apo_pdb_id, meta.apo_chain)})

parser = MMCIFParser(QUIET=True)
A_rows, B_rows, C_rows = [], [], []
for pdb, chain in pairs_used:
    csv = os.path.join(SCAN, "%s_%s.csv" % (pdb, chain))
    d = pd.read_csv(csv)
    idx = d["Residue Index"].astype(int).values
    seq = d["Sequence"].astype(str).values
    B_rows.append({"key": "%s_%s" % (pdb, chain), "n": len(d), "n_unique_idx": len(set(idx))})

    st = parser.get_structure(pdb, os.path.join(CIF, "%s.cif" % pdb))[0]
    ch = st[chain] if chain in st else None
    cif_map = {}
    if ch is not None:
        for res in ch:
            if res.id[0] == " ":
                cif_map[int(res.id[1])] = AA3.get(res.resname.strip().upper(), "X")
    match = sum(1 for i, s in zip(idx, seq) if cif_map.get(i) == s)
    mism = [i for i, s in zip(idx, seq) if cif_map.get(i) not in (None, s)]
    absent = [i for i in idx if i not in cif_map]
    A_rows.append({"key": "%s_%s" % (pdb, chain), "n_scan": len(d), "n_cif_std": len(cif_map),
                   "match": match, "match_rate": match / len(d),
                   "mismatch": len(mism), "not_in_cif": len(absent),
                   "first_mism_idx": mism[:3]})

    mp = meta[(meta.apo_pdb_id.str.lower() == pdb) & (meta.apo_chain.str.upper() == chain)]
    pos = set(mp.apo_position.astype(int))
    pset = set()
    for f in glob.glob(os.path.join(PESTO, "*__%s_%s_apo.csv" % (pdb, chain))):
        pset |= set(pd.read_csv(f, usecols=["auth_seq_id"]).auth_seq_id.astype(int))
    C_rows.append({"key": "%s_%s" % (pdb, chain), "n_meta_pos": len(pos),
                   "pos_in_cif": len(pos & set(cif_map)), "pos_in_pesto": len(pos & pset),
                   "meta_minus_pesto": len(pos - pset), "pesto_minus_meta": len(pset - pos)})

A = pd.DataFrame(A_rows); B = pd.DataFrame(B_rows); C = pd.DataFrame(C_rows)
print("=== A 结构侧逐位核对（ScanNet 序列 vs CIF auth 残基名）")
print(A.to_string(index=False))
print("\n=== B 重复编号检查：有重复的键 -> ", B[B.n != B.n_unique_idx].to_dict("records"))
print("\n=== C 编号同源性（meta ∩ CIF ∩ PeSTo）")
print(C.to_string(index=False))

# D 指标实现一致性
res = pd.read_csv(RES)
df = oof.merge(meta[["window_id", "apo_chain", "apo_position"]], on="window_id", how="left")
scans = {}
for f in sorted(glob.glob(os.path.join(SCAN, "*.csv"))):
    stem = os.path.basename(f)[:-4]
    pdb, chain = stem.split("_")[0], stem.split("_")[1]
    d = pd.read_csv(f)
    scans[(pdb, chain.upper())] = dict(zip(d["Residue Index"].astype(int), d["Binding site probability"]))
df["p"] = [scans[(a.lower(), c.upper())].get(int(q), np.nan)
           for a, c, q in zip(df.apo_pdb_id, df.apo_chain, df.apo_position)]
df = df[df.p.notna()]

D_rows = []
for pid, g in df.groupby("pair_id"):
    D_rows.append({"pair_id": pid, "manual": auprc(g.label, g.p),
                   "sklearn": average_precision_score(g.label, g.p),
                   "n": len(g), "pos": int(g.label.sum())})
D = pd.DataFrame(D_rows)
D["absdiff"] = (D.manual - D.sklearn).abs()
print("\n=== D AUPRC 实现一致性：max|Δ| = %.3e（n=%d 对）" % (D.absdiff.max(), len(D)))

# E 与 Step125 结果比对
cmp = D.merge(res[["pair_id", "scannet_auprc", "n_windows", "n_iface"]], on="pair_id", how="outer", indicator=True)
print("=== E 换路径重算 vs Step125：join", cmp._merge.value_counts().to_dict(),
      "max|Δ auprc| = %.3e" % (cmp.manual - cmp.scannet_auprc).abs().max(),
      "n 不一致:", int((cmp.n != cmp.n_windows).sum()))

# 缺口解释：唯一覆盖率 0.994 的那一对
bad = pd.read_csv(os.path.join(ROOT, "results/Step125_scannet/mapping_coverage.csv"))
bad = bad.sort_values("coverage").head(2)
print("\n=== 覆盖不足的 pair")
print(bad.to_string(index=False))
for _, r in bad.iterrows():
    pid = r.pair_id
    g = df[df.pair_id == pid]
    miss = g[g.p.isna()]
    print(pid, "缺失位置:", miss.apo_position.tolist(), "chain", miss.apo_chain.unique(),
          "ScanNet 范围", min(scans[(miss.apo_pdb_id.iloc[0].lower(), miss.apo_chain.iloc[0].upper())]) if len(miss) else "",
          max(scans[(miss.apo_pdb_id.iloc[0].lower(), miss.apo_chain.iloc[0].upper())]) if len(miss) else "")

json.dump({
    "A_match_rate_min": float(A.match_rate.min()),
    "A_total_mismatch": int(A.mismatch.sum()),
    "A_total_not_in_cif": int(A.not_in_cif.sum()),
    "B_duplicate_keys": B[B.n != B.n_unique_idx].key.tolist(),
    "C_meta_pos_not_in_cif": int((C.n_meta_pos - C.pos_in_cif).sum()),
    "C_meta_minus_pesto": int(C.meta_minus_pesto.sum()),
    "C_pesto_minus_meta": int(C.pesto_minus_meta.sum()),
    "D_max_absdiff": float(D.absdiff.max()),
    "E_max_absdiff": float((cmp.manual - cmp.scannet_auprc).abs().max()),
}, open(os.path.join(ROOT, "results/Step125_scannet/verification.json"), "w", encoding="utf-8"),
   ensure_ascii=False, indent=1)
print("\nverification written")
