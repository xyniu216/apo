"""Step111: one coherent pair-level / record-level sensitivity table (v3 vs expansion)."""
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

ROOT = Path(r"D:\hnnm\Metabolic_Inflammation_Functional_Interface")
V3 = ROOT / "results/Step82_h1_prereg/pair_level_table.csv"
SENS = ROOT / "results/Step110_apo_expansion_stats/pair_level_table_sens.csv"
OUT = ROOT / "results/Step111_expansion_summary"
OUT.mkdir(parents=True, exist_ok=True)


def prep(t, rmsd, auprc, fam):
    return t.rename(columns={rmsd: "aligned_ca_rmsd", auprc: "apo_auprc", fam: "family"})


v3 = prep(pd.read_csv(V3), "preformation_aligned", "pesto_pair_auprc", "cluster")
sens = pd.read_csv(SENS)
v3["set"] = "v3 (<=3 apo/record)"
sens["set"] = "expansion (<=12 apo/record)"

rows = []
for name, frame in (("v3", v3), ("expansion", sens)):
    for scope, sub in (("all", frame), ("development", frame[frame.dataset == "DEVELOPMENT"]),
                       ("temporal", frame[frame.dataset == "TEMPORAL_HOLDOUT"])):
        r = stats.spearmanr(sub.aligned_ca_rmsd, sub.apo_auprc)
        rows.append({"set": name, "level": "pair", "scope": scope, "n": len(sub),
                     "rho": round(float(r.statistic), 4), "p": round(float(r.pvalue), 6)})
    rec = (frame.groupby(["record_id", "family", "dataset"], as_index=False)
           .agg(aligned_ca_rmsd=("aligned_ca_rmsd", "mean"), apo_auprc=("apo_auprc", "mean"),
                n_apo=("apo_auprc", "size")))
    for scope, sub in (("all", rec), ("development", rec[rec.dataset == "DEVELOPMENT"]),
                       ("temporal", rec[rec.dataset == "TEMPORAL_HOLDOUT"])):
        r = stats.spearmanr(sub.aligned_ca_rmsd, sub.apo_auprc)
        rows.append({"set": name, "level": "record", "scope": scope, "n": len(sub),
                     "rho": round(float(r.statistic), 4), "p": round(float(r.pvalue), 6)})
    rng = np.random.default_rng(20261116)
    cl = sorted(rec.family.unique())
    vals = []
    for _ in range(5000):
        picked = rng.choice(cl, size=len(cl), replace=True)
        sub = pd.concat([rec[rec.family == c] for c in picked], ignore_index=True)
        if sub.family.nunique() < 3:
            continue
        vals.append(stats.spearmanr(sub.aligned_ca_rmsd, sub.apo_auprc).statistic)
    v = np.array(vals, dtype=float)
    rows.append({"set": name, "level": "record", "scope": "cluster_bootstrap_CI",
                 "n": len(rec), "rho": "", "p": ""})
    rows[-1]["ci_low"] = round(float(np.nanpercentile(v, 2.5)), 4)
    rows[-1]["ci_high"] = round(float(np.nanpercentile(v, 97.5)), 4)

table = pd.DataFrame(rows)
table.to_csv(OUT / "sensitivity_summary.csv", index=False)
print(table.to_string(index=False))

# descriptive scale of the two sets
desc = {
    "v3": {"pairs": len(v3), "records": int(v3.record_id.nunique()),
           "families": int(v3.family.nunique()),
           "apo_structures": int(v3.apo_pdb_id.nunique()),
           "auprc_median": float(v3.apo_auprc.median())},
    "expansion": {"pairs": len(sens), "records": int(sens.record_id.nunique()),
                  "families": int(sens.family.nunique()),
                  "apo_structures": int(sens.apo_pdb_id.nunique()),
                  "windows": int(sens.n_windows.sum()),
                  "auprc_median": float(sens.apo_auprc.median())},
}
(OUT / "scale.json").write_text(json.dumps(desc, indent=2, ensure_ascii=False))
print(json.dumps(desc, indent=2, ensure_ascii=False))
