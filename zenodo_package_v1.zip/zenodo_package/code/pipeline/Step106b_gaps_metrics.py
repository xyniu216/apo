"""Step106b: GAPS metrics on the PeSTo-matched BM5.5 evaluation set.

Merges per-residue GAPS probabilities (Step106) onto the zero-homology window
metadata and restricts to the exact 115,215-window subset used for all other
baselines (windows with a PeSTo prediction), so the comparison is same-set.
"""
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score, roc_auc_score

ROOT = Path(r"D:\hnnm\Metabolic_Inflammation_Functional_Interface")
DATA = ROOT / "data/processed/external/bm5"
S57 = ROOT / "results/Step57_published_baselines"
OUT = ROOT / "results/Step106_gaps_baseline"
GAPS = OUT / "residue_scores_full.csv"


def metrics(frame, score):
    y = frame.label.to_numpy(dtype=int)
    score = np.asarray(score, dtype=float)
    order = np.argsort(-score, kind="stable")
    top1 = max(1, int(np.ceil(len(y) * 0.01)))
    top5 = max(1, int(np.ceil(len(y) * 0.05)))
    return {"windows": len(frame), "positives": int(y.sum()), "prevalence": float(y.mean()),
            "AUC": float(roc_auc_score(y, score)), "AUPRC": float(average_precision_score(y, score)),
            "normalized_AUPRC": float(average_precision_score(y, score) / y.mean()),
            "Top1_precision": float(y[order[:top1]].mean()),
            "Top5_precision": float(y[order[:top5]].mean())}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--scores", default=str(GAPS))
    args = ap.parse_args()

    chains = pd.read_csv(DATA / "chain_sequences_zero_homology.csv")
    chains = chains[chains.external_included == True]  # noqa: E712
    frames = []
    for row in chains.itertuples(index=False):
        path = S57 / "pesto_per_chain" / f"{row.record_id}_bound.csv"
        if path.exists():
            frames.append(pd.read_csv(path))
    pesto = pd.concat(frames, ignore_index=True)
    pesto = pesto.groupby(["record_id", "auth_seq_id"], as_index=False).agg(
        pesto_protein=("pesto_protein", "mean"))

    meta = pd.read_csv(DATA / "window_metadata_zero_homology.csv")
    g = pd.read_csv(args.scores)
    g = g.groupby(["pdb_id", "chain_id", "auth_seq_id"], as_index=False).agg(
        gaps_probability=("gaps_probability", "mean"))

    merged = meta.merge(pesto[["record_id", "auth_seq_id", "pesto_protein"]],
                        on=["record_id", "auth_seq_id"], how="left")
    merged = merged.merge(g, on=["pdb_id", "chain_id", "auth_seq_id"], how="left")
    matched = merged[merged.pesto_protein.notna()].copy()
    covered = matched[matched.gaps_probability.notna()].copy()
    print(f"matched windows={len(matched)} with GAPS={len(covered)} "
          f"({len(covered)/max(len(matched),1):.2%})")

    if len(covered) < len(matched):
        missing = matched[matched.gaps_probability.isna()]
        miss_summary = (missing.groupby(["pdb_id", "chain_id"]).size()
                        .reset_index(name="n_windows").sort_values("n_windows", ascending=False))
        miss_summary.to_csv(OUT / "matched_missing_windows.csv", index=False)
        print("missing top:\n", miss_summary.head(15).to_string(index=False))

    row = {"model": "GAPS", "scope": "PeSTo-matched common residues", **metrics(covered, covered.gaps_probability)}
    frame = pd.DataFrame([row])
    frame.to_csv(OUT / "matched_metrics.csv", index=False)

    # combined table with the existing baselines for the manuscript
    existing = pd.read_csv(ROOT / "results/Step104_xgboost_baseline/matched_global_metrics.csv")
    combined = pd.concat([existing, frame], ignore_index=True)
    combined.to_csv(OUT / "matched_global_metrics_with_gaps.csv", index=False)
    print(combined.to_string(index=False))


if __name__ == "__main__":
    main()
