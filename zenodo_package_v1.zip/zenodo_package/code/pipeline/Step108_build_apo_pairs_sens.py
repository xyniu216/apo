"""Step108 (cap-relaxed sensitivity expansion): multi-apo pair building with a higher cap.

Finding (Step74/75): the single-protein apo pool is exhausted (104 entries /
14 receptors; tier-2 unusable — receptors with tier-2 hits are not partners in
the main data). The one remaining lever is using MULTIPLE apo structures per
holo record: Step03 used one best apo per record, but 50/65 records had >=2
valid candidates. This raises the number of independent PAIRS (complex-level
bootstrap units) from 55 to ~100+ while keeping the label/mapping rules from
Step03 identical.

Rules (unchanged from Step03): sequence identity >= 0.8, interface coverage
>= 0.5, mapped interface residues >= 5; windows = 17-mers around each mapped
position (same as v2 features). Up to MAX_APO_PER_RECORD=3 apo structures per
record, ranked by (interface_coverage, sequence_identity, mapped residues).
Tier-2 entries are NOT used (see Step75: unusable for main-data partners).

Per-record caching in results/Step76_apo_pairs_v3/_cache allows resume.
"""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "code"))
sys.path.append(str(ROOT / "docs/paper/_revision_work/_bio"))
import structure_utils as su  # noqa: E402
import feature_utils as fu  # noqa: E402

OUT = ROOT / "results/Step108_apo_expansion"
CACHE = OUT / "_cache"
RAW = ROOT / "data/raw/apo/structures_v3"
PROC = ROOT / "data/processed/apo_v4_sens"
for p in (OUT, CACHE, RAW, PROC):
    p.mkdir(parents=True, exist_ok=True)

MAX_APO_PER_RECORD = 12
OLD = ROOT.parent / "Metabolic_Inflammation_Binding_Expanded"

import requests  # noqa: E402
sys.path.append(str(ROOT / "docs/paper/_revision_work/_bio"))
from concurrent.futures import ThreadPoolExecutor, as_completed  # noqa: E402


def download(pdb: str) -> Path:
    target = RAW / f"{pdb}.cif"
    if target.exists() and target.stat().st_size > 1000:
        return target
    import subprocess
    for i in range(3):
        try:
            r = subprocess.run(["curl.exe", "-s", "-m", "90", "-o", str(target),
                                f"https://files.rcsb.org/download/{pdb.upper()}.cif"],
                               capture_output=True, timeout=100)
            if r.returncode == 0 and target.exists() and target.stat().st_size > 1000:
                return target
        except Exception:
            pass
        time.sleep(2)
    raise RuntimeError(f"download failed {pdb}")


def main() -> None:
    from Bio.Align import PairwiseAligner
    from Bio.PDB import MMCIFParser, ShrakeRupley

    def align_maps(holo, apo):
        aligner = PairwiseAligner()
        aligner.mode = "global"
        aligner.match_score = 2
        aligner.mismatch_score = -1
        aligner.open_gap_score = -5
        aligner.extend_gap_score = -0.5
        a = aligner.align(holo, apo)[0]
        mapping, matches, aligned = {}, 0, 0
        for (hs, he), (as_, ae) in zip(*a.aligned):
            for h, p in zip(range(hs, he), range(as_, ae)):
                mapping[h + 1] = p + 1
                aligned += 1
                matches += int(holo[h] == apo[p])
        return mapping, matches / max(aligned, 1)

    def kabsch_rmsd(a, b):
        ac = a - a.mean(0)
        bc = b - b.mean(0)
        u, s, vt = np.linalg.svd(ac.T @ bc)
        d = np.sign(np.linalg.det(u @ vt))
        rot = u @ np.diag([1, 1, d]) @ vt
        return float(np.sqrt(((ac @ rot - bc) ** 2).sum(1).mean()))

    apo_entities = pd.read_csv(ROOT / "results/Step02_apo/apo_polymer_entities.csv",
                               keep_default_na=False, dtype={"entity_id": str})
    pdbs = apo_entities.pdb_id.unique()
    with ThreadPoolExecutor(max_workers=4) as pool:
        futures = {pool.submit(download, p): p for p in pdbs}
        for f in as_completed(futures):
            try:
                f.result()
            except Exception as e:
                print("DOWNLOAD ERROR", futures[f], e, flush=True)

    holo = pd.concat([pd.read_csv(p) for p in (ROOT / "data/processed/holo/interfaces").glob("*_residues.csv")
                      if p.stat().st_size > 10], ignore_index=True)
    oldmeta = pd.read_csv(ROOT / "data/processed/holo/window_metadata.csv")
    window_lookup = oldmeta.set_index(["record_id", "center_position"]).window_id.to_dict()
    parser = MMCIFParser(QUIET=True)

    def process_record(record, block):
        audits, windows, fb, fs, disps = [], [], [], [], []
        block = block.sort_values("position")
        hseq = "".join(block.amino_acid)
        labels = block.label.to_numpy()
        positive_positions = set(block.loc[block.label == 1, "position"])
        candidates = []
        for apo in apo_entities[apo_entities.uniprot.apply(
                lambda x: block.partner_uniprot.iloc[0] in x.split(";"))].itertuples(index=False):
            try:
                model = parser.get_structure(apo.pdb_id, str(download(apo.pdb_id)))[0]
                for chain_id in apo.auth_chains.split(";"):
                    if chain_id not in model:
                        continue
                    obs = su.residues(model[chain_id])
                    aseq = "".join(a for r, a in obs)
                    mapping, identity = align_maps(hseq, aseq)
                    mapped_pos = [p for p in positive_positions if p in mapping]
                    coverage = len(mapped_pos) / max(len(positive_positions), 1)
                    candidates.append({"apo_pdb_id": apo.pdb_id, "apo_chain": chain_id,
                                       "sequence_identity": identity,
                                       "interface_coverage": coverage,
                                       "mapped_interface_residues": len(mapped_pos),
                                       "mapping": mapping, "obs": obs, "model": model})
            except Exception as e:
                audits.append({"record_id": record, "apo_pdb_id": apo.pdb_id,
                               "status": "ERROR", "error": str(e)})
        valid = [c for c in candidates
                 if c["sequence_identity"] >= .8 and c["interface_coverage"] >= .5
                 and c["mapped_interface_residues"] >= 5]
        for c in candidates:
            audits.append({k: v for k, v in c.items() if k not in ("mapping", "obs", "model")}
                          | {"status": "CANDIDATE"})
        valid.sort(key=lambda c: (c["interface_coverage"], c["sequence_identity"],
                                    c["mapped_interface_residues"]), reverse=True)
        chosen = valid[:MAX_APO_PER_RECORD]
        for c in chosen:
            audits.append({k: v for k, v in c.items() if k not in ("mapping", "obs", "model")}
                          | {"status": "INCLUDE"})
        for best in chosen:
            chain_id, model, obs, mapping = best["apo_chain"], best["model"], best["obs"], best["mapping"]
            chain = model[chain_id]
            ShrakeRupley().compute(chain, level="R")
            obs2, struct = su.structural_features(chain)
            segments, seg, prev = [], 0, None
            for r, a in obs2:
                auth = r.get_id()[1]
                if prev is None or auth != prev + 1:
                    seg += 1
                prev = auth
                segments.append(seg)
            obs, struct = obs2, struct
            aseq = "".join(a for r, a in obs)
            hmodel = parser.get_structure(block.pdb_id.iloc[0], str(
                OLD / "data/raw/pdb" / f"{block.pdb_id.iloc[0]}.cif"))[0]
            hchain = hmodel[block.partner_chain.iloc[0]]
            hobs = su.residues(hchain)
            common = [p for p in mapping if p <= len(hobs)]
            hc = np.array([hobs[p - 1][0]["CA"].coord for p in common])
            ac = np.array([obs[mapping[p] - 1][0]["CA"].coord for p in common])
            imask = np.array([p in positive_positions for p in common])
            rmsd = kabsch_rmsd(hc, ac) if len(common) >= 3 else np.nan
            irmsd = kabsch_rmsd(hc[imask], ac[imask]) if imask.sum() >= 3 else np.nan
            audits.append({"record_id": record, "apo_pdb_id": best["apo_pdb_id"],
                           "apo_chain": chain_id, "status": "CONFORMATION",
                           "aligned_ca_rmsd": rmsd, "interface_ca_rmsd": irmsd,
                           "aligned_residues": len(common)})
            rsa = np.array([float(getattr(r, "sasa", np.nan)) / su.MAX_ASA[a]
                            for r, a in obs])
            rsa = np.nan_to_num(rsa, nan=0.0)
            for hp, ap in mapping.items():
                if ap < 9 or ap > len(obs) - 8:
                    continue
                hrow = block.iloc[hp - 1]
                start, end = ap - 9, ap + 8
                wseq = aseq[start:end + 1]
                names, b, e = fu.names_and_values(wseq, rsa[start:end + 1])
                window_id = f"{record}__{best['apo_pdb_id']}_{chain_id}_{ap}"
                windows.append({"window_id": window_id,
                                "holo_window_id": window_lookup.get((record, hp), ""),
                                "record_id": record, "holo_pdb_id": block.pdb_id.iloc[0],
                                "apo_pdb_id": best["apo_pdb_id"], "apo_chain": chain_id,
                                "family": hrow.family, "partner_gene": hrow.partner_gene,
                                "partner_uniprot": hrow.partner_uniprot,
                                "dataset": oldmeta[oldmeta.record_id == record].dataset.iloc[0],
                                "holo_position": hp, "apo_position": ap,
                                "label": int(hrow.label),
                                "sequence_identity": best["sequence_identity"],
                                "interface_coverage": best["interface_coverage"],
                                "aligned_ca_rmsd": rmsd, "interface_ca_rmsd": irmsd})
                fb.append(b)
                fs.append(np.array(list(struct[ap - 1].values()), dtype=np.float32))
            for hp, ap in mapping.items():
                if hp <= len(hobs) and ap <= len(obs):
                    d = float(np.linalg.norm(hobs[hp - 1][0]["CA"].coord
                                             - obs[ap - 1][0]["CA"].coord))
                    disps.append({"record_id": record, "apo_pdb_id": best["apo_pdb_id"],
                                "holo_position": hp, "apo_position": ap,
                                "label": int(block.iloc[hp - 1].label),
                                "raw_ca_displacement": d})
        return audits, windows, fb, fs, disps

    records = sorted(holo.record_id.unique())
    all_audits, all_windows, FB, FS = [], [], [], []
    for record in records:
        cache = CACHE / f"{record}.npz"
        if cache.exists():
            z = np.load(cache, allow_pickle=True)
            all_audits.append(pd.read_csv(CACHE / f"{record}_audit.csv"))
            all_windows.append(pd.read_csv(CACHE / f"{record}_windows.csv"))
            FB.append(z["base"])
            FS.append(z["structure"])
            continue
        block = holo[holo.record_id == record]
        audits, windows, fb, fs, disps = process_record(record, block)
        aud = pd.DataFrame(audits)
        win = pd.DataFrame(windows)
        aud.to_csv(CACHE / f"{record}_audit.csv", index=False)
        win.to_csv(CACHE / f"{record}_windows.csv", index=False)
        if len(fb):
            np.savez_compressed(cache, base=np.stack(fb), structure=np.stack(fs))
            all_audits.append(aud)
            all_windows.append(win)
            FB.append(np.stack(fb))
            FS.append(np.stack(fs))
        print(record, "windows:", len(win), "includes:",
              (aud.status == "INCLUDE").sum() if len(aud) else 0, flush=True)

    audit = pd.concat(all_audits, ignore_index=True)
    meta = pd.concat(all_windows, ignore_index=True)
    audit.to_csv(OUT / "apo_pair_audit_sens.csv", index=False)
    meta.to_csv(PROC / "apo_window_metadata_sens.csv", index=False)
    np.savez_compressed(PROC / "apo_features_sens.npz", base=np.vstack(FB), structure=np.vstack(FS))
    included = audit[audit.status == "INCLUDE"].drop_duplicates(["record_id", "apo_pdb_id"])
    summary = {"holo_interfaces": int(len(records)),
               "pairs_v3": int(len(included)),
               "pairs_v2_reference": 55,
               "apo_structures_used": int(included.apo_pdb_id.nunique()),
               "records_with_multiple_apo": int((included.groupby("record_id").size() >= 2).sum()),
               "apo_windows": int(len(meta)),
               "apo_positive_windows": int(meta.label.sum())}
    (OUT / "apo_pair_summary_sens.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
