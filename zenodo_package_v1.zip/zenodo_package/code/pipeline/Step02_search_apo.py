"""Search single-protein PDB entries for target-ligand-free apo receptor candidates."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import json,time
import pandas as pd
import requests
ROOT=Path(__file__).resolve().parents[1]
OLD=ROOT.parent/"Metabolic_Inflammation_Binding_Expanded"
RAW=ROOT/"data/raw/apo/search";META=ROOT/"data/raw/apo/metadata"
OUT=ROOT/"results/Step02_apo"
for p in (RAW,META,OUT):p.mkdir(parents=True,exist_ok=True)
ATTR="rcsb_polymer_entity_container_identifiers.reference_sequence_identifiers.database_accession"

def get_json(url,target,payload=None):
    if target.exists() and target.stat().st_size>100:return json.loads(target.read_text(encoding="utf-8"))
    for attempt in range(3):
        try:
            r=requests.post(url,json=payload,timeout=50) if payload else requests.get(url,timeout=50);r.raise_for_status();d=r.json();target.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding="utf-8");return d
        except Exception:
            if attempt==2:raise
            time.sleep(attempt+1)

def main():
    registry=pd.read_csv(OLD/"data/metadata/family_registry.csv");receptors=registry[["partner_uniprot","partner_gene"]].drop_duplicates();rows=[];ids=set()
    for r in receptors.itertuples(index=False):
        query={"query":{"type":"group","logical_operator":"and","nodes":[{"type":"terminal","service":"text","parameters":{"attribute":ATTR,"operator":"exact_match","value":r.partner_uniprot}},{"type":"terminal","service":"text","parameters":{"attribute":"rcsb_entry_info.polymer_entity_count_protein","operator":"equals","value":1}}]},"return_type":"entry","request_options":{"paginate":{"start":0,"rows":500},"results_content_type":["experimental"]}}
        try:
            d=get_json("https://search.rcsb.org/rcsbsearch/v2/query",RAW/f"{r.partner_uniprot}.json",query);found=[x["identifier"].lower() for x in d.get("result_set",[])];ids.update(found);rows.append({"partner_uniprot":r.partner_uniprot,"partner_gene":r.partner_gene,"status":"OK","single_protein_entries":len(found),"pdb_ids":";".join(found)});print(r.partner_gene,len(found),flush=True)
        except requests.HTTPError as e:
            if e.response is not None and e.response.status_code==404:rows.append({"partner_uniprot":r.partner_uniprot,"partner_gene":r.partner_gene,"status":"NO_HIT","single_protein_entries":0,"pdb_ids":""})
            else:rows.append({"partner_uniprot":r.partner_uniprot,"partner_gene":r.partner_gene,"status":"ERROR","error":str(e)})
        except Exception as e:rows.append({"partner_uniprot":r.partner_uniprot,"partner_gene":r.partner_gene,"status":"ERROR","error":str(e)})
    pd.DataFrame(rows).to_csv(OUT/"apo_search_summary.csv",index=False)
    holo=pd.read_csv(OLD/"results/Step01_pdb_download/polymer_entities.csv",keep_default_na=False,dtype={"entity_id":str});holo_ids=set(holo.pdb_id)
    def task(pdb):
        entry=get_json(f"https://data.rcsb.org/rest/v1/core/entry/{pdb}",META/f"{pdb}_entry.json");out=[]
        for eid in entry.get("rcsb_entry_container_identifiers",{}).get("polymer_entity_ids",[]):
            e=get_json(f"https://data.rcsb.org/rest/v1/core/polymer_entity/{pdb}/{eid}",META/f"{pdb}_{eid}.json");info=e.get("rcsb_polymer_entity",{});ident=e.get("rcsb_polymer_entity_container_identifiers",{});refs=e.get("rcsb_polymer_entity_align",[]);uniprot=sorted({x.get("reference_database_accession","") for x in refs if x.get("reference_database_name")=="UniProt"})
            out.append({"pdb_id":pdb,"entity_id":str(eid),"description":info.get("pdbx_description",""),"auth_chains":";".join(ident.get("auth_asym_ids",[])),"sequence":info.get("pdbx_seq_one_letter_code_can",""),"uniprot":";".join(uniprot),"release_date":entry.get("rcsb_accession_info",{}).get("initial_release_date",""),"title":entry.get("struct",{}).get("title",""),"nonpolymer_entity_count":entry.get("rcsb_entry_info",{}).get("nonpolymer_entity_count",0)})
        return out
    entities=[];fail=[]
    with ThreadPoolExecutor(max_workers=6) as pool:
        futures={pool.submit(task,p):p for p in sorted(ids-holo_ids)}
        for f in as_completed(futures):
            try:entities.extend(f.result());print("META",futures[f],flush=True)
            except Exception as e:fail.append({"pdb_id":futures[f],"error":str(e)})
    pd.DataFrame(entities).to_csv(OUT/"apo_polymer_entities.csv",index=False);pd.DataFrame(fail).to_csv(OUT/"apo_metadata_failures.csv",index=False)
    print("TOTAL",len(ids-holo_ids),"candidate apo entries",len(entities),"entities",len(fail),"failures",flush=True)
if __name__=="__main__":main()
