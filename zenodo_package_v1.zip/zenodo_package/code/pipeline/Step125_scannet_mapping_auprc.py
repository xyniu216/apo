# -*- coding: utf-8 -*-
"""Step125: ScanNet noMSA 逐残基概率 -> 与 v3 apo 窗口口径对齐 -> 83 对 AUPRC 与方向性检验。

口径与 Step82 完全一致：
  - 窗口集合 = data/processed/apo_v3/apo_window_metadata_v3.csv（18,965 个逐残基位置）
  - 标签 = results/Step79_c1_v3/c1_v3_oof_scores.csv 的 label（PeSTo 基线同款）
  - AUPRC = Step82 里的 auprc(y, s)，逐对计算
  - 映射键 = (apo_pdb_id, apo_chain, apo_position)；ScanNet 的 Residue Index 与其同源（Bio.PDB auth_seq_id）
"""
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

ROOT = Path(r"D:\hnnm\Metabolic_Inflammation_Functional_Interface")
META = ROOT / "data/processed/apo_v3/apo_window_metadata_v3.csv"
OOF = ROOT / "results/Step79_c1_v3/c1_v3_oof_scores.csv"
PAIRS = ROOT / "results/Step82_h1_prereg/pair_level_table.csv"
SCAN = ROOT / "data/raw/external_methods/scannet_predictions"
OUT = ROOT / "results/Step125_scannet"
OUT.mkdir(parents=True, exist_ok=True)

N_BOOT = 2000
rng = np.random.default_rng(20261126)


def auprc(y, s):
    y = np.asarray(y, dtype=int); s = np.asarray(s, dtype=float)
    order = np.argsort(-s, kind="mergesort")
    y = y[order]; tp = np.cumsum(y); prec = tp / np.arange(1, len(y) + 1)
    return float((prec * y).sum() / y.sum()) if y.sum() else float("nan")


def boot_spearman(x, y, n=N_BOOT):
    x = np.asarray(x, float); y = np.asarray(y, float)
    r = np.empty(n)
    for i in range(n):
        idx = rng.integers(0, len(x), len(x))
        r[i] = stats.spearmanr(x[idx], y[idx])[0] if len(np.unique(x[idx])) > 2 else np.nan
    r = r[~np.isnan(r)]
    return [float(np.percentile(r, 2.5)), float(np.percentile(r, 97.5))]


meta = pd.read_csv(META)
oof = pd.read_csv(OOF)
pairs = pd.read_csv(PAIRS)
df = oof.merge(meta[["window_id", "apo_chain", "apo_position", "interface_ca_rmsd",
                     "aligned_ca_rmsd", "interface_coverage"]], on="window_id", how="left")
print("windows:", len(df), "pairs:", df.pair_id.nunique())

# ---- ScanNet 概率表 ----
scan = {}
for f in sorted(SCAN.glob("*.csv")):
    pdb, chain = f.stem.split("_")[0], f.stem.split("_")[1]
    d = pd.read_csv(f)
    scan[(pdb.lower(), chain.upper())] = pd.Series(
        d["Binding site probability"].values, index=d["Residue Index"].astype(int).values)

meta_keys = set(zip(df.apo_pdb_id.str.lower(), df.apo_chain.str.upper()))
scan_keys = set(scan)
print("apo chains in meta:", len(meta_keys), "scan csv:", len(scan_keys))
print("meta 有而 ScanNet 缺:", sorted(meta_keys - scan_keys))
print("ScanNet 有而 meta 无:", sorted(scan_keys - meta_keys))

# ---- 逐对映射与覆盖 ----
df["apo_key"] = list(zip(df.apo_pdb_id.str.lower(), df.apo_chain.str.upper()))
df["scan_prob"] = [scan[k].get(int(p), np.nan) if k in scan else np.nan
                   for k, p in zip(df["apo_key"], df["apo_position"])]

cov_rows = []
for (pair_id, rec, apo, chain), g in df.groupby(["pair_id", "record_id", "apo_pdb_id", "apo_chain"]):
    n = len(g); hit = int(g.scan_prob.notna().sum())
    cov_rows.append({"pair_id": pair_id, "apo_pdb_id": apo, "apo_chain": chain,
                     "n_windows": n, "n_mapped": hit, "coverage": hit / n,
                     "first_pos": int(g.apo_position.min()), "last_pos": int(g.apo_position.max())})
cov = pd.DataFrame(cov_rows).sort_values("coverage")
cov.to_csv(OUT / "mapping_coverage.csv", index=False)
print("\nper-pair mapping coverage: min %.3f  median %.3f  n<0.95: %d"
      % (cov.coverage.min(), cov.coverage.median(), int((cov.coverage < 0.95).sum())))
print(cov.head(8).to_string(index=False))

# ---- 逐对 AUPRC ----
rows = []
for pair_id, g in df.groupby("pair_id"):
    g = g[g.scan_prob.notna()]
    if len(g) < 20 or g.label.sum() < 3:
        continue
    r = pairs[pairs.pair_id == pair_id].iloc[0]
    rows.append({"pair_id": pair_id, "record_id": r.record_id, "apo_pdb_id": r.apo_pdb_id,
                 "cluster": r.cluster, "dataset": r.dataset,
                 "aligned_rmsd": r.preformation_aligned, "iface_rmsd": r.preformation_iface_rmsd,
                 "pesto_auprc": r.pesto_pair_auprc,
                 "scannet_auprc": auprc(g.label, g.scan_prob),
                 "n_windows": len(g), "n_iface": int(g.label.sum()),
                 "mapping_coverage": len(g) / len(df[df.pair_id == pair_id])})
res = pd.DataFrame(rows).sort_values("aligned_rmsd")
res.to_csv(OUT / "scannet_pair_level.csv", index=False)

print("\npairs scored:", len(res))
print(res[["aligned_rmsd", "pesto_auprc", "scannet_auprc", "mapping_coverage"]].describe().to_string())

# ---- 方向性与一致性 ----
rho_rmsd, p_rmsd = stats.spearmanr(res.aligned_rmsd, res.scannet_auprc)
ci_rmsd = boot_spearman(res.aligned_rmsd, res.scannet_auprc)
rho_pe, p_pe = stats.spearmanr(res.pesto_auprc, res.scannet_auprc)
ci_pe = boot_spearman(res.pesto_auprc, res.scannet_auprc)
rho_rmsd_pe, p_rmsd_pe = stats.spearmanr(res.aligned_rmsd, res.pesto_auprc)
summary = {
    "n_pairs": int(len(res)),
    "scannet_auprc_mean": float(res.scannet_auprc.mean()),
    "scannet_auprc_median": float(res.scannet_auprc.median()),
    "pesto_auprc_mean": float(res.pesto_auprc.mean()),
    "rho_rmsd_vs_scannet": float(rho_rmsd), "p": float(p_rmsd), "ci": ci_rmsd,
    "rho_rmsd_vs_pesto_same_subset": float(rho_rmsd_pe), "p_pesto": float(p_rmsd_pe),
    "rho_pesto_vs_scannet": float(rho_pe), "p_pesto_scannet": float(p_pe), "ci_pesto_scannet": ci_pe,
    "min_mapping_coverage": float(res.mapping_coverage.min()),
}
(OUT / "scannet_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=1), encoding="utf-8")
print("\n" + json.dumps(summary, ensure_ascii=False, indent=1))
