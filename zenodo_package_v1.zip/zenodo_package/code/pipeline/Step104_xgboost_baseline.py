"""XGBoost baseline on the frozen development set, evaluated on BM5 zero-homology bound/unbound.

Reuses the exact leakage-safe splits, feature matrix, threshold selection and metrics of
Step32_bm5_frozen_models / baseline_utils. Does not tune on external data.
Outputs an ensemble prediction CSV in the same schema as the RF/LGBM/Logistic baselines.
"""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
from xgboost import XGBClassifier

CODE = Path(__file__).resolve().parent
sys.path.insert(0, str(CODE))
import baseline_utils as common  # noqa: E402

ROOT = common.ROOT
OUT = ROOT / "results/Step104_xgboost_baseline"
FEATURE_SET = "base_structure"


def new_xgboost(y, seed):
    positives = int(y.sum())
    negatives = len(y) - positives
    return XGBClassifier(
        n_estimators=220,
        learning_rate=0.035,
        max_depth=5,
        min_child_weight=40,
        colsample_bytree=0.8,
        subsample=0.85,
        reg_lambda=2.0,
        scale_pos_weight=negatives / max(positives, 1),
        eval_metric="logloss",
        tree_method="hist",
        n_jobs=4,
        random_state=seed,
        verbosity=0,
    )


def main():
    started = time.time()
    destination = OUT / "xgboost" / FEATURE_SET
    destination.mkdir(parents=True, exist_ok=True)

    _, dev, dev_features = common.load_development()
    x_dev = common.feature_matrix(dev, dev_features, FEATURE_SET)
    y_dev = dev.label.to_numpy(dtype=int)

    external = pd.read_csv(ROOT / "data/processed/external/bm5/window_metadata_zero_homology.csv")
    archive = np.load(ROOT / "data/processed/external/bm5/bm5_features_zero_homology.npz")
    x_bound = common.feature_matrix(
        external,
        {"base": archive["base"], "structure": archive["structure"], "sequence_extended": np.empty((len(external), 0))},
        FEATURE_SET,
    )
    x_unbound = common.feature_matrix(
        external,
        {"base": archive["unbound_base"], "structure": archive["unbound_structure"], "sequence_extended": np.empty((len(external), 0))},
        FEATURE_SET,
    )

    seed_predictions, rows = [], []
    for seed in common.SEEDS:
        inner_train, inner_valid = common.inner_indices(dev.reset_index(drop=True), seed + 707)
        classifier = new_xgboost(y_dev[inner_train], seed)
        classifier.fit(x_dev[inner_train], y_dev[inner_train])
        threshold = common.threshold_mcc(y_dev[inner_valid], classifier.predict_proba(x_dev[inner_valid])[:, 1])

        classifier = new_xgboost(y_dev, seed)
        classifier.fit(x_dev, y_dev)
        probability = classifier.predict_proba(x_bound)[:, 1]
        unbound_probability = classifier.predict_proba(x_unbound)[:, 1]

        output = external[["window_id", "record_id", "complex_id", "pdb_id", "chain_id", "side", "category",
                           "external_homology_cluster", "label"]].copy()
        output["seed"] = seed
        output["probability"] = probability
        output["unbound_probability"] = unbound_probability
        output["threshold"] = threshold
        seed_predictions.append(output)

        for state, values in [("BOUND", probability), ("UNBOUND", unbound_probability)]:
            row = common.metrics(external.label, values, threshold)
            row.update({"model": "xgboost", "feature_set": FEATURE_SET, "seed": seed, "state": state})
            rows.append(row)
        print("xgboost", FEATURE_SET, seed, rows[-2]["AUC"], rows[-2]["AUPRC"], flush=True)

    raw = pd.concat(seed_predictions, ignore_index=True)
    raw.to_csv(destination / "seed_predictions.csv", index=False)
    metadata = external[["window_id", "record_id", "complex_id", "pdb_id", "chain_id", "side", "category",
                          "external_homology_cluster", "label"]]
    ensemble = raw.groupby("window_id").agg(
        probability=("probability", "mean"),
        unbound_probability=("unbound_probability", "mean"),
        threshold=("threshold", "mean"),
    ).reset_index()
    ensemble = metadata.merge(ensemble, on="window_id", validate="one_to_one")
    ensemble.to_csv(destination / "ensemble_predictions.csv", index=False)

    for state, column in [("BOUND", "probability"), ("UNBOUND", "unbound_probability")]:
        row = common.metrics(ensemble.label, ensemble[column], ensemble.threshold.mean())
        row.update({"model": "xgboost", "feature_set": FEATURE_SET, "seed": "ENSEMBLE", "state": state})
        rows.append(row)
    pd.DataFrame(rows).to_csv(destination / "external_metrics.csv", index=False)

    summary = {
        "model": "xgboost",
        "feature_set": FEATURE_SET,
        "seeds": list(common.SEEDS),
        "training": "DEVELOPMENT only; homology-isolated inner threshold; external data never used for fitting or tuning",
        "external_complexes": int(external.complex_id.nunique()),
        "external_chains": int(external.record_id.nunique()),
        "external_windows": len(external),
        "zero_pdb_and_homology_overlap": True,
        "estimator": "XGBClassifier hist, n_estimators=220, lr=0.035, max_depth=5, min_child_weight=40, "
                     "colsample=0.8, subsample=0.85, reg_lambda=2.0, scale_pos_weight=imbalance",
        "elapsed_seconds": time.time() - started,
    }
    (destination / "run_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2), flush=True)


if __name__ == "__main__":
    main()
