"""Build 40% identity / 50% coverage homology clusters for the 122 interfaces."""
from __future__ import annotations

import json
from itertools import combinations
from pathlib import Path

import numpy as np
import pandas as pd
from Bio.Align import PairwiseAligner

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "results" / "Step17_homology_clusters"
IDENTITY_CUTOFF = 0.40
COVERAGE_CUTOFF = 0.50


class DisjointSet:
    def __init__(self, items):
        self.parent = {item: item for item in items}

    def find(self, item):
        while self.parent[item] != item:
            self.parent[item] = self.parent[self.parent[item]]
            item = self.parent[item]
        return item

    def union(self, left, right):
        left, right = self.find(left), self.find(right)
        if left != right:
            self.parent[right] = left


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    frames = [pd.read_csv(path) for path in sorted((ROOT / "data/processed/holo/interfaces").glob("*_residues.csv")) if path.stat().st_size > 10]
    residues = pd.concat(frames, ignore_index=True)
    current_records = set(pd.read_csv(ROOT / "data/processed/holo/window_metadata.csv", usecols=["record_id"]).record_id)
    residues = residues[residues.record_id.isin(current_records)].copy()
    records = []
    for record_id, block in residues.groupby("record_id", sort=True):
        first = block.iloc[0]
        sequence = "".join(block.sort_values(["segment_id", "position"]).amino_acid.astype(str))
        records.append({
            "record_id": record_id,
            "pdb_id": first.pdb_id,
            "family": first.family,
            "partner_gene": first.partner_gene,
            "partner_uniprot": first.partner_uniprot,
            "dataset": "TEMPORAL_HOLDOUT" if pd.Timestamp(first.release_date, tz="UTC") >= pd.Timestamp("2024-01-01", tz="UTC") else "DEVELOPMENT",
            "observed_sequence": sequence,
            "observed_length": len(sequence),
        })
    frame = pd.DataFrame(records)
    assert len(frame) == 122, f"Expected 122 interfaces, found {len(frame)}"
    dsu = DisjointSet(frame.record_id)
    for _, block in frame.groupby("partner_uniprot"):
        ids = block.record_id.tolist()
        for record_id in ids[1:]:
            dsu.union(ids[0], record_id)

    aligner = PairwiseAligner()
    aligner.mode = "global"
    aligner.match_score = 2.0
    aligner.mismatch_score = -1.0
    aligner.open_gap_score = -10.0
    aligner.extend_gap_score = -0.5
    pair_rows = []
    indexed = frame.set_index("record_id")
    for left, right in combinations(frame.record_id, 2):
        seq1 = indexed.loc[left, "observed_sequence"]
        seq2 = indexed.loc[right, "observed_sequence"]
        alignment = aligner.align(seq1, seq2)[0]
        a, b = str(alignment[0]), str(alignment[1])
        columns = len(a)
        matches = sum(x == y for x, y in zip(a, b))
        paired = sum(x != "-" and y != "-" for x, y in zip(a, b))
        identity = matches / columns if columns else 0.0
        coverage = paired / min(len(seq1), len(seq2))
        homology_edge = identity >= IDENTITY_CUTOFF and coverage >= COVERAGE_CUTOFF
        if homology_edge:
            dsu.union(left, right)
        pair_rows.append({
            "record_id_1": left, "record_id_2": right,
            "partner_uniprot_1": indexed.loc[left, "partner_uniprot"],
            "partner_uniprot_2": indexed.loc[right, "partner_uniprot"],
            "identity": identity, "coverage_shorter_sequence": coverage,
            "alignment_columns": columns, "homology_edge": homology_edge,
        })
    pd.DataFrame(pair_rows).to_csv(OUT / "pairwise_sequence_similarity.csv", index=False)

    components = {}
    for record_id in frame.record_id:
        components.setdefault(dsu.find(record_id), []).append(record_id)
    ordered = sorted(components.values(), key=lambda ids: min(ids))
    cluster_map = {record_id: f"H{index:03d}" for index, ids in enumerate(ordered, 1) for record_id in ids}
    frame["homology_cluster"] = frame.record_id.map(cluster_map)
    frame.to_csv(OUT / "interface_homology_mapping.csv", index=False)
    with (OUT / "interface_sequences.fasta").open("w", encoding="utf-8") as handle:
        for row in frame.itertuples(index=False):
            handle.write(f">{row.record_id}|{row.partner_uniprot}|{row.homology_cluster}\n{row.observed_sequence}\n")

    metadata = pd.read_csv(ROOT / "data/processed/holo/window_metadata.csv")
    metadata["homology_cluster"] = metadata.record_id.map(cluster_map)
    assert metadata.homology_cluster.notna().all()
    metadata.to_csv(OUT / "window_metadata_homology.csv", index=False)
    cluster_summary = frame.groupby("homology_cluster").agg(
        interfaces=("record_id", "size"), receptors=("partner_uniprot", "nunique"),
        families=("family", lambda x: ";".join(sorted(set(x)))),
        partner_genes=("partner_gene", lambda x: ";".join(sorted(set(x)))),
        datasets=("dataset", lambda x: ";".join(sorted(set(x)))),
    ).reset_index()
    cluster_summary.to_csv(OUT / "homology_cluster_summary.csv", index=False)
    summary = {
        "interfaces": len(frame), "receptors": frame.partner_uniprot.nunique(),
        "homology_clusters": frame.homology_cluster.nunique(),
        "multi_receptor_clusters": int((cluster_summary.receptors > 1).sum()),
        "largest_cluster_interfaces": int(cluster_summary.interfaces.max()),
        "identity_cutoff": IDENTITY_CUTOFF, "coverage_cutoff_shorter_sequence": COVERAGE_CUTOFF,
        "same_uniprot_forced_together": True,
        "development_clusters": frame.loc[frame.dataset == "DEVELOPMENT", "homology_cluster"].nunique(),
        "temporal_clusters": frame.loc[frame.dataset == "TEMPORAL_HOLDOUT", "homology_cluster"].nunique(),
        "clusters_spanning_development_and_temporal": int((cluster_summary.datasets == "DEVELOPMENT;TEMPORAL_HOLDOUT").sum()),
        "homology_edges": int(sum(row["homology_edge"] for row in pair_rows)),
    }
    (OUT / "homology_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2), flush=True)
    print(cluster_summary.to_string(index=False), flush=True)


if __name__ == "__main__":
    main()
