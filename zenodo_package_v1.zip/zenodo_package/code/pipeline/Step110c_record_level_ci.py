"""Step110c: cluster-block bootstrap CI for the record-level expansion estimate."""
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

ROOT = Path(r"D:\hnnm\Metabolic_Inflammation_Functional_Interface")
OUT = ROOT / "results/Step110_apo_expansion_stats"
PESTO = ROOT / "results/Step109_pesto_apo_sens"
t = pd.read_csv(OUT / "pair_level_table_sens.csv")
rec = (t.groupby(["record_id", "family"], as_index=False)
       .agg(apo_auprc=("apo_auprc", "mean"), aligned_ca_rmsd=("aligned_ca_rmsd", "mean"),
            n_apo=("apo_auprc", "size")))
rng = np.random.default_rng(20261116)

vals = []
cl = sorted(rec.family.unique())
for _ in range(5000):
    picked = rng.choice(cl, size=len(cl), replace=True)
    sub = pd.concat([rec[rec.family == c] for c in picked], ignore_index=True)
    if sub.family.nunique() < 3:
        continue
    vals.append(stats.spearmanr(sub.aligned_ca_rmsd, sub.apo_auprc).statistic)
v = np.array(vals, dtype=float)
ci = [float(np.nanpercentile(v, 2.5)), float(np.nanpercentile(v, 97.5))]

# Fisher z CI as a reference for the point estimate
r0 = stats.spearmanr(rec.aligned_ca_rmsd, rec.apo_auprc).statistic
n = len(rec)
z = np.arctanh(r0)
se = 1 / np.sqrt(n - 3)
fisher = [float(np.tanh(z - 1.96 * se)), float(np.tanh(z + 1.96 * se))]

res = {"n_records": n, "n_clusters": len(cl), "rho": float(r0),
       "cluster_bootstrap_ci": ci, "fisher_ci": fisher}
(OUT / "record_level_ci.json").write_text(json.dumps(res, indent=2))
print(json.dumps(res, indent=2))
