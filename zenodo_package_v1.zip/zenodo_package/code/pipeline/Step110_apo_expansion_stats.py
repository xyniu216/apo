"""Step110: pair-level apo AUPRC and H1 replication on the cap-relaxed expansion set.

The expansion set uses up to 12 apo structures per holo record (vs 3 in the
pre-registered v3 set) over the same 104-entry single-protein apo pool. It is a
sensitivity analysis: more pairs, identical pairing/mapping/label rules.
"""
from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats
from sklearn.metrics import average_precision_score

ROOT = Path(r"D:\hnnm\Metabolic_Inflammation_Functional_Interface")
PROC = ROOT / "data/processed/apo_v4_sens"
PESTO = ROOT / "results/Step109_pesto_apo_sens"
OUT = ROOT / "results/Step110_apo_expansion_stats"
RNG = np.random.default_rng(20261116)


def pair_table():
    meta = pd.read_csv(PROC / "apo_window_metadata_sens.csv")
    keys = ["record_id", "apo_pdb_id", "apo_chain"]
    rows = []
    for (rec, apo, chain), g in meta.groupby(keys):
        path = PESTO / f"{rec}__{apo}_{chain}_apo.csv"
        if not path.exists():
            continue
        pred = pd.read_csv(path, usecols=["auth_seq_id", "pesto_protein"])
        pred = pred.rename(columns={"auth_seq_id": "apo_position"})
        merged = g.merge(pred, on="apo_position", how="left", validate="one_to_one")
        if merged.pesto_protein.isna().any():
            merged = merged[merged.pesto_protein.notna()]
        if len(merged) == 0 or merged.label.nunique() < 2:
            continue
        rows.append({
            "pair_id": f"{rec}__{apo}_{chain}",
            "record_id": rec, "apo_pdb_id": apo, "apo_chain": chain,
            "cluster": g.family.iloc[0],
            "family": g.family.iloc[0],
            "dataset": g.dataset.iloc[0],
            "n_windows": len(merged),
            "apo_auprc": float(average_precision_score(merged.label, merged.pesto_protein)),
            "aligned_ca_rmsd": float(g.aligned_ca_rmsd.iloc[0]),
            "interface_ca_rmsd": float(g.interface_ca_rmsd.iloc[0]),
            "sequence_identity": float(g.sequence_identity.iloc[0]),
            "interface_coverage": float(g.interface_coverage.iloc[0]),
        })
    return pd.DataFrame(rows)


def cluster_bootstrap(frame, x, y, n=2000):
    cl = sorted(frame.cluster.unique())
    vals = []
    for _ in range(n):
        picked = RNG.choice(cl, size=len(cl), replace=True)
        parts = [frame[frame.cluster == c] for c in picked]
        sub = pd.concat(parts, ignore_index=True)
        if sub.cluster.nunique() < 3:
            continue
        vals.append(stats.spearmanr(sub[x], sub[y]).statistic)
    v = np.array(vals, dtype=float)
    return [float(np.nanpercentile(v, 2.5)), float(np.nanpercentile(v, 97.5))]


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    table = pair_table()
    table.to_csv(OUT / "pair_level_table_sens.csv", index=False)
    dev = table[table.dataset == "DEVELOPMENT"].copy()

    out = {"n_pairs_total": len(table), "n_clusters_total": int(table.cluster.nunique()),
           "n_pairs_dev": len(dev), "n_clusters_dev": int(dev.cluster.nunique())}
    for label, frame in (("all", table), ("development", dev)):
        r = stats.spearmanr(frame.aligned_ca_rmsd, frame.apo_auprc)
        out[label] = {
            "n_pairs": len(frame), "rho": float(r.statistic), "p": float(r.pvalue),
            "cluster_bootstrap_ci": cluster_bootstrap(frame, "aligned_ca_rmsd", "apo_auprc"),
        }

    # leave-one-cluster-out over the full set
    loo = []
    for c in sorted(table.cluster.unique()):
        sub = table[table.cluster != c]
        r = stats.spearmanr(sub.aligned_ca_rmsd, sub.apo_auprc)
        loo.append({"cluster_left_out": c, "n_pairs": len(sub), "rho": float(r.statistic),
                    "p": float(r.pvalue)})
    pd.DataFrame(loo).to_csv(OUT / "leave_one_cluster_out_sens.csv", index=False)
    out["loo_rho_range"] = [float(min(r["rho"] for r in loo)), float(max(r["rho"] for r in loo))]
    out["loo_all_negative"] = bool(all(r["rho"] < 0 for r in loo))

    # negative controls, mirroring the pre-registered secondary metrics
    for name, col in (("interface_rmsd", "interface_ca_rmsd"), ("coverage", "interface_coverage")):
        r = stats.spearmanr(table[col], table.apo_auprc)
        out[f"control_{name}"] = {"rho": float(r.statistic), "p": float(r.pvalue)}

    import json
    (OUT / "expansion_stats.json").write_text(json.dumps(out, indent=2, ensure_ascii=False))
    print(json.dumps(out, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
