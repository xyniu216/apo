"""Step110b: independence-aware views of the cap-relaxed expansion set."""
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

ROOT = Path(r"D:\hnnm\Metabolic_Inflammation_Functional_Interface")
OUT = ROOT / "results/Step110_apo_expansion_stats"
t = pd.read_csv(OUT / "pair_level_table_sens.csv")

res = {}
for name, sub in (("all", t), ("development", t[t.dataset == "DEVELOPMENT"]),
                  ("temporal", t[t.dataset == "TEMPORAL_HOLDOUT"])):
    r = stats.spearmanr(sub.aligned_ca_rmsd, sub.apo_auprc)
    res[name] = {"n_pairs": len(sub), "rho": float(r.statistic), "p": float(r.pvalue),
                 "auprc_median": float(sub.apo_auprc.median()),
                 "rmsd_median": float(sub.aligned_ca_rmsd.median())}

# one value per holo record: removes the up-to-12-apo pseudo-replication
rec = (t.groupby(["record_id", "family", "dataset"], as_index=False)
       .agg(apo_auprc=("apo_auprc", "mean"), aligned_ca_rmsd=("aligned_ca_rmsd", "mean"),
            n_apo=("apo_auprc", "size")))
for name, sub in (("record_all", rec), ("record_development", rec[rec.dataset == "DEVELOPMENT"]),
                  ("record_temporal", rec[rec.dataset == "TEMPORAL_HOLDOUT"])):
    r = stats.spearmanr(sub.aligned_ca_rmsd, sub.apo_auprc)
    res[name] = {"n_records": len(sub), "rho": float(r.statistic), "p": float(r.pvalue)}

# cluster-mean level
cl = (rec.groupby(["family", "dataset"], as_index=False)
      .agg(apo_auprc=("apo_auprc", "mean"), aligned_ca_rmsd=("aligned_ca_rmsd", "mean"),
           n_records=("apo_auprc", "size")))
r = stats.spearmanr(cl.aligned_ca_rmsd, cl.apo_auprc)
res["cluster_mean"] = {"n_clusters": len(cl), "rho": float(r.statistic), "p": float(r.pvalue)}

# bin trend on the full expansion set
t["rmsd_bin"] = pd.cut(t.aligned_ca_rmsd, [0, 1, 2, 4, 8, 100],
                       labels=["<1", "1-2", "2-4", "4-8", ">8"])
bt = t.groupby("rmsd_bin").agg(n=("apo_auprc", "size"), auprc_median=("apo_auprc", "median")).reset_index()
res["rmsd_bins"] = bt.to_dict(orient="records")

(OUT / "expansion_stats_independence.json").write_text(json.dumps(res, indent=2, ensure_ascii=False))
print(json.dumps(res, indent=2, ensure_ascii=False))
