"""Align holo interfaces to independent single-protein apo structures and build paired features."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import json,time
import numpy as np
import pandas as pd
import requests
from Bio.PDB import MMCIFParser,ShrakeRupley
from Bio.Align import PairwiseAligner
import structure_utils as su
import feature_utils as fu
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/"results/Step03_apo_pairs";RAW=ROOT/"data/raw/apo/structures";PROC=ROOT/"data/processed/apo"
for p in (OUT,RAW,PROC):p.mkdir(parents=True,exist_ok=True)

def download(pdb):
    target=RAW/f"{pdb}.cif"
    if target.exists() and target.stat().st_size>1000:return target
    for i in range(3):
        try:
            r=requests.get(f"https://files.rcsb.org/download/{pdb.upper()}.cif",timeout=90);r.raise_for_status();target.write_bytes(r.content);return target
        except Exception:
            if i==2:raise
            time.sleep(2)

def align_maps(holo,apo):
    aligner=PairwiseAligner();aligner.mode="global";aligner.match_score=2;aligner.mismatch_score=-1;aligner.open_gap_score=-5;aligner.extend_gap_score=-.5
    a=aligner.align(holo,apo)[0];mapping={};matches=0;aligned=0
    for (hs,he),(as_,ae) in zip(*a.aligned):
        for h,p in zip(range(hs,he),range(as_,ae)):
            mapping[h+1]=p+1;aligned+=1;matches+=int(holo[h]==apo[p])
    return mapping,matches/max(aligned,1)

def kabsch_rmsd(a,b):
    ac=a-a.mean(0);bc=b-b.mean(0);u,s,vt=np.linalg.svd(ac.T@bc);d=np.sign(np.linalg.det(u@vt));rot=u@np.diag([1,1,d])@vt;return float(np.sqrt(((ac@rot-bc)**2).sum(1).mean()))

def main():
    apo_entities=pd.read_csv(ROOT/"results/Step02_apo/apo_polymer_entities.csv",keep_default_na=False,dtype={"entity_id":str})
    pdbs=apo_entities.pdb_id.unique()
    with ThreadPoolExecutor(max_workers=6) as pool:
        futures={pool.submit(download,p):p for p in pdbs}
        for f in as_completed(futures):
            try:f.result()
            except Exception as e:print("DOWNLOAD ERROR",futures[f],e,flush=True)
    holo=pd.concat([pd.read_csv(p) for p in (ROOT/"data/processed/holo/interfaces").glob("*_residues.csv") if p.stat().st_size>10],ignore_index=True)
    oldmeta=pd.read_csv(ROOT/"data/processed/holo/window_metadata.csv");window_lookup=oldmeta.set_index(["record_id","center_position"]).window_id.to_dict()
    parser=MMCIFParser(QUIET=True);cache={};audits=[];windows=[];features_base=[];features_struct=[];displacements=[]
    for record,block in holo.groupby("record_id",sort=True):
        block=block.sort_values("position");hseq="".join(block.amino_acid);labels=block.label.to_numpy();positive_positions=set(block.loc[block.label==1,"position"])
        candidates=[]
        for apo in apo_entities[apo_entities.uniprot.apply(lambda x:block.partner_uniprot.iloc[0] in x.split(";"))].itertuples(index=False):
            try:
                model=parser.get_structure(apo.pdb_id,download(apo.pdb_id))[0]
                for chain_id in apo.auth_chains.split(";"):
                    if chain_id not in model:continue
                    obs=su.residues(model[chain_id]);aseq="".join(a for r,a in obs);mapping,identity=align_maps(hseq,aseq);mapped_pos=[p for p in positive_positions if p in mapping];coverage=len(mapped_pos)/max(len(positive_positions),1)
                    candidates.append({"record_id":record,"pdb_id":block.pdb_id.iloc[0],"family":block.family.iloc[0],"partner_gene":block.partner_gene.iloc[0],"partner_uniprot":block.partner_uniprot.iloc[0],"apo_pdb_id":apo.pdb_id,"apo_chain":chain_id,"sequence_identity":identity,"interface_coverage":coverage,"mapped_interface_residues":len(mapped_pos),"holo_interface_residues":len(positive_positions),"mapping":mapping,"obs":obs,"model":model})
            except Exception as e:audits.append({"record_id":record,"apo_pdb_id":apo.pdb_id,"status":"ERROR","error":str(e)})
        valid=[c for c in candidates if c["sequence_identity"]>=.8 and c["interface_coverage"]>=.5 and c["mapped_interface_residues"]>=5]
        for c in candidates:
            audits.append({k:v for k,v in c.items() if k not in ("mapping","obs","model")}|{"status":"CANDIDATE"})
        if not valid:continue
        best=max(valid,key=lambda c:(c["interface_coverage"],c["sequence_identity"],c["mapped_interface_residues"]));best["status"]="INCLUDE";audits.append({k:v for k,v in best.items() if k not in ("mapping","obs","model")})
        chain_id=best["apo_chain"];model=best["model"];obs=best["obs"];mapping=best["mapping"]
        cache_key=(best["apo_pdb_id"],chain_id)
        if cache_key not in cache:
            chain=model[chain_id];ShrakeRupley().compute(chain,level="R");obs2,struct=su.structural_features(chain);segments=[];seg=0;prev=None
            for r,a in obs2:
                auth=r.get_id()[1]
                if prev is None or auth!=prev+1:seg+=1
                prev=auth;segments.append(seg)
            cache[cache_key]=(obs2,struct,segments)
        obs,struct,segments=cache[cache_key];coords_h=np.array([r["CA"].coord for r,a in su.residues(model[chain_id])]);aseq="".join(a for r,a in obs)
        # Holo coordinates are loaded only for conformational measurements, not model features.
        hmodel=parser.get_structure(block.pdb_id.iloc[0],ROOT.parent/"Metabolic_Inflammation_Binding_Expanded/data/raw/pdb"/f"{block.pdb_id.iloc[0]}.cif")[0];hchain=hmodel[block.partner_chain.iloc[0]];hobs=su.residues(hchain)
        common=[p for p in mapping if p<=len(hobs)];hc=np.array([hobs[p-1][0]["CA"].coord for p in common]);ac=np.array([obs[mapping[p]-1][0]["CA"].coord for p in common]);interface_mask=np.array([p in positive_positions for p in common])
        rmsd=kabsch_rmsd(hc,ac) if len(common)>=3 else np.nan;irmsd=kabsch_rmsd(hc[interface_mask],ac[interface_mask]) if interface_mask.sum()>=3 else np.nan
        audits.append({"record_id":record,"apo_pdb_id":best["apo_pdb_id"],"apo_chain":chain_id,"status":"CONFORMATION","aligned_ca_rmsd":rmsd,"interface_ca_rmsd":irmsd,"aligned_residues":len(common)})
        for hp,ap in mapping.items():
            if ap<9 or ap>len(obs)-8:continue
            hrow=block.iloc[hp-1];start=ap-9;end=ap+8;wseq=aseq[start:end+1];rsa=np.array([float(getattr(r,"sasa",np.nan))/su.MAX_ASA[a] for r,a in obs]);rsa=np.nan_to_num(rsa,nan=0.0)
            names,b,e=fu.names_and_values(wseq,rsa[start:end+1]);window_id=f"{record}__{best['apo_pdb_id']}_{chain_id}_{ap}"
            windows.append({"window_id":window_id,"holo_window_id":window_lookup.get((record,hp),""),"record_id":record,"holo_pdb_id":block.pdb_id.iloc[0],"apo_pdb_id":best["apo_pdb_id"],"apo_chain":chain_id,"family":hrow.family,"partner_gene":hrow.partner_gene,"partner_uniprot":hrow.partner_uniprot,"dataset":oldmeta[(oldmeta.record_id==record)].dataset.iloc[0],"holo_position":hp,"apo_position":ap,"label":int(hrow.label),"sequence_identity":best["sequence_identity"],"interface_coverage":best["interface_coverage"],"aligned_ca_rmsd":rmsd,"interface_ca_rmsd":irmsd})
            features_base.append(b);features_struct.append(np.array(list(struct[ap-1].values()),dtype=np.float32))
        for hp,ap in mapping.items():
            if hp<=len(hobs) and ap<=len(obs):
                d=float(np.linalg.norm(hobs[hp-1][0]["CA"].coord-obs[ap-1][0]["CA"].coord));displacements.append({"record_id":record,"apo_pdb_id":best["apo_pdb_id"],"holo_position":hp,"apo_position":ap,"label":int(block.iloc[hp-1].label),"raw_ca_displacement":d})
    audit=pd.DataFrame(audits);audit.to_csv(OUT/"apo_pair_audit.csv",index=False);meta=pd.DataFrame(windows);meta.to_csv(PROC/"apo_window_metadata.csv",index=False);np.savez_compressed(PROC/"apo_features.npz",base=np.stack(features_base),structure=np.stack(features_struct));pd.DataFrame(displacements).to_csv(OUT/"apo_holo_residue_displacements.csv",index=False)
    included=audit[audit.status=="INCLUDE"].drop_duplicates(["record_id","apo_pdb_id"]);summary={"holo_interfaces":holo.record_id.nunique(),"paired_holo_interfaces":len(included),"apo_structures_used":included.apo_pdb_id.nunique() if len(included) else 0,"receptors_with_pairs":included.partner_uniprot.nunique() if len(included) else 0,"apo_windows":len(meta),"apo_positive_windows":int(meta.label.sum()) if len(meta) else 0,"median_interface_coverage":float(included.interface_coverage.median()) if len(included) else 0}
    (OUT/"apo_pair_summary.json").write_text(json.dumps(summary,indent=2),encoding="utf-8");print(json.dumps(summary,indent=2),flush=True)
if __name__=="__main__":main()
