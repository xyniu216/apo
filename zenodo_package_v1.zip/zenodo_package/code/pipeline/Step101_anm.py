# -*- coding: utf-8 -*-
"""Step101: ANM（各向异性网络模型）简正模柔性验证——补充材料级。
问题：apo 晶体结构的固有理论柔性（ANM 低频率大位移模式）是否与观测到的
结合诱导重排残基（局部位移 top-25%）重合？
方法：对每对（X-ray/EM apo 结构，仅取其映射链 Cα），构建 ANM Hessian
（截止 10 Å，Kirchhoff 形式），取 20 个最低非零本征模的残基均方位移
B_i = sum_k (1/λ_k) * |u_{i,k}|^2 作为固有柔性分数；
逐对计算 Spearman(ANM 柔性, 观测局部位移)，并以 Mann-Whitney AUC 检验
可塑残基（top-25%）的 ANM 柔性是否高于其余残基。
输出：results/Step101_anm/anm_summary.json + anm_per_pair.csv
"""
import csv, json, os, sys
import numpy as np
from scipy import stats
from Bio.PDB.MMCIFParser import MMCIFParser
from Bio.PDB.Polypeptide import is_aa

ROOT = r"D:\hnnm\Metabolic_Inflammation_Functional_Interface"
PDB = os.path.join(ROOT, "data", "raw", "pdb")
OUT = os.path.join(ROOT, "results", "Step101_anm")
os.makedirs(OUT, exist_ok=True)

CUTOFF = 10.0
N_MODES = 20

parser = MMCIFParser(QUIET=True)

def anm_flexibility(xyz, n_modes=N_MODES):
    """返回每个残基的 ANM 柔性分数（低 20 模均方位移和）。"""
    n = len(xyz)
    d = np.linalg.norm(xyz[:, None, :] - xyz[None, :, :], axis=-1)
    contact = (d < CUTOFF) & (d > 0)
    # Kirchhoff 矩阵（超简 ANM：γ=1，忽略 Hesse 3x3 块细节，用标量近似）
    K = np.diag(contact.sum(1).astype(float)) - contact.astype(float)
    # 完整 3N Hesse：H_ii = sum_j Γ_ij, H_ij = -Γ_ij；Γ_ij = (r_ij r_ij^T)/|r_ij|^2
    H = np.zeros((3 * n, 3 * n))
    for i in range(n):
        for j in range(n):
            if contact[i, j]:
                r = xyz[i] - xyz[j]
                g = np.outer(r, r) / (r @ r)
                H[3*i:3*i+3, 3*i:3*i+3] += g
                H[3*i:3*i+3, 3*j:3*j+3] -= g
    w, v = np.linalg.eigh(H)
    nz = w > 1e-6
    w, v = w[nz], v[:, nz]
    idx = np.argsort(w)[:n_modes]
    w, v = w[idx], v[:, idx]
    # 残基 i 的柔性：sum_k (1/λ_k) * |u_i,k|^2
    flex = np.zeros(n)
    for k in range(len(w)):
        u = v[:, k].reshape(n, 3)
        flex += (u ** 2).sum(1) / w[k]
    return flex

# 83 对位移 + 仅 X-ray/EM apo
disp = {}
meta = {}
for r in csv.DictReader(open(os.path.join(ROOT, "results", "Step86_displacement", "per_residue_displacement_v3.csv"), encoding="utf-8")):
    key = (r["record_id"], r["apo_pdb_id"])
    if key not in meta:
        meta[key] = r["apo_chain"]
    disp.setdefault(key, []).append((int(r["apo_position"]), float(r["local_ca_displacement"])))

qc = list(csv.DictReader(open(os.path.join(ROOT, "results", "Step97_structure_qc", "pair_structure_qc.csv"), encoding="utf-8-sig")))
method = {(r["record_id"], r["apo_pdb_id"]): r["apo_method"] for r in qc}

results = []
for key, chain_id in meta.items():
    if method.get(key) not in ("X-RAY DIFFRACTION", "ELECTRON MICROSCOPY"):
        continue
    rec, apo = key
    try:
        s = parser.get_structure(apo.upper(), os.path.join(PDB, apo + ".cif"))[0][chain_id]
    except Exception:
        continue
    xyz, seq_pos = [], []
    for res in s:
        if is_aa(res) and "CA" in res:
            seq_pos.append(res.id[1]); xyz.append(res["CA"].coord)
    if len(xyz) < 30:
        continue
    xyz = np.array(xyz); seq_pos = np.array(seq_pos)
    try:
        flex = anm_flexibility(xyz)
    except np.linalg.LinAlgError:
        continue
    fmap = dict(zip(seq_pos, flex))
    rows = [(p, d) for p, d in disp[key] if p in fmap]
    if len(rows) < 30:
        continue
    pos = np.array([p for p, _ in rows]); obs = np.array([d for _, d in rows])
    fl = np.array([fmap[p] for p in pos])
    rho, p = stats.spearmanr(fl, obs)
    thr = np.percentile(obs, 75)
    plastic = obs >= thr
    auc = stats.mannwhitneyu(fl[plastic], fl[~plastic]).pvalue
    results.append({
        "record_id": rec, "apo_pdb_id": apo, "family": rec.split("_")[-1],
        "n_residues": len(rows), "spearman_flex_vs_disp": round(float(rho), 3),
        "spearman_p": float(p), "mw_p_plastic_more_flexible": float(auc),
    })

rhos = np.array([r["spearman_flex_vs_disp"] for r in results])
med_rho = float(np.median(rhos))
wilcox = stats.wilcoxon(rhos).pvalue if len(rhos) >= 8 else None
frac_pos = float((rhos > 0).mean())
frac_sig = float((np.array([r["spearman_p"] for r in results]) < 0.05).mean())

with open(os.path.join(OUT, "anm_per_pair.csv"), "w", newline="", encoding="utf-8-sig") as f:
    w = csv.DictWriter(f, fieldnames=list(results[0].keys())); w.writeheader(); w.writerows(results)
summary = {
    "n_pairs_analyzed": len(results),
    "median_spearman_flexibility_vs_displacement": round(med_rho, 3),
    "wilcoxon_signed_rank_p_median_gt0": float(wilcox) if wilcox is not None else None,
    "frac_pairs_rho_positive": round(frac_pos, 3),
    "frac_pairs_p_lt_0.05": round(frac_sig, 3),
    "note": "ANM 为静态晶体固有柔性的理论近似，不等于结合诱导重排；按方案预期若相关弱亦如实报告。",
}
with open(os.path.join(OUT, "anm_summary.json"), "w", encoding="utf-8") as f:
    json.dump(summary, f, ensure_ascii=False, indent=2)
print(json.dumps(summary, ensure_ascii=False, indent=2))
