# -*- coding: utf-8 -*-
"""Step81: H1 可行性检查 —— PeSTo apo 性能是否由界面预成度（pre-formation）分层决定。

H1: 配对级 PeSTo apo AUPRC 与界面预成指数显著相关（预成度 = 界面窗口平均 interface_ca_rmsd，
值越小越预成；预期方向为负相关：RMSD 越大性能越差）。
H1b: 中位二分后预成组与可塑组的配对级 AUPRC 差异显著。

输入：
  data/processed/apo_v3/apo_window_metadata_v3.csv   （interface_ca_rmsd 等）
  results/Step79_c1_v3/c1_v3_oof_scores.csv         （label, pesto_protein，与 v3 元数据同窗口集）
输出：
  results/Step81_h1_feasibility/h1_result.json
  results/Step81_h1_feasibility/pair_level_table.csv
"""
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

ROOT = Path(__file__).resolve().parent.parent
META = ROOT / "data/processed/apo_v3/apo_window_metadata_v3.csv"
OOF = ROOT / "results/Step79_c1_v3/c1_v3_oof_scores.csv"
OUT = ROOT / "results/Step81_h1_feasibility"
OUT.mkdir(parents=True, exist_ok=True)

rng = np.random.default_rng(42)
N_BOOT = 1000


def auprc(y, s):
    y = np.asarray(y, dtype=int)
    s = np.asarray(s, dtype=float)
    order = np.argsort(-s, kind="mergesort")
    y = y[order]
    tp = np.cumsum(y)
    prec = tp / np.arange(1, len(y) + 1)
    return float((prec * y).sum() / y.sum())


def pair_auc(y, s):
    """Mann-Whitney AUC，正负例均≥1即可算。"""
    y = np.asarray(y, dtype=int)
    s = np.asarray(s, dtype=float)
    pos, neg = s[y == 1], s[y == 0]
    if len(pos) == 0 or len(neg) == 0:
        return np.nan
    r = stats.rankdata(np.concatenate([pos, neg]))
    return float((r[: len(pos)].sum() - len(pos) * (len(pos) + 1) / 2) / (len(pos) * len(neg)))


def boot_ci(values, stat_fn, n=N_BOOT):
    vals = np.asarray(values, dtype=float)
    vals = vals[~np.isnan(vals)]
    if len(vals) < 5:
        return [float("nan"), float("nan")]
    stats_ = np.empty(n)
    for i in range(n):
        idx = rng.integers(0, len(vals), len(vals))
        stats_[i] = stat_fn(vals[idx])
    return [float(np.percentile(stats_, 2.5)), float(np.percentile(stats_, 97.5))]


meta = pd.read_csv(META)
oof = pd.read_csv(OOF)

df = oof.merge(
    meta[["window_id", "record_id", "apo_pdb_id", "interface_ca_rmsd", "aligned_ca_rmsd"]],
    on="window_id", how="left", suffixes=("", "_m"),
)
assert df["interface_ca_rmsd"].notna().all(), "存在无法 join 的窗口"

# 配对级预成指数：界面窗口（label==1）的 interface_ca_rmsd 均值；无正例的配对回退全部窗口
rows = []
for (rec, apo), g in df.groupby(["record_id", "apo_pdb_id"]):
    iface = g[g["label"] == 1]
    src = iface if len(iface) > 0 else g
    rows.append({
        "pair_id": f"{rec}__{apo}",
        "record_id": rec,
        "apo_pdb_id": apo,
        "cluster": g["homology_cluster"].iloc[0],
        "dataset": g["dataset"].iloc[0],
        "n_windows": len(g),
        "n_pos": int((g["label"] == 1).sum()),
        "preformation_rmsd": float(src["interface_ca_rmsd"].mean()),
        "aligned_rmsd": float(g["aligned_ca_rmsd"].iloc[0]),
        "pesto_pair_auprc": auprc(g["label"], g["pesto_protein"]) if (g["label"].sum() >= 2) else np.nan,
        "pesto_pair_auc": pair_auc(g["label"], g["pesto_protein"]),
    })
pairs = pd.DataFrame(rows)
usable = pairs.dropna(subset=["pesto_pair_auprc"]).reset_index(drop=True)

# H1: Spearman 相关（预成度越小越预成 → 预期 rho < 0）
rho_auprc, p_auprc = stats.spearmanr(usable["preformation_rmsd"], usable["pesto_pair_auprc"])
rho_auc, p_auc = stats.spearmanr(pairs["preformation_rmsd"], pairs["pesto_pair_auc"])

# 配对 bootstrap CI（对 Spearman 重抽样配对）
rhos = np.empty(N_BOOT)
for i in range(N_BOOT):
    idx = rng.integers(0, len(usable), len(usable))
    sub = usable.iloc[idx]
    if sub["preformation_rmsd"].nunique() < 3 or sub["pesto_pair_auprc"].nunique() < 3:
        rhos[i] = np.nan
    else:
        rhos[i] = stats.spearmanr(sub["preformation_rmsd"], sub["pesto_pair_auprc"])[0]
rhos = rhos[~np.isnan(rhos)]
ci_rho = [float(np.percentile(rhos, 2.5)), float(np.percentile(rhos, 97.5))]

# H1b: 中位二分
med = usable["preformation_rmsd"].median()
usable["stratum"] = np.where(usable["preformation_rmsd"] <= med, "preformed", "plastic")
a_pre = usable.loc[usable["stratum"] == "preformed", "pesto_pair_auprc"].to_numpy()
a_pla = usable.loc[usable["stratum"] == "plastic", "pesto_pair_auprc"].to_numpy()
delta_med = float(np.median(a_pre) - np.median(a_pla))
mean_pre, mean_pla = float(np.mean(a_pre)), float(np.mean(a_pla))
deltas = np.empty(N_BOOT)
for i in range(N_BOOT):
    pre_idx = rng.integers(0, len(a_pre), len(a_pre))
    pla_idx = rng.integers(0, len(a_pla), len(a_pla))
    deltas[i] = np.mean(a_pre[pre_idx]) - np.mean(a_pla[pla_idx])
ci_delta = [float(np.percentile(deltas, 2.5)), float(np.percentile(deltas, 97.5))]

# 分层池化 AUPRC（辅助）
def pooled(stratum_df):
    g = df.merge(stratum_df[["record_id", "apo_pdb_id"]], on=["record_id", "apo_pdb_id"])
    return auprc(g["label"], g["pesto_protein"]), len(g)

pooled_pre = pooled(usable[usable["stratum"] == "preformed"])
pooled_pla = pooled(usable[usable["stratum"] == "plastic"])

result = {
    "hypothesis": "H1: PeSTo apo AUPRC 由界面预成度分层（预成度=界面窗口均 interface_ca_rmsd）",
    "n_pairs_total": int(len(pairs)),
    "n_pairs_with_auprc": int(len(usable)),
    "preformation_rmsd_distribution": {
        "min": float(usable["preformation_rmsd"].min()),
        "median": float(med),
        "max": float(usable["preformation_rmsd"].max()),
    },
    "H1_spearman": {
        "metric": "pair AUPRC vs preformation_rmsd",
        "rho": float(rho_auprc),
        "p_value": float(p_auprc),
        "pair_bootstrap_95ci": ci_rho,
        "ci_upper_below_zero": bool(ci_rho[1] < 0),
    },
    "H1_spearman_auc_version": {"rho": float(rho_auc), "p_value": float(p_auc)},
    "H1b_median_split": {
        "preformed_pairs": int((usable["stratum"] == "preformed").sum()),
        "plastic_pairs": int((usable["stratum"] == "plastic").sum()),
        "mean_auprc_preformed": mean_pre,
        "mean_auprc_plastic": mean_pla,
        "delta_mean": float(mean_pre - mean_pla),
        "delta_median": delta_med,
        "bootstrap_95ci": ci_delta,
        "ci_lower_positive": bool(ci_delta[0] > 0),
    },
    "pooled_auprc_stratified": {
        "preformed": {"auprc": pooled_pre[0], "n_windows": int(pooled_pre[1])},
        "plastic": {"auprc": pooled_pla[0], "n_windows": int(pooled_pla[1])},
    },
    "baseline_reference": "全配对 PeSTo apo OOF AUPRC = 0.12582 (Step79)",
    "n_bootstrap": N_BOOT,
    "seed": 42,
}

(OUT / "h1_result.json").write_text(json.dumps(result, indent=2, ensure_ascii=False))
usable.to_csv(OUT / "pair_level_table.csv", index=False)
print(json.dumps(result, indent=2, ensure_ascii=False))
