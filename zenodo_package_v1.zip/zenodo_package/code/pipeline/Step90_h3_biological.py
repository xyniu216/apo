# -*- coding: utf-8 -*-
"""Step90: H3 家族级生物学刻画（描述性，无门槛）。

A. 每家族：记录/配对数、预成指数（aligned RMSD 均值）、界面残基 vs 非界面残基的局部位移、PeSTo apo 配对 AUPRC
B. 配对内检验：界面残基是否比非界面残基更易重排（每对取中位数 → 83 对 Wilcoxon 符号秩）
C. 家族级图：预成指数 × 界面可塑性 × PeSTo 性能三联图
"""
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "results/Step90_h3_biological"
OUT.mkdir(parents=True, exist_ok=True)

meta = pd.read_csv(ROOT / "data/processed/apo_v3/apo_window_metadata_v3.csv")
disp = pd.read_csv(ROOT / "results/Step86_displacement/per_residue_displacement_v3.csv")
meta = meta.merge(disp[["record_id", "apo_pdb_id", "apo_position", "local_ca_displacement"]],
                  on=["record_id", "apo_pdb_id", "apo_position"], how="left")
pairs = pd.read_csv(ROOT / "results/Step82_h1_prereg/pair_level_table.csv")
fam_of_record = meta.drop_duplicates("record_id")[["record_id", "family", "partner_gene"]]
pairs = pairs.merge(fam_of_record, on="record_id", how="left")

# A. 家族级汇总
rows = []
for fam, g in pairs.groupby("family"):
    mm = meta[meta.record_id.isin(g.record_id)]
    iface = mm[mm["label"] == 1]["local_ca_displacement"]
    noniface = mm[mm["label"] == 0]["local_ca_displacement"]
    rows.append({
        "family": fam, "n_records": g.record_id.nunique(), "n_pairs": len(g),
        "preformation_aligned_rmsd_mean": g["preformation_aligned"].mean(),
        "interface_local_disp_mean": iface.mean(),
        "noninterface_local_disp_mean": noniface.mean(),
        "interface_vs_noninterface_ratio": iface.mean() / max(noniface.mean(), 1e-9),
        "pesto_apo_pair_auprc_mean": g["pesto_pair_auprc"].mean(),
        "frac_plastic_pairs": float((g["preformation_aligned"] > g["preformation_aligned"].median()).mean()),
    })
fam_table = pd.DataFrame(rows).sort_values("preformation_aligned_rmsd_mean")
fam_table.to_csv(OUT / "family_table.csv", index=False)

# B. 配对内界面 vs 非界面（每对中位数 → Wilcoxon）
pr = []
for (rec, apo), g in meta.groupby(["record_id", "apo_pdb_id"]):
    i = g.loc[g["label"] == 1, "local_ca_displacement"]
    n = g.loc[g["label"] == 0, "local_ca_displacement"]
    if len(i) >= 3 and len(n) >= 3:
        pr.append({"pair_id": f"{rec}__{apo}", "family": g["family"].iloc[0],
                   "iface_median": i.median(), "noniface_median": n.median()})
pr = pd.DataFrame(pr)
pr.to_csv(OUT / "interface_vs_noninterface_pairs.csv", index=False)
w_stat, w_p = stats.wilcoxon(pr["iface_median"], pr["noniface_median"])
diff = pr["iface_median"] - pr["noniface_median"]
iface_more_mobile = float((diff > 0).mean())

# C. 图
import sys
sys.path.insert(0, str(Path(sys.executable).parent.parent.parent))
from daimon_runtime import setup_plot
import matplotlib.pyplot as plt

setup_plot()
fig, axes = plt.subplots(1, 2, figsize=(12.5, 4.6))
t = fam_table.tail(12)  # 配对数最多的家族更可靠，展示前12
ax = axes[0]
x = np.arange(len(t))
ax.bar(x - 0.2, t["interface_local_disp_mean"], 0.4, label="界面残基", color="#d62728")
ax.bar(x + 0.2, t["noninterface_local_disp_mean"], 0.4, label="非界面残基", color="#7f7f7f")
ax.set_xticks(x); ax.set_xticklabels(t["family"], rotation=45, ha="right", fontsize=8)
ax.set_ylabel("平均局部重排位移 (Å)")
ax.set_title("A  界面 vs 非界面残基的可塑性（按家族）")
ax.legend(frameon=False, fontsize=8)

ax = axes[1]
sc = ax.scatter(t["preformation_aligned_rmsd_mean"], t["pesto_apo_pair_auprc_mean"],
                s=t["n_pairs"] * 14, c=t["interface_local_disp_mean"], cmap="viridis",
                alpha=0.8, edgecolors="white")
for _, r in t.iterrows():
    ax.annotate(r["family"], (r["preformation_aligned_rmsd_mean"], r["pesto_apo_pair_auprc_mean"]),
                fontsize=7, ha="center", va="bottom")
ax.set_xlabel("预成指数（全局 apo→holo RMSD, Å，越大越可塑）")
ax.set_ylabel("PeSTo apo 配对 AUPRC 均值")
ax.set_title("B  家族级：预成度 × 预测性能（点色=界面可塑性）")
fig.colorbar(sc, ax=ax, label="界面平均位移 (Å)")
fig.tight_layout()
fig.savefig(OUT / "h3_family_landscape.png", dpi=200, bbox_inches="tight")

result = {
    "A_family_table": OUT.joinpath("family_table.csv").name,
    "B_interface_vs_noninterface": {
        "n_pairs": int(len(pr)),
        "median_diff_A": float(diff.median()),
        "wilcoxon_stat": float(w_stat), "wilcoxon_p": float(w_p),
        "frac_pairs_iface_more_mobile": iface_more_mobile,
    },
    "note": "描述性分析，无门槛；家族按预成指数排序",
}
(OUT / "h3_result.json").write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
print(fam_table.round(3).to_string())
print(json.dumps(result["B_interface_vs_noninterface"], indent=2))
