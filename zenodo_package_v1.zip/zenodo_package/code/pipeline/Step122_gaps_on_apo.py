# -*- coding: utf-8 -*-
"""Step122：把官方 GAPS 权重跑在本文 28 个 apo 结构上，并在同一 apo 面板内
计算每对的结构-配对 AUPRC，得到与 PeSTo 的可比基准。

stage=infer   -> results/Step122_gaps_on_apo/residue_scores_apo.csv
stage=metrics -> results/Step122_gaps_on_apo/gaps_apo_stats.json (+ pair_level_with_gaps.csv)
"""
from __future__ import annotations

import argparse, json, sys, time
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(r"D:\hnnm\Metabolic_Inflammation_Functional_Interface")
GAPS_DIR = ROOT / "docs/paper/_revision_work/gaps"
sys.path.insert(0, str(GAPS_DIR / "GAPS"))
sys.path.insert(0, str(GAPS_DIR / "_pylibs"))
sys.path.insert(0, str(ROOT / "code"))

import gemmi  # noqa: E402
import torch as pt  # noqa: E402

from src.structure_io import read_pdb  # noqa: E402
from src.structure import (cle_structure, delete_hetatm, split_by_chain,  # noqa: E402
                           fil_non_atomic_sub, rm_duplicate_tagged_sub, concatenate_chains)
from src.data_encoding import en_structure, en_features, ext_topology  # noqa: E402
from src.dataset import col_batch  # noqa: E402
from src.config import config_model  # noqa: E402
from model.model import Model  # noqa: E402

OUT = ROOT / "results/Step122_gaps_on_apo"


def auprc(y, s):
    y = np.asarray(y, dtype=int); s = np.asarray(s, dtype=float)
    order = np.argsort(-s, kind="mergesort")
    y = y[order]; tp = np.cumsum(y); prec = tp / np.arange(1, len(y) + 1)
    return float((prec * y).sum() / y.sum())

CIF = ROOT / "data/raw/apo/structures_v3"
TMP = OUT / "_tmp_pdb"


def residue_map(raw):
    s = {k: (v.copy() if hasattr(v, "copy") else v) for k, v in raw.items()}
    s = cle_structure(s)
    s = delete_hetatm(s)
    m_wat = raw["resname"] == "HOH"
    m_h = raw["element"] == "H"
    m_d = raw["element"] == "D"
    m_hwat = raw["resname"] == "DOD"
    keep = ~(m_wat | m_h | m_d | m_hwat) & (raw["het_flag"] != "H")
    internal = s["resid"]
    o_resid = raw["resid"][keep]
    o_chain = raw["chain_name"][keep]
    o_icode = raw["icode"][keep]
    o_resname = raw["resname"][keep]
    n = len(internal)
    assert n == int(keep.sum()), "mask/reindex mismatch"
    levels = []
    for i in range(n):
        key = int(internal[i])
        if not levels or levels[-1][0] != key:
            levels.append([key, str(o_chain[i]).split(":")[0], int(o_resid[i]),
                           str(o_icode[i]).strip(), str(o_resname[i])])
    return levels, s


def forward(model, subunits):
    structure = concatenate_chains(subunits)
    X, M = en_structure(structure)
    q = en_features(structure)[0]
    ids_topk, _, _, _, _ = ext_topology(X, 64)
    X, ids_topk, q, M = col_batch([[X, ids_topk, q, M]])
    with pt.no_grad():
        p = pt.sigmoid(model(X, ids_topk, q, M.float())).cpu().numpy().ravel()
    return p, M.shape[1]


def cif_to_pdb(pdb_id: str) -> Path:
    TMP.mkdir(parents=True, exist_ok=True)
    dst = TMP / f"{pdb_id}.pdb"
    doc = gemmi.read_structure(str(CIF / f"{pdb_id}.cif"))
    doc.setup_entities()
    doc.write_pdb(str(dst))
    return dst


def run_one(model, pdb_id):
    t0 = time.time()
    pdb_path = cif_to_pdb(pdb_id)
    raw = read_pdb(str(pdb_path))
    levels, s = residue_map(raw)
    subunits = split_by_chain(s)
    subunits = fil_non_atomic_sub(subunits)
    subunits = rm_duplicate_tagged_sub(subunits)
    if not subunits:
        return [], {"pdb_id": pdb_id, "status": "empty_subunits"}
    p, n_cols = forward(model, subunits)
    if len(p) != n_cols:
        return [], {"pdb_id": pdb_id, "status": f"length_mismatch p={len(p)} cols={n_cols}"}
    rows = [{"pdb_id": pdb_id, "chain_id": ch, "auth_seq_id": auth, "icode": ic,
             "resname": rn, "gaps_probability": float(p[r - 1])}
            for (r, ch, auth, ic, rn) in levels if 1 <= r <= len(p)]
    return rows, {"pdb_id": pdb_id, "status": "ok", "n_residues": len(p),
                  "n_levels": len(levels), "seconds": round(time.time() - t0, 2)}


def stage_infer(limit=0):
    pt.set_num_threads(8)
    model = Model(config_model)
    model.load_state_dict(pt.load(str(GAPS_DIR / "GAPS/checkpoints/model.pt"), map_location="cpu"))
    model.eval()
    pairs = pd.read_csv(ROOT / "results/Step82_h1_prereg/pair_level_table.csv")
    ids = sorted(pairs.apo_pdb_id.unique().tolist())
    if limit:
        ids = ids[:limit]
    print(f"structures: {len(ids)}", flush=True)
    rows, log, t0 = [], [], time.time()
    for i, pid in enumerate(ids, 1):
        try:
            r, m = run_one(model, pid)
        except Exception as e:  # noqa: BLE001
            r, m = [], {"pdb_id": pid, "status": f"exception: {type(e).__name__}: {e}"}
        rows.extend(r); log.append(m)
        print(f"[{i}/{len(ids)}] {pid} {m.get('status')} rows={len(rows)} "
              f"elapsed={time.time()-t0:.0f}s", flush=True)
    OUT.mkdir(parents=True, exist_ok=True)
    scores = pd.DataFrame(rows)
    if len(scores):
        scores["pdb_id"] = scores["pdb_id"].str.lower()
        scores.to_csv(OUT / "residue_scores_apo.csv", index=False)
    pd.DataFrame(log).to_csv(OUT / "run_log_apo.csv", index=False)
    summary = {"structures": len(ids), "ok": sum(1 for m in log if m.get("status") == "ok"),
               "rows": len(rows), "seconds": round(time.time() - t0, 1)}
    (OUT / "run_summary_apo.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2))
    print(json.dumps(summary, ensure_ascii=False))


def stage_metrics():
    from scipy import stats
    pairs = pd.read_csv(ROOT / "results/Step82_h1_prereg/pair_level_table.csv")
    oof = pd.read_csv(ROOT / "results/Step79_c1_v3/c1_v3_oof_scores.csv")
    meta = pd.read_csv(ROOT / "data/processed/apo_v3/apo_window_metadata_v3.csv")
    g = pd.read_csv(OUT / "residue_scores_apo.csv")
    g["auth_seq_id"] = g["auth_seq_id"].astype(int)
    g["icode"] = g["icode"].fillna("").astype(str).str.strip()

    df = oof.merge(meta[["window_id", "apo_chain", "apo_position"]], on="window_id", how="left")
    df["apo_pdb_id"] = df["apo_pdb_id"].str.lower()
    df["apo_position"] = df["apo_position"].astype(int)
    df = df.merge(g[["pdb_id", "chain_id", "auth_seq_id", "icode", "gaps_probability"]],
                  left_on=["apo_pdb_id", "apo_chain", "apo_position"],
                  right_on=["pdb_id", "chain_id", "auth_seq_id"], how="left")
    cov = df.gaps_probability.notna().mean()
    print("window coverage by GAPS: %.4f (%d/%d)" % (cov, df.gaps_probability.notna().sum(), len(df)))

    rows = []
    for (rec, apo), gg in df.groupby(["record_id", "apo_pdb_id"]):
        sub = gg.dropna(subset=["gaps_probability"])
        if sub.label.sum() < 2:
            continue
        rows.append({"pair_id": f"{rec}__{apo}", "record_id": rec, "apo_pdb_id": apo,
                     "cluster": gg["homology_cluster"].iloc[0],
                     "n_windows": int(len(gg)), "n_covered": int(len(sub)),
                     "gaps_auprc": auprc(sub.label, sub.gaps_probability)})
    pg = pd.DataFrame(rows)
    m = pairs.merge(pg, on=["pair_id", "record_id", "apo_pdb_id"])
    m.to_csv(OUT / "pair_level_with_gaps.csv", index=False)

    x = m.preformation_aligned.to_numpy(); y = m.gaps_auprc.to_numpy(); yp = m.pesto_pair_auprc.to_numpy()
    rho_p, p_p = stats.spearmanr(x, y)
    diff = y - yp
    apo = m.groupby("apo_pdb_id").agg(rmsd=("preformation_aligned", "first"),
                                      gaps=("gaps_auprc", "median"),
                                      pesto=("pesto_pair_auprc", "median")).reset_index()
    rho_a, p_a = stats.spearmanr(apo.rmsd, apo.gaps)
    rho_a_pesto, p_a_pesto = stats.spearmanr(apo.rmsd, apo.pesto)
    rng = np.random.default_rng(7)
    n = len(apo); bs = []
    for _ in range(3000):
        i = rng.integers(0, n, n)
        bs.append(stats.spearmanr(apo.rmsd.values[i], apo.gaps.values[i])[0])
    ci = [float(np.percentile(bs, 2.5)), float(np.percentile(bs, 97.5))]
    w = stats.wilcoxon(y, yp) if len(y) >= 10 else None

    res = {
        "n_pairs": int(len(m)), "n_apo": int(apo.shape[0]),
        "window_coverage": round(float(cov), 4),
        "pair_level": {"gaps_spearman": {"rho": round(float(rho_p), 4), "p": float(p_p)},
                       "gaps_auprc_mean": round(float(y.mean()), 4),
                       "gaps_auprc_median": round(float(np.median(y)), 4),
                       "pesto_auprc_median": round(float(np.median(yp)), 4)},
        "apo_level": {"gaps_spearman": {"rho": round(float(rho_a), 4), "p": float(p_a)},
                      "bootstrap_95ci": [round(ci[0], 4), round(ci[1], 4)],
                      "frac_negative": round(float(np.mean(np.array(bs) < 0)), 4),
                      "pesto_spearman": {"rho": round(float(rho_a_pesto), 4), "p": float(p_a_pesto)}},
        "gaps_minus_pesto_pair_auprc": {"mean": round(float(diff.mean()), 4),
                                        "median": round(float(np.median(diff)), 4),
                                        "wilcoxon_p": (float(w.pvalue) if w is not None else None)},
        "apo_table": apo.round(4).to_dict(orient="records"),
    }
    (OUT / "gaps_apo_stats.json").write_text(json.dumps(res, ensure_ascii=False, indent=2))
    (OUT / "gaps_apo_stats.txt").write_text(
        json.dumps({k: v for k, v in res.items() if k != "apo_table"}, ensure_ascii=False, indent=2),
        encoding="utf-8")
    print(json.dumps({k: v for k, v in res.items() if k != "apo_table"}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--stage", default="infer")
    ap.add_argument("--limit", type=int, default=0)
    a = ap.parse_args()
    if a.stage == "infer":
        stage_infer(a.limit)
    else:
        stage_metrics()
