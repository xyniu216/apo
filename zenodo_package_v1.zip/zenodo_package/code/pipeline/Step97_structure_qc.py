# -*- coding: utf-8 -*-
"""Step97: 83 对 apo-holo 配对的结构质控表（分辨率/Rfree/方法）。
数据源：data/raw/pdb/*.cif + results/Step86_displacement/per_residue_displacement_v3.csv
输出：results/Step97_structure_qc/pair_structure_qc.csv + qc_summary.json
"""
import csv, json, os, sys
from collections import defaultdict
from Bio.PDB.MMCIF2Dict import MMCIF2Dict

ROOT = r"D:\hnnm\Metabolic_Inflammation_Functional_Interface"
PDB_DIR = os.path.join(ROOT, "data", "raw", "pdb")
OUT_DIR = os.path.join(ROOT, "results", "Step97_structure_qc")
os.makedirs(OUT_DIR, exist_ok=True)

def head(pdb_id):
    """从 mmCIF 头解析分辨率、Rfree、实验方法。"""
    p = os.path.join(PDB_DIR, pdb_id.lower() + ".cif")
    if not os.path.exists(p):
        return {"resolution": None, "rfree": None, "method": None}
    try:
        d = MMCIF2Dict(p)
        def first(x):
            if x is None: return None
            if isinstance(x, list): return x[0] if x else None
            return x
        def f(x):
            try:
                v = first(x)
                return float(v) if v not in (None, "", "?") else None
            except (ValueError, TypeError):
                return None
        # 晶体：_reflns.d_resolution_high / _refine 系列；冷冻电镜：_em_3d_reconstruction.resolution；NMR 无分辨率
        res = None
        for k in ("_reflns.d_resolution_high", "_refine.ls_d_res_high",
                  "_em_3d_reconstruction.resolution", "_em_3d_fitting_list.resolution"):
            res = f(d.get(k))
            if res: break
        rfree = None
        for k in ("_refine.ls_R_factor_R_free", "_reflns.R_free"):
            rfree = f(d.get(k))
            if rfree: break
        method = first(d.get("_exptl.method"))
        return {"resolution": res, "rfree": rfree, "method": method}
    except Exception as e:
        return {"resolution": None, "rfree": None, "method": f"PARSE_ERROR:{e}"}

# 83 对清单（唯一 (record_id, apo_pdb_id)），并取 holo_pdb_id / apo_chain / family
pairs = {}
disp = os.path.join(ROOT, "results", "Step86_displacement", "per_residue_displacement_v3.csv")
with open(disp, encoding="utf-8") as f:
    for r in csv.DictReader(f):
        key = (r["record_id"], r["apo_pdb_id"])
        if key not in pairs:
            pairs[key] = {"apo_chain": r["apo_chain"], "holo_pdb_id": None, "family": None}

def fnum(x):
    try:
        return float(x) if x not in (None, "", "NA") else None
    except ValueError:
        return None

# holo pdb / family / 序列同一性 / 叠合 RMSD 以 apo_window_metadata_v3（覆盖全部 83 对）为准
wm = os.path.join(ROOT, "data", "processed", "apo_v3", "apo_window_metadata_v3.csv")
with open(wm, encoding="utf-8") as f:
    for r in csv.DictReader(f):
        key = (r["record_id"], r["apo_pdb_id"])
        if key in pairs and pairs[key].get("holo_pdb_id") is None:
            pairs[key]["holo_pdb_id"] = r["holo_pdb_id"]
            pairs[key]["family"] = r["family"]
            pairs[key]["sequence_identity"] = fnum(r["sequence_identity"])
            pairs[key]["global_ca_rmsd"] = fnum(r["aligned_ca_rmsd"])
            pairs[key]["interface_ca_rmsd"] = fnum(r["interface_ca_rmsd"])
            pairs[key]["interface_coverage"] = fnum(r["interface_coverage"])

# pair_level_table（H1 预注册）提供 preformation（全局 RMSD）、界面 RMSD、覆盖度与 AUPRC
plt_rows = {}
with open(os.path.join(ROOT, "results", "Step82_h1_prereg", "pair_level_table.csv"), encoding="utf-8") as f:
    for r in csv.DictReader(f):
        plt_rows[(r["record_id"], r["apo_pdb_id"])] = r
        key = (r["record_id"], r["apo_pdb_id"])
        if key in pairs:
            pairs[key]["global_ca_rmsd"] = fnum(r["preformation_aligned"])
            pairs[key]["interface_ca_rmsd"] = fnum(r["preformation_iface_rmsd"])
            pairs[key]["interface_coverage"] = fnum(r["preformation_coverage"])

rows = []
missing_holo = []
for (rec, apo), meta in sorted(pairs.items()):
    holo = meta.get("holo_pdb_id")
    if not holo:
        missing_holo.append((rec, apo)); continue
    ah, ao = head(holo), head(apo)
    pl = plt_rows.get((rec, apo), {})
    g = meta.get("global_ca_rmsd")
    cls = "预成型" if (g is not None and g < 2.0) else "可塑"  # 连续谱上的描述性分层（2 Å 为 H1 剂量反应区间的近似中点）
    rows.append({
        "record_id": rec, "family": meta.get("family"), "holo_pdb_id": holo, "apo_pdb_id": apo,
        "apo_chain": meta.get("apo_chain"),
        "holo_resolution": ah["resolution"], "holo_rfree": ah["rfree"], "holo_method": ah["method"],
        "apo_resolution": ao["resolution"], "apo_rfree": ao["rfree"], "apo_method": ao["method"],
        "sequence_identity": meta.get("sequence_identity"), "interface_coverage": meta.get("interface_coverage"),
        "global_ca_rmsd": g, "interface_ca_rmsd": meta.get("interface_ca_rmsd"),
        "preformation_class": cls,
        "pesto_apo_pair_auprc": pl.get("pesto_pair_auprc"),
        "dataset": pl.get("dataset"),
    })

out_csv = os.path.join(OUT_DIR, "pair_structure_qc.csv")
cols = list(rows[0].keys())
with open(out_csv, "w", newline="", encoding="utf-8-sig") as f:
    w = csv.DictWriter(f, fieldnames=cols); w.writeheader(); w.writerows(rows)

def stats(vals):
    vals = [v for v in vals if v is not None]
    if not vals: return None
    vals.sort()
    n = len(vals)
    return {"n": n, "min": round(vals[0], 2), "median": round(vals[n//2], 2), "max": round(vals[-1], 2)}

summary = {
    "n_pairs": len(rows),
    "missing_holo_join": missing_holo,
    "apo": {"resolution": stats([r["apo_resolution"] for r in rows]),
             "rfree": stats([r["apo_rfree"] for r in rows]),
             "method_counts": dict(__import__("collections").Counter(r["apo_method"] for r in rows))},
    "holo": {"resolution": stats([r["holo_resolution"] for r in rows]),
              "rfree": stats([r["holo_rfree"] for r in rows]),
              "method_counts": dict(__import__("collections").Counter(r["holo_method"] for r in rows))},
    "n_preformed_lt2A": sum(1 for r in rows if r["preformation_class"] == "预成型"),
    "n_plastic_ge2A": sum(1 for r in rows if r["preformation_class"] == "可塑"),
    "n_apo_resolution_gt3p5": sum(1 for r in rows if r["apo_resolution"] and r["apo_resolution"] > 3.5),
    "n_holo_resolution_gt3p5": sum(1 for r in rows if r["holo_resolution"] and r["holo_resolution"] > 3.5),
}
with open(os.path.join(OUT_DIR, "qc_summary.json"), "w", encoding="utf-8") as f:
    json.dump(summary, f, ensure_ascii=False, indent=2)

print(json.dumps(summary, ensure_ascii=False, indent=2))
print("rows:", len(rows), "->", out_csv)
